// Kiwtech — meesho-fetch.js
// Runs on meesho.com product pages, listens for FETCH_PRODUCT message

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.action === 'FETCH_MEESHO_PRODUCT') {
    try {
      const data = scrapeProduct();
      sendResponse({ success: true, data });
    } catch(e) {
      sendResponse({ success: false, error: e.message });
    }
    return true;
  }

  if (msg.action === 'CHECK_MEESHO_PAGE') {
    sendResponse({
      isProduct: isProductPage(),
      url: window.location.href
    });
    return true;
  }
});

function isProductPage() {
  const url = window.location.href;
  if (url.includes('/search') || url.includes('searchType') || url.includes('?q=')) return false;
  if (window.location.pathname.length < 10) return false;
  return !!document.querySelector('h1') || !!window.__NEXT_DATA__?.props?.pageProps;
}

function scrapeProduct() {
  const nd = window.__NEXT_DATA__;
  const pp = nd?.props?.pageProps;

  // Try all possible data paths Meesho uses
  const d = pp?.initialState?.product?.details?.data
    || pp?.initialState?.product?.data
    || pp?.product?.details?.data
    || pp?.catalogData
    || pp?.initialState?.catalog?.data
    || pp?.data
    || null;

  let result = {
    title: '', price: '', mrp: '', discount: '',
    rating: '', reviews: '', sold: '',
    description: '', category: '',
    images: [], attrs: {},
    url: window.location.href,
    source: 'json'
  };

  if (d) {
    result.title       = d.catalog_name || d.name || d.product_name || '';
    result.price       = String(d.meesho_price || d.price || '');
    result.mrp         = String(d.mrp || '');
    result.discount    = d.discount_percent ? d.discount_percent + '%' : '';
    result.rating      = String(d.rating || d.avg_rating || '');
    result.reviews     = String(d.ratings_count || d.reviews_count || '');
    result.sold        = String(d.sold_count || d.total_orders || '');
    result.description = (d.description || d.catalog_description || d.about || '').trim();
    result.category    = d.category || d.catalog_category || '';

    // Images
    const seen = new Set();
    const addImg = url => {
      if (!url || seen.has(url)) return;
      seen.add(url);
      // Strip resize transforms for original quality
      const clean = url
        .replace(/\/upload\/[a-z_,0-9]+\//, '/upload/')
        .replace(/,w_\d+|,h_\d+|,c_[^,/]+|,q_\d+/g, '')
        .replace(/\?.*$/, '');
      result.images.push(clean || url);
    };

    if (Array.isArray(d.catalog_images)) d.catalog_images.forEach(i => addImg(i.url || i));
    if (Array.isArray(d.images)) d.images.forEach(i => addImg(i.url || i.src || i));
    if (Array.isArray(d.variants)) d.variants.forEach(v => v.image_url && addImg(v.image_url));
    if (Array.isArray(d.catalog_variants)) d.catalog_variants.forEach(v => v.image_url && addImg(v.image_url));

    // Attributes
    const addAttrs = arr => {
      if (!Array.isArray(arr)) return;
      arr.forEach(a => {
        const k = a.name || a.attribute_name || a.key;
        const v = a.value || a.attribute_value || a.val;
        if (k && v) result.attrs[k] = String(v).trim();
      });
    };
    addAttrs(d.product_details?.product_highlights?.attributes);
    addAttrs(d.product_details?.additional_details?.attributes);
    addAttrs(d.attributes);
    addAttrs(d.product_attributes);
    addAttrs(d.variants?.[0]?.attributes);

    // Top-level fields as attrs
    const knownFields = {
      'Color': d.color, 'Fabric': d.fabric || d.material,
      'Brand': d.brand, 'Size': d.size,
      'Net Quantity': d.net_quantity, 'Country of Origin': d.country_of_origin,
      'Generic Name': d.generic_name, 'Type': d.type,
      'Shelf Life': d.shelf_life, 'Capacity': d.capacity,
    };
    Object.entries(knownFields).forEach(([k, v]) => { if (v && !result.attrs[k]) result.attrs[k] = String(v); });
  }

  // DOM fallback if JSON missing or incomplete
  if (!result.title) {
    result.source = 'dom';
    result.title = document.querySelector('h1')?.innerText?.trim()
      || document.title.replace(/buy|meesho|online/gi, '').trim();
  }

  if (!result.images.length) {
    document.querySelectorAll('img').forEach(img => {
      const src = img.src || img.getAttribute('data-src') || '';
      if (src && img.naturalWidth > 150 &&
          (src.includes('meesho-media') || src.includes('meeshocdn') || src.includes('cloudinary'))) {
        result.images.push(src);
      }
    });
    result.images = [...new Set(result.images)].slice(0, 12);
  }

  // DOM attributes from product highlights table
  if (!Object.keys(result.attrs).length) {
    document.querySelectorAll('table tr').forEach(row => {
      const cells = row.querySelectorAll('td');
      if (cells.length >= 2) {
        const k = cells[0]?.innerText?.trim();
        const v = cells[1]?.innerText?.trim();
        if (k && v && k.length < 60) result.attrs[k] = v;
      }
    });
  }

  return result;
}

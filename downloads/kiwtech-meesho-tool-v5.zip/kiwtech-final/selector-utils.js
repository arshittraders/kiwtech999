// selector-utils.js — Kiwtech Meesho Tool v2.0
// Generates stable CSS selectors for DOM elements

(function () {

  /**
   * Returns a stable, unique CSS selector for any DOM element.
   * Priority: id → name+type → aria-label → placeholder → class path → nth-child path
   */
  function getStableSelector(el) {
    if (!el || !el.tagName) return null;
    const tag = el.tagName.toLowerCase();

    // 1. Has id — most stable
    if (el.id && el.id.trim() !== '') {
      return `${tag}[id="${CSS.escape(el.id)}"]`;
    }

    // 2. Has name attribute
    if (el.name && el.name.trim() !== '') {
      const typePart = el.type ? `[type="${el.type}"]` : '';
      const sel = `${tag}[name="${CSS.escape(el.name)}"]${typePart}`;
      // Verify uniqueness
      if (document.querySelectorAll(sel).length === 1) return sel;
    }

    // 3. aria-label
    const ariaLabel = el.getAttribute('aria-label');
    if (ariaLabel) {
      const sel = `${tag}[aria-label="${CSS.escape(ariaLabel)}"]`;
      if (document.querySelectorAll(sel).length === 1) return sel;
    }

    // 4. placeholder
    if (el.placeholder && el.placeholder.trim() !== '') {
      const sel = `${tag}[placeholder="${CSS.escape(el.placeholder)}"]`;
      if (document.querySelectorAll(sel).length === 1) return sel;
    }

    // 5. aria-labelledby → resolve label text
    const labelledBy = el.getAttribute('aria-labelledby');
    if (labelledBy) {
      const lbl = document.getElementById(labelledBy);
      if (lbl) {
        const txt = lbl.innerText.trim();
        if (txt) {
          const sel = `${tag}[aria-labelledby="${CSS.escape(labelledBy)}"]`;
          if (document.querySelectorAll(sel).length === 1) return sel;
        }
      }
    }

    // 6. MUI FormControl label → use MUISELECT: prefix for div buttons
    if (tag === 'div') {
      const fc = el.closest('.MuiFormControl-root');
      if (fc) {
        const lbl = fc.querySelector('.MuiFormLabel-root,.MuiInputLabel-root,label');
        if (lbl) {
          const labelText = lbl.innerText.trim().replace(/\s*\*\s*$/, '').trim();
          if (labelText) return `MUISELECT:${labelText}`;
        }
      }
    }

    // 7. Build nth-child path from body down (fallback)
    const path = buildNthChildPath(el);
    return path;
  }

  /**
   * Builds a path-based CSS selector using nth-child.
   * Traverses up the DOM to body and builds a unique path.
   */
  function buildNthChildPath(el) {
    const parts = [];
    let current = el;

    while (current && current !== document.body && current.parentElement) {
      const tag = current.tagName.toLowerCase();
      const parent = current.parentElement;
      const siblings = Array.from(parent.children).filter(c => c.tagName === current.tagName);

      if (siblings.length === 1) {
        parts.unshift(tag);
      } else {
        const idx = siblings.indexOf(current) + 1;
        parts.unshift(`${tag}:nth-of-type(${idx})`);
      }

      // Add a stable anchor class if available to avoid overly long paths
      const stableClasses = ['MuiFormControl-root', 'MuiInputBase-root', 'MuiOutlinedInput-root'];
      const cls = stableClasses.find(c => current.classList.contains(c));
      if (cls && parts.length > 1) {
        parts[0] = `.${cls} > ${parts[0]}`;
        break;
      }

      current = parent;

      // Stop if we've reached a reasonable depth
      if (parts.length >= 6) break;
    }

    const sel = parts.join(' > ');

    // Verify uniqueness; if not unique, append ||index
    const all = document.querySelectorAll(sel);
    if (all.length === 1) return sel;
    if (all.length > 1) {
      const idx = Array.from(all).indexOf(el);
      if (idx >= 0) return `${sel}||${idx}`;
    }

    return sel;
  }

  // Expose globally
  window.getStableSelector = getStableSelector;

})();

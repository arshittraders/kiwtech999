// Kiwtech Meesho All-in-One Tool v5.0 — background.js
// Backend-powered: OpenAI key + license storage central server par hai
// ────────────────────────────────────────────────────────────────────

// ── Side Panel: Extension icon click pe side panel open karo ────────────────
chrome.sidePanel.setPanelBehavior({ openPanelOnActionClick: true }).catch(() => {});

// ⚠️  IMPORTANT: Deploy your Cloudflare Worker first, then paste the URL here:
const BACKEND_URL = "https://kiwtech-backend.kiwtech.workers.dev";

// ─── Device ID (random, persistent) — for soft device locking ──────────────
async function getDeviceId() {
  const r = await chrome.storage.local.get(["deviceId"]);
  if (r.deviceId) return r.deviceId;
  const id = "DEV-" + Math.random().toString(36).substring(2, 10) +
             "-" + Math.random().toString(36).substring(2, 10);
  await chrome.storage.local.set({ deviceId: id });
  return id;
}

// ─── Get stored credentials ──────────────────────────────────────────────
async function getCreds() {
  const r = await chrome.storage.local.get(["licenseKey", "gmail"]);
  return { key: r.licenseKey || "", email: r.gmail || "" };
}

// ─── Backend call helper ─────────────────────────────────────────────────
async function backendCall(path, body) {
  if (BACKEND_URL.includes("YOUR-SUBDOMAIN")) {
    return { success: false, error: "Backend URL not configured. background.js mein BACKEND_URL set karein." };
  }
  try {
    const res = await fetch(BACKEND_URL + path, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    return await res.json();
  } catch (e) {
    return { success: false, error: "Backend reachable nahi hai: " + e.message };
  }
}

// ─── Local license validation (when backend not configured) ──────────────
function validateKeyLocally(key) {
  // Key format: KWT-XXXXX-XXXXX-XXXXX (alphanumeric segments)
  if (!key) return false;
  const parts = key.trim().toUpperCase().split("-");
  return parts.length === 4 && parts[0] === "KWT" &&
         parts[1].length >= 4 && parts[2].length >= 4 && parts[3].length >= 4;
}

// ─── License cache (avoid re-validating on every call) ───────────────────
let _licCache = null;
async function getValidLicense() {
  if (_licCache && (Date.now() - _licCache.cachedAt) < 5 * 60 * 1000) return _licCache;
  const { key, email } = await getCreds();
  if (!key || !email) return null;

  // If backend not configured, use local validation
  if (BACKEND_URL.includes("YOUR-SUBDOMAIN")) {
    if (!validateKeyLocally(key)) return null;
    _licCache = { key, email, deviceId: await getDeviceId(), plan: "local", expiresAt: null, cachedAt: Date.now() };
    return _licCache;
  }

  const deviceId = await getDeviceId();
  const r = await backendCall("/api/verify", { email, key, deviceId });
  if (!r.valid) return null;
  _licCache = {
    key, email, deviceId,
    plan: r.plan,
    expiresAt: r.expiresAt,
    cachedAt: Date.now(),
  };
  return _licCache;
}

// ─── XMP Metadata writer (JPEG) — UNCHANGED (no API) ────────────────────
function escapeXml(str) {
  return String(str || "")
    .replace(/&/g, "&amp;").replace(/</g, "&lt;")
    .replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}

function writeXMPtoJPEG(base64Input, title, subject, tags, comment, rating) {
  const binaryStr = atob(base64Input);
  const bytes = new Uint8Array(binaryStr.length);
  for (let i = 0; i < binaryStr.length; i++) bytes[i] = binaryStr.charCodeAt(i);

  const xmpData = `<?xpacket begin="\uFEFF" id="W5M0MpCehiHzreSzNTczkc9d"?>
<x:xmpmeta xmlns:x="adobe:ns:meta/">
  <rdf:RDF xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#">
    <rdf:Description rdf:about=""
      xmlns:dc="http://purl.org/dc/elements/1.1/"
      xmlns:xmp="http://ns.adobe.com/xap/1.0/"
      xmlns:MicrosoftPhoto="http://ns.microsoft.com/photo/1.0/">
      <dc:title><rdf:Alt><rdf:li xml:lang="x-default">${escapeXml(title)}</rdf:li></rdf:Alt></dc:title>
      <dc:subject>
        <rdf:Bag>
          ${subject.split(" ").filter(Boolean).map(k => `<rdf:li>${escapeXml(k)}</rdf:li>`).join("\n          ")}
        </rdf:Bag>
      </dc:subject>
      <dc:description><rdf:Alt><rdf:li xml:lang="x-default">${escapeXml(comment)}</rdf:li></rdf:Alt></dc:description>
      <xmp:Rating>${rating}</xmp:Rating>
      <MicrosoftPhoto:Rating>${rating === 5 ? 99 : rating === 4 ? 75 : rating === 3 ? 50 : rating === 2 ? 25 : 1}</MicrosoftPhoto:Rating>
    </rdf:Description>
    <rdf:Description rdf:about="" xmlns:MicrosoftPhoto="http://ns.microsoft.com/photo/1.0/">
      <MicrosoftPhoto:LastKeywordXMP>
        <rdf:Bag>
          ${tags.split(" ").filter(Boolean).map(k => `<rdf:li>${escapeXml(k)}</rdf:li>`).join("\n          ")}
        </rdf:Bag>
      </MicrosoftPhoto:LastKeywordXMP>
    </rdf:Description>
  </rdf:RDF>
</x:xmpmeta>
<?xpacket end="w"?>`;

  const xmpBytes = new TextEncoder().encode(xmpData);
  const xmpSegmentHeader = new TextEncoder().encode("http://ns.adobe.com/xap/1.0/\x00");
  const segmentLength = xmpBytes.length + xmpSegmentHeader.length + 2;

  const xmpSegment = new Uint8Array(segmentLength + 4);
  xmpSegment[0] = 0xFF; xmpSegment[1] = 0xE1;
  xmpSegment[2] = (segmentLength >> 8) & 0xFF;
  xmpSegment[3] = segmentLength & 0xFF;
  xmpSegment.set(xmpSegmentHeader, 4);
  xmpSegment.set(xmpBytes, 4 + xmpSegmentHeader.length);

  let insertPos = 2;
  while (insertPos < bytes.length - 1) {
    if (bytes[insertPos] === 0xFF) {
      const marker = bytes[insertPos + 1];
      if (marker === 0xE0 || marker === 0xE1 || marker === 0xE2) {
        const segLen = (bytes[insertPos + 2] << 8) | bytes[insertPos + 3];
        insertPos += 2 + segLen;
      } else { break; }
    } else { break; }
  }

  const output = new Uint8Array(bytes.length + xmpSegment.length);
  output.set(bytes.slice(0, insertPos));
  output.set(xmpSegment, insertPos);
  output.set(bytes.slice(insertPos), insertPos + xmpSegment.length);

  let outBin = "";
  for (let i = 0; i < output.length; i++) outBin += String.fromCharCode(output[i]);
  return btoa(outBin);
}

// ─── Message handlers ────────────────────────────────────────────────────
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {

  // ── Relay to content script (for form scan / autofill) ────────────────
  const relay = (msg) => {
    chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
      if (!tabs || !tabs[0]) { sendResponse({ success: false, error: "No active tab" }); return; }
      const tab = tabs[0];
      if (!tab.url || !tab.url.includes("meesho.com")) {
        sendResponse({ success: false, error: "Meesho supplier page kholen pehle" }); return;
      }
      chrome.tabs.sendMessage(tab.id, msg, (response) => {
        if (chrome.runtime.lastError) sendResponse({ success: false, error: chrome.runtime.lastError.message });
        else sendResponse(response);
      });
    });
    return true;
  };

  if (message.type === "AUTOFILL_FIELDS") return relay({ action: "AUTOFILL", data: { fields: message.fields, force: true } });
  if (message.type === "SCAN_FORM")       return relay({ action: "SCAN_FORM" });
  if (message.type === "DEEP_SCAN")       return relay({ action: "DEEP_SCAN" });
  if (message.type === "START_CAPTURE")   return relay({ action: "START_CAPTURE", profileId: message.name });
  if (message.type === "STOP_CAPTURE")    return relay({ action: "STOP_CAPTURE" });

  // ── Capture stopped callback ──────────────────────────────────────────
  if (message.action === "CAPTURE_STOPPED") {
    chrome.storage.local.get(["captureProfiles"], (stored) => {
      const profiles = stored.captureProfiles || {};
      profiles[message.name] = { fields: message.data, savedAt: new Date().toISOString() };
      chrome.storage.local.set({ captureProfiles: profiles });
    });
    return true;
  }

  // ── Write XMP metadata (no API needed) ────────────────────────────────
  if (message.type === "WRITE_XMP_METADATA" || message.type === "WRITE_IMAGE_METADATA") {
    (async () => {
      try {
        const { imageBase64, metadata } = message;
        const { title="", subject="", tags="", comment="", rating=5 } = metadata || {};
        const outputBase64 = writeXMPtoJPEG(imageBase64, title, subject, tags, comment, rating);
        sendResponse({ success: true, outputBase64 });
      } catch (e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  // ── OpenAI call (via backend) ─────────────────────────────────────────
  if (message.type === "OPENAI_CALL") {
    (async () => {
      try {
        const { key, email } = await getCreds();
        if (!key || !email) {
          sendResponse({ success: false, error: "Login required — popup mein license activate karein" });
          return;
        }
        const deviceId = await getDeviceId();
        const r = await backendCall("/api/openai", {
          email, key, deviceId, payload: message.payload
        });
        sendResponse(r);
      } catch (e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  // ── Validate license (via backend) ────────────────────────────────────
  if (message.type === "VALIDATE_LICENSE") {
    (async () => {
      try {
        const email = (message.gmail || message.email || "").toLowerCase().trim();
        const key = (message.key || "").toUpperCase().trim();
        if (!email || !key) {
          sendResponse({ success: true, valid: false, reason: "Gmail aur Key dono required" });
          return;
        }
        const deviceId = await getDeviceId();

        // Local validation if backend not configured
        if (BACKEND_URL.includes("YOUR-SUBDOMAIN")) {
          if (validateKeyLocally(key)) {
            await chrome.storage.local.set({ licenseKey: key, gmail: email });
            _licCache = null;
            sendResponse({ success: true, valid: true, plan: "local", expiry: null, gmail: email });
          } else {
            sendResponse({ success: true, valid: false, reason: "Invalid key format." });
          }
          return;
        }

        const r = await backendCall("/api/verify", { email, key, deviceId });
        if (r.valid) {
          await chrome.storage.local.set({ licenseKey: key, gmail: email });
          _licCache = null;
          sendResponse({ success: true, valid: true, plan: r.plan, expiry: r.expiresAt, gmail: r.gmail });
        } else {
          sendResponse({ success: true, valid: false, reason: r.error });
        }
      } catch (e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  // ── Logout ────────────────────────────────────────────────────────────
  if (message.type === "LOGOUT") {
    (async () => {
      await chrome.storage.local.remove(["licenseKey", "gmail"]);
      _licCache = null;
      sendResponse({ success: true });
    })();
    return true;
  }

  // ── Check current login status ────────────────────────────────────────
  if (message.type === "CHECK_LOGIN") {
    (async () => {
      const lic = await getValidLicense();
      if (lic) sendResponse({ success: true, valid: true, plan: lic.plan, expiry: lic.expiresAt, gmail: lic.email });
      else sendResponse({ success: true, valid: false });
    })();
    return true;
  }

  // ── Fetch image as base64 JPG (bypass CORS) ─────────────────────────────
  if (message.type === "FETCH_IMAGE_AS_JPG") {
    (async () => {
      try {
        const resp = await fetch(message.url, {
          headers: { 'Accept': 'image/*,*/*', 'Referer': 'https://www.meesho.com/' }
        });
        if (!resp.ok) throw new Error('HTTP ' + resp.status);
        const blob = await resp.blob();
        const ab = await blob.arrayBuffer();
        const bytes = new Uint8Array(ab);
        let binary = '';
        for (let i = 0; i < bytes.byteLength; i++) binary += String.fromCharCode(bytes[i]);
        const b64 = btoa(binary);
        sendResponse({ success: true, base64: b64, mimeType: blob.type || 'image/jpeg' });
      } catch(e) {
        sendResponse({ success: false, error: e.message });
      }
    })();
    return true;
  }

  // ── Fetch catalog data by ID (for Fetch tab) ─────────────────────────────
  if (message.type === "FETCH_CATALOG_DATA") {
    (async () => {
      try {
        const { catalogId } = message;
        // Search Meesho for this specific catalog ID
        const body = {
          query: catalogId, type: "text_search",
          page: 1, offset: 0, limit: 5,
          search_session_id: `ctx_1_uid_-1_txt_-1_t_${Date.now()}`,
          isDevicePhone: false
        };
        const res = await fetch("https://www.meesho.com/api/v1/products/search", {
          method: "POST",
          headers: { "Content-Type": "application/json", "meesho-iso-country-code": "IN",
            "Origin": "https://www.meesho.com", "Referer": "https://www.meesho.com/" },
          credentials: "omit", body: JSON.stringify(body)
        });
        if (!res.ok) { sendResponse({ success: false, error: `API ${res.status}` }); return; }
        const apiData = await res.json();
        const catalogs = apiData?.catalogs || [];
        // Find matching catalog
        const cat = catalogs.find(c =>
          String(c.catalogId) === String(catalogId) ||
          String(c.id)        === String(catalogId) ||
          String(c.product_id) === String(catalogId) ||
          String(c.original_product_id) === String(catalogId)
        ) || catalogs[0];

        if (!cat) { sendResponse({ success: false, error: 'Catalog nahi mila' }); return; }

        // find a number anywhere inside an object by key name (Meesho keeps renaming fields)
        const deepNum = (obj, re, depth = 0) => {
          if (!obj || typeof obj !== "object" || depth > 5) return null;
          for (const [k, v] of Object.entries(obj)) {
            if (re.test(k) && (typeof v === "number" || (typeof v === "string" && /^\d+(\.\d+)?$/.test(v)))) return Number(v);
            if (re.test(k) && v && typeof v === "object") { const n = v.charges ?? v.charge ?? v.amount ?? v.value ?? v.price; if (n !== undefined && !isNaN(Number(n))) return Number(n); }
          }
          for (const v of Object.values(obj)) { if (v && typeof v === "object") { const n = deepNum(v, re, depth + 1); if (n !== null) return n; } }
          return null;
        };
        const SHIP_RE = /^(shipping|shipping_?charges?|shipping_?fee|delivery_?charges?|delivery_?fee|logistics_?charges?|logisticsCharge|shippingCharges?|deliveryCharges?)$/i;
        // Decode price_metadata
        let insights = {};
        try {
          const pm64 = cat.app_event_data?.price_metadata || '';
          if (pm64) {
            let pm = {};
            try { pm = JSON.parse(atob(pm64)); } catch (e1) { try { pm = JSON.parse(decodeURIComponent(escape(atob(pm64)))); } catch (e2) {} }
            const logi = pm.logisticsCharge ?? pm.logistics_charge ?? pm.shippingCharges ?? pm.shipping_charges ?? deepNum(pm, SHIP_RE);
            const buyerPrice = parseFloat(cat.min_product_price || cat.min_catalog_price || 0);
            const supPrice   = pm.supplierPrice || 0;
            insights = {
              supplier_price:   supPrice ? `₹${supPrice}` : '',
              buyer_price:      buyerPrice ? `₹${buyerPrice}` : '',
              logistics_charge: logi !== null && logi !== undefined && !isNaN(Number(logi)) ? `₹${Number(logi).toFixed(2)}` : '',
              cod_charge:       pm.codCharge ? `₹${pm.codCharge.toFixed(2)}` : '',
              inventory:        pm.inventoryCount !== undefined ? String(pm.inventoryCount) : '',
              weight:           pm.weight ? `${pm.weight}g` : '',
              zone:             pm.zone || '',
              margin_pct:       supPrice && buyerPrice ? `${((buyerPrice - supPrice)/buyerPrice*100).toFixed(1)}%` : '',
              cod_discount:     pm.codDiscount ? `₹${pm.codDiscount}` : '',
              rto_pct_cod:      (() => { if (!pm.rtoPercentageCod) return ""; const r = pm.rtoPercentageCod; const p = r > 1 ? r : r*100; return Math.min(p,99.9).toFixed(1)+"%"; })(),
            };
          }
        } catch(e) {}

        // Build result object
        const data = {
          title:       cat.name || cat.hero_product_name || '',
          price:       String(cat.min_product_price || cat.min_catalog_price || ''),
          mrp:         '',
          discount:    '',
          shipping:    (() => { const sc = cat.shipping?.charges ?? cat.shipping_charges ?? cat.shipping?.amount ?? deepNum(cat, SHIP_RE);
                                if (sc === 0) return 'Free'; if (sc !== null && sc !== undefined && sc !== '') return String(sc);
                                const l = (insights.logistics_charge || '').replace(/[^0-9.]/g, ''); return l ? l : ''; })(),
          rating:      String(cat.catalog_reviews_summary?.average_rating || ''),
          reviews:     String(cat.catalog_reviews_summary?.rating_count || ''),
          description: cat.full_details || cat.description || '',
          category:    cat.sub_sub_category_name || '',
          images:      [],
          attrs:       {},
          seller:      { inventory: insights.inventory || '' },
          stats: {
            product_rating: String(cat.catalog_reviews_summary?.average_rating || ''),
            rating_count:   String(cat.catalog_reviews_summary?.rating_count || ''),
            review_count:   String(cat.catalog_reviews_summary?.review_count || ''),
            rating_map:     cat.catalog_reviews_summary?.rating_count_map || {},
            is_ad:          cat.isAdProduct ? 'Yes (Ad)' : 'No (Organic)',
          },
          similar:    [],
          insights,
          url: `https://www.meesho.com/${cat.slug || ''}`,
        };

        // Extract images
        const imgSet = new Set();
        const addI = u => { if (u && !imgSet.has(u)) { imgSet.add(u); data.images.push(u); } };
        (cat.images || []).forEach(u => addI(typeof u === 'string' ? u : u?.url));
        (cat.product_images || []).forEach(i => addI(i.url || i));
        addI(cat.image); addI(cat.collage_image);

        sendResponse({ success: true, data });
      } catch(e) { sendResponse({ success: false, error: e.message }); }
    })();
    return true;
  }

  // ── Get backend URL (for popup display) ──────────────────────────────
  if (message.type === "GET_BACKEND_URL") {
    sendResponse({ success: true, url: BACKEND_URL });
    return false;
  }

  // ── Legacy admin handlers — admin is now web-based ──────────────────
  if (message.type === "ADMIN_GENERATE_KEY" || message.type === "ADMIN_GENERATE_DEMO" ||
      message.type === "ADMIN_LIST_KEYS" || message.type === "ADMIN_DEACTIVATE_KEY" ||
      message.type === "ADMIN_EXPORT_KEYS" || message.type === "ADMIN_IMPORT_KEYS") {
    sendResponse({ success: false, error: "Admin panel ab web-based hai. Visit: " + BACKEND_URL + "/admin" });
    return false;
  }

  // ── Legacy OpenAI key handlers (no longer used) ──────────────────────
  if (message.type === "GET_OPENAI_KEY" || message.type === "SAVE_OPENAI_KEY") {
    sendResponse({ success: true, key: "(backend-managed)" });
    return false;
  }

  // ── RANK TRACKER messages ─────────────────────────────────────────────
  if (message.type === "RANK_START") {
    startRankSearch(message.keyword, message.targetId).then(sendResponse);
    return true;
  }
  if (message.type === "RANK_STOP") {
    rankState.running = false;
    if (rankState.tabId && rankState.origUrl) {
      chrome.tabs.update(rankState.tabId, { url: rankState.origUrl }).catch(() => {});
    }
    sendResponse({ ok: true });
    return false;
  }
  if (message.type === "RANK_STATUS") {
    sendResponse({
      running: rankState.running,
      page: rankState.page,
      idsFound: rankState.allIds.length,
      keyword: rankState.keyword,
      targetId: rankState.targetId,
      found: rankState.found
    });
    return false;
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// ── RANK TRACKER ENGINE — Runs entirely in background ──────────────────────
// ═══════════════════════════════════════════════════════════════════════════

let rankState = {
  running: false,
  keyword: '',
  targetId: '',
  tabId: null,
  origUrl: '',
  page: 0,
  maxPages: 100,
  allIds: [],        // accumulated product IDs across pages
  found: false,
};

const rankSleep = ms => new Promise(r => setTimeout(r, ms));

// Broadcast status to all popup instances
function rankBroadcast(msg) {
  chrome.runtime.sendMessage({ type: 'RANK_UPDATE', ...msg }).catch(() => {});
}

async function rankWaitComplete(tabId, timeoutMs = 18000) {
  const start = Date.now();
  while (Date.now() - start < timeoutMs) {
    try {
      const tab = await chrome.tabs.get(tabId);
      if (tab.status === 'complete') return true;
    } catch(e) { return false; }
    await rankSleep(200);
  }
  return true; // timeout — proceed anyway
}

// ── Fetch IDs directly from Meesho search API (no tab/scroll needed) ──────────
// ── Rank: Meesho exact POST API with cursor-based pagination ──────────────────
let rankCursor = null; // cursor from previous page response

async function rankFetchPageIds(keyword, page) {
  try {
    const offset = (page - 1) * 20;
    const sessionId = `ctx_1_uid_-1_txt_-1_t_${Date.now()}`;

    const body = {
      query: keyword,
      type: "text_search",
      page: page,
      offset: offset,
      limit: 20,
      search_session_id: sessionId,
      isDevicePhone: false
    };

    // Use cursor from previous response for pagination (Meesho uses cursor not page number)
    if (rankCursor && page > 1) {
      body.cursor = rankCursor;
    }

    const res = await fetch("https://www.meesho.com/api/v1/products/search", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json, text/plain, */*",
        "Accept-Language": "en-GB,en-US;q=0.9,en;q=0.8",
        "Origin": "https://www.meesho.com",
        "Referer": `https://www.meesho.com/search?q=${encodeURIComponent(keyword)}`,
        "meesho-iso-country-code": "IN",
        "sec-fetch-dest": "empty",
        "sec-fetch-mode": "cors",
        "sec-fetch-site": "same-origin",
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/149.0.0.0 Safari/537.36"
      },
      credentials: "omit",
      body: JSON.stringify(body)
    });

    if (!res.ok) {
      console.log(`[Rank] API failed: ${res.status}`);
      return { ids: [], method: `api_${res.status}`, total: 0, cursor: null };
    }

    const data = await res.json();

    // Save cursor for next page
    if (data?.cursor) rankCursor = data.cursor;

    // Extract catalog IDs
    const ids = new Set();

    const catalogs = data?.catalogs || data?.data?.catalogs || [];
    catalogs.forEach(c => {
      if (c.id)                   ids.add(String(c.id));
      if (c.catalogId)            ids.add(String(c.catalogId));
      if (c.catalog_id)           ids.add(String(c.catalog_id));
      if (c.product_id)           ids.add(String(c.product_id));
      if (c.original_product_id)  ids.add(String(c.original_product_id));
      if (c.hero_pid)             ids.add(String(c.hero_pid));
      if (c.slug)                 { ids.add(String(c.slug)); ids.add(String(c.slug).replace(/^s-/i,'')); }
      if (c.original_slug)        ids.add(String(c.original_slug));
      const imgs = c.images || c.product_images || [];
      const imgUrl = (Array.isArray(imgs) && imgs[0]) ? (imgs[0].url || imgs[0]) : (c.image || '');
      const m = String(imgUrl).match(/\/images\/products\/(\d{5,12})\//);
      if (m) ids.add(m[1]);
    });
    const str = JSON.stringify(data);
    for (const m of str.matchAll(/\/images\/products\/(\d{5,12})\//g)) ids.add(m[1]);

    const arr = [...ids].filter(Boolean);
    console.log(`[Rank] Page ${page}: ${catalogs.length} catalogs → ${arr.length} IDs | cursor: ${data?.cursor ? 'yes' : 'no'}`);

    return {
      ids: arr,
      method: "post_api",
      total: arr.length,
      catalogCount: catalogs.length,
      cursor: data?.cursor || null
    };

  } catch(e) {
    console.log(`[Rank] API error: ${e.message}`);
    return { ids: [], method: 'api_error', total: 0, cursor: null };
  }
}
async function runRankSearch() {
  const PER_PAGE = 20;
  rankCursor = null; // reset cursor for new search
  const s = rankState;

  for (let page = 1; page <= s.maxPages; page++) {
    if (!s.running) break;
    s.page = page;

    rankBroadcast({
      status: 'progress', page,
      message: `Page ${page} fetch ho rahi hai...`,
      idsFound: s.allIds.length
    });

    try {
      // Meesho POST API — exact same request as browser makes
      const pageResult = await rankFetchPageIds(s.keyword, page);
      const { ids: newIds, method, total, catalogCount } = pageResult;

      // Add new IDs in sequence
      const before = s.allIds.length;
      newIds.forEach(id => { if (!s.allIds.includes(id)) s.allIds.push(id); });
      const added = s.allIds.length - before;

      chrome.storage.local.set({ rankSearchState: { keyword: s.keyword, targetId: s.targetId, page, allIds: s.allIds, ts: Date.now() } });

      rankBroadcast({
        status: 'progress', page,
        message: `Page ${page} [${method}]: ${catalogCount || total} products | +${added} new IDs | Searching for: ${s.targetId}`,
        idsFound: s.allIds.length,
        sample: newIds.slice(0, 4).join(', ')
      });

    // Check match — try numeric ID, s- prefix, slug all variants
    const tId      = s.targetId.toLowerCase().replace(/^s-/, '');
    const tIdWithS = 's-' + tId;

    const pos = s.allIds.findIndex(id => {
      const idStr   = String(id).toLowerCase();
      const idClean = idStr.replace(/^s-/, '');
      return idClean === tId || idStr === tId || idStr === tIdWithS || idStr === s.targetId.toLowerCase();
    });

      if (pos !== -1) {
        const rank       = pos + 1;
        const foundPage  = Math.ceil(rank / PER_PAGE);
        const posInPage  = ((rank - 1) % PER_PAGE) + 1;
        s.found   = true;
        s.running = false;

        // Save history
        const entry = {
          date: new Date().toISOString().slice(0,10),
          time: new Date().toLocaleTimeString('en-IN',{hour:'2-digit',minute:'2-digit'}),
          rank, page: foundPage, posInPage, perPage: PER_PAGE,
          keyword: s.keyword, catalogId: s.targetId
        };
        const stored = await chrome.storage.local.get(['rankHistory']);
        const h   = stored.rankHistory || {};
        const key = s.targetId + '_' + s.keyword.replace(/\s+/g,'_').slice(0,20);
        if (!h[key]) h[key] = { keyword: s.keyword, catalogId: s.targetId, entries: [] };
        h[key].entries.unshift(entry);
        if (h[key].entries.length > 30) h[key].entries = h[key].entries.slice(0,30);
        await chrome.storage.local.set({ rankHistory: h });

        // Restore tab
        if (s.origUrl) chrome.tabs.update(s.tabId, { url: s.origUrl }).catch(() => {});

        rankBroadcast({
          status: 'found', rank, page: foundPage, posInPage, perPage: PER_PAGE,
          keyword: s.keyword, catalogId: s.targetId
        });
        return;
      }

      // No more results — stop when API returns 0 catalogs
      if ((catalogCount || 0) === 0) {
        if (page <= 2) {
          // Maybe rate limited — wait and retry once
          await rankSleep(2000);
          const retry = await rankFetchPageIds(s.keyword, page);
          if (retry.total === 0) {
            s.running = false;
            if (s.origUrl) chrome.tabs.update(s.tabId, { url: s.origUrl }).catch(() => {});
            rankBroadcast({
              status: 'notfound',
              message: `API se data nahi mila (${s.allIds.length} IDs scanned) | Sample: ${s.allIds.slice(0,5).join(', ')} | ID sahi hai? Image URL mein numbers hi daalo`,
              idsFound: s.allIds.length
            });
            return;
          }
          // Got data on retry — continue with it
          const retryIds = retry.ids || [];
          retryIds.forEach(id => { if (!s.allIds.includes(id)) s.allIds.push(id); });
        } else {
          // After page 2, 0 results means end of search
          s.running = false;
          if (s.origUrl) chrome.tabs.update(s.tabId, { url: s.origUrl }).catch(() => {});
          rankBroadcast({
            status: 'notfound',
            message: `${page} pages complete — ${s.allIds.length} IDs scanned — product nahi mila | Sample: ${s.allIds.slice(0,5).join(', ')}`,
            idsFound: s.allIds.length
          });
          return;
        }
      }

      // Small delay between pages (API rate limit protection)
      await rankSleep(300);

    } catch(e) {
      rankBroadcast({ status: 'progress', page, message: `Page ${page} error: ${e.message}`, idsFound: s.allIds.length });
      await rankSleep(1500);
    }
  }

  // MAX reached
  s.running = false;
  if (s.origUrl) chrome.tabs.update(s.tabId, { url: s.origUrl }).catch(() => {});
  rankBroadcast({
    status: 'notfound',
    message: `100 pages complete — ${s.allIds.length} total IDs scanned\n"${s.targetId}" is keyword pe nahi mila\nID sahi hai? Product is keyword pe rank karta hai? Sample: ${s.allIds.slice(0,5).join(', ')}`,
    idsFound: s.allIds.length
  });
}


async function startRankSearch(keyword, targetId) {
  if (rankState.running) return { error: 'Already running' };

  // Find meesho buyer tab
  const allTabs = await chrome.tabs.query({});
  const meeshoTab = allTabs.find(t => t.url && t.url.includes('meesho.com') && !t.url.includes('supplier.meesho.com'));
  if (!meeshoTab) return { error: 'meesho.com tab nahi mila — pehle meesho.com kholo' };

  rankState = {
    running: true,
    keyword,
    targetId: targetId.toLowerCase().trim(),
    tabId: meeshoTab.id,
    origUrl: meeshoTab.url,
    page: 0,
    maxPages: 100,
    allIds: [],
    found: false,
  };

  // Run async — don't block response
  runRankSearch().catch(e => {
    rankBroadcast({ status: 'error', message: e.message });
    rankState.running = false;
  });

  return { ok: true };
}

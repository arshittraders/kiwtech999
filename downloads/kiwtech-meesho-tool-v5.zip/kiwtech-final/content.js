const ALLOWED_ORIGIN="https://supplier.meesho.com",CATALOG_PAGE_PATTERN=/\/panel\/v3\/new\/cataloging\/[^\/]+\/catalogs\/single\/(add|edit)/;
function isValidDomain(){return window.location.origin===ALLOWED_ORIGIN}
function isCatalogPage(){return CATALOG_PAGE_PATTERN.test(window.location.pathname)}
isValidDomain()&&isCatalogPage();

let highlightOverlay=null,stopCaptureButton=null,stopAutofillButton=null,isCaptureMode=false,isAutofilling=false,shouldStopAutofill=false,currentProfileId=null;

function initializeUI(){
  if(isValidDomain()){
    highlightOverlay=createOverlay();
    stopCaptureButton=createStopCaptureButton();
    stopAutofillButton=createStopAutofillButton();
  }
}

// ── Selector Parsing ──────────────────────────────────────────────────────────
function parseAndQuerySelector(sel){
  if(!sel)return null;

  // LABEL:text — find input by its nearby label text
  if(sel.startsWith("LABEL:")){
    const labelText = sel.slice(6).trim().toLowerCase().replace(/\s*\*\s*$/,"");
    // Check all MuiFormControl labels
    for(const fc of document.querySelectorAll(".MuiFormControl-root")){
      const lbl = fc.querySelector(".MuiFormLabel-root,.MuiInputLabel-root,label");
      if(!lbl) continue;
      const lt = lbl.innerText.trim().toLowerCase().replace(/\s*\*\s*$/,"");
      if(lt===labelText || lt.includes(labelText) || labelText.includes(lt)){
        const inp = fc.querySelector("input,textarea");
        if(inp) return inp;
        const btn = fc.querySelector('div[role="button"]');
        if(btn) return btn;
      }
    }
    // Fallback: check all labels on page
    for(const lbl of document.querySelectorAll("label,span")){
      const lt = (lbl.innerText||"").trim().toLowerCase().replace(/\s*\*\s*$/,"");
      if(lt===labelText || lt.includes(labelText)){
        const parent = lbl.closest("div,td,li") || lbl.parentElement;
        if(parent){
          const inp = parent.querySelector("input,textarea");
          if(inp) return inp;
        }
      }
    }
    return null;
  }

  // MUISELECT:Label — finds MUI Select div by label text
  if(sel.startsWith("MUISELECT:")){
    const labelText=sel.slice(10).trim().toLowerCase().replace(/\s*\*\s*$/,"").trim();
    const fcs=document.querySelectorAll(".MuiFormControl-root");
    for(const fc of fcs){
      const lbl=fc.querySelector(".MuiFormLabel-root,.MuiInputLabel-root,label");
      if(lbl){
        const lt=lbl.innerText.trim().toLowerCase().replace(/\s*\*\s*$/,"").trim();
        if(lt===labelText||lt.includes(labelText)||labelText.includes(lt)){
          const btn=fc.querySelector('div[role="button"][aria-haspopup="listbox"],div.MuiSelect-select[role="button"]');
          if(btn)return btn;
        }
      }
    }
    return null;
  }

  // SIZE:rowLabel::selector
  if(sel.startsWith("SIZE:")){
    const m=sel.match(/^SIZE:(.+?)::(.+)$/);
    if(!m)return null;
    const rowLabel=m[1],innerSel=m[2];
    // Try multiple row class selectors
    const rowSelectors=[".css-1hw3sau",".css-1d3bbye",".css-46bh2p","[class*='variantRow']","tr"];
    for(const rs of rowSelectors){
      const rows=document.querySelectorAll(rs);
      for(const row of rows){
        const p=row.querySelector("p.css-twqx64,p,[class*='rowLabel'],[class*='RowLabel'],td:first-child");
        if(p&&p.innerText&&p.innerText.trim()===rowLabel){
          const el=row.querySelector(innerSel);
          if(el)return el;
        }
      }
    }
    return null;
  }

  // selector||index
  const parts=sel.split("||");
  const baseSel=parts[0];
  const idx=parts.length>1?parseInt(parts[1],10):0;
  const all=document.querySelectorAll(baseSel);
  return all.length===0?null:(all[idx]||null);
}

function waitForElement(sel,timeout=300){
  return new Promise(resolve=>{
    const find=()=>parseAndQuerySelector(sel);
    const el=find();
    if(el)return resolve(el);
    const obs=new MutationObserver(()=>{const e=find();if(e){obs.disconnect();resolve(e);}});
    obs.observe(document.body,{childList:true,subtree:true});
    setTimeout(()=>{obs.disconnect();resolve(null);},timeout);
  });
}

function waitForTextElement(text,timeout=2500){
  return new Promise(resolve=>{
    const needle=text.toLowerCase().trim();
    const find=()=>{
      const els=document.querySelectorAll('li[role="option"],li,div[role="option"],p,span');
      for(const el of els){
        if(el.offsetParent===null)continue;
        const t=el.innerText?el.innerText.toLowerCase().trim():"";
        if(t===needle||t.includes(needle))return el;
      }
      return null;
    };
    const found=find();
    if(found)return resolve(found);
    const obs=new MutationObserver(()=>{const e=find();if(e){obs.disconnect();resolve(e);}});
    obs.observe(document.body,{childList:true,subtree:true});
    setTimeout(()=>{obs.disconnect();resolve(null);},timeout);
  });
}

function setNativeValue(el,val){
  const nativeSetter=Object.getOwnPropertyDescriptor(el,"value")?.set;
  const proto=Object.getPrototypeOf(el);
  const protoSetter=Object.getOwnPropertyDescriptor(proto,"value")?.set;
  if(nativeSetter&&nativeSetter!==protoSetter||protoSetter){
    protoSetter.call(el,val);
  } else {
    el.value=val;
  }
}

// ── UI Helpers ────────────────────────────────────────────────────────────────
function createOverlay(){
  const el=document.createElement("div");
  el.style.cssText="position:absolute;background:rgba(106,27,154,0.3);border:2px solid #6a1b9a;pointer-events:none;z-index:999999;display:none;transition:all 0.1s ease;";
  document.body.appendChild(el);
  return el;
}

function showToast(msg,isError=false){
  const el=document.createElement("div");
  el.innerText=msg;
  el.style.cssText=`position:fixed;bottom:20px;right:20px;background:${isError?"linear-gradient(180deg,#ff4444 0%,#cc0000 100%)":"linear-gradient(180deg,#00ff88 0%,#00cc6a 100%)"};color:${isError?"#fff":"#000"};padding:12px 20px;font-family:'VT323',monospace;font-size:16px;font-weight:bold;border:2px solid ${isError?"#ff6666":"#33ff9f"};z-index:1000000;box-shadow:0 4px 12px rgba(0,0,0,0.4);opacity:0;transition:opacity 0.3s;text-transform:uppercase;letter-spacing:1px;`;
  document.body.appendChild(el);
  requestAnimationFrame(()=>el.style.opacity="1");
  setTimeout(()=>{el.style.opacity="0";setTimeout(()=>el.remove(),300);},3000);
}

function showFillEffect(el){
  if(!el)return;
  const origOutline=el.style.outline,origShadow=el.style.boxShadow,origTrans=el.style.transition;
  el.style.transition="all 0.2s ease";
  el.style.outline="3px solid #00ff88";
  el.style.boxShadow="0 0 20px #00ff88,0 0 40px #00ff8866,inset 0 0 10px #00ff8833";
  const badge=document.createElement("div");
  badge.innerText="\u2713 FILLED";
  const r=el.getBoundingClientRect();
  badge.style.cssText=`position:absolute;left:${r.left+window.scrollX}px;top:${r.top+window.scrollY-30}px;background:linear-gradient(180deg,#00ff88 0%,#00cc6a 100%);color:#000;padding:4px 12px;font-family:'VT323',monospace;font-size:14px;font-weight:bold;border:2px solid #33ff9f;z-index:1000000;animation:floatUp 0.8s ease-out forwards;pointer-events:none;`;
  document.body.appendChild(badge);
  setTimeout(()=>{el.style.outline=origOutline;el.style.boxShadow=origShadow;el.style.transition=origTrans;},500);
  setTimeout(()=>badge.remove(),800);
}

function showSkipEffect(el){
  if(!el)return;
  const origOutline=el.style.outline,origShadow=el.style.boxShadow;
  el.style.outline="2px solid #ffaa00";
  el.style.boxShadow="0 0 10px #ffaa0066";
  const badge=document.createElement("div");
  badge.innerText="\xbb SKIP";
  const r=el.getBoundingClientRect();
  badge.style.cssText=`position:absolute;left:${r.left+window.scrollX}px;top:${r.top+window.scrollY-25}px;background:linear-gradient(180deg,#ffaa00 0%,#cc8800 100%);color:#000;padding:3px 10px;font-family:'VT323',monospace;font-size:12px;font-weight:bold;border:2px solid #ffcc44;z-index:1000000;animation:floatUp 0.5s ease-out forwards;pointer-events:none;`;
  document.body.appendChild(badge);
  setTimeout(()=>{el.style.outline=origOutline;el.style.boxShadow=origShadow;},300);
  setTimeout(()=>badge.remove(),500);
}

function showNotFoundEffect(sel){
  const el=document.createElement("div");
  const short=sel.length>30?"..."+sel.slice(-27):sel;
  el.innerHTML=`<span style="color:#ff6666">\u2715</span> NOT FOUND: ${short}`;
  el.style.cssText="position:fixed;top:70px;left:50%;transform:translateX(-50%);background:linear-gradient(180deg,#444 0%,#222 100%);color:#ff6666;padding:6px 16px;font-family:'VT323',monospace;font-size:14px;font-weight:bold;border:2px solid #666;z-index:1000000;animation:fadeOut 1s ease-out forwards;pointer-events:none;white-space:nowrap;max-width:90vw;overflow:hidden;text-overflow:ellipsis;";
  document.body.appendChild(el);
  setTimeout(()=>el.remove(),1000);
}

function initVisualEffectStyles(){
  if(document.getElementById("meesho-autofill-styles"))return;
  const s=document.createElement("style");
  s.id="meesho-autofill-styles";
  s.textContent=`
    @keyframes floatUp{0%{opacity:1;transform:translateY(0)}100%{opacity:0;transform:translateY(-20px)}}
    @keyframes fadeOut{0%{opacity:1}70%{opacity:1}100%{opacity:0}}
    @keyframes pulseGlow{0%{box-shadow:0 0 10px #00ff88}50%{box-shadow:0 0 25px #00ff88,0 0 40px #00ff8866}100%{box-shadow:0 0 10px #00ff88}}
    @import url('https://fonts.googleapis.com/css2?family=VT323&display=swap');
  `;
  document.head.appendChild(s);
}

function hideOverlay(){if(highlightOverlay)highlightOverlay.style.display="none";}

function createStopCaptureButton(){
  const btn=document.createElement("button");
  btn.id="meesho-autofill-stop-btn";
  btn.innerText="\u2715 Stop Capture";
  btn.style.cssText="position:fixed;top:20px;right:20px;z-index:1000001;background:#d32f2f;color:white;border:none;padding:10px 20px;border-radius:8px;font-size:14px;font-weight:bold;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.3);display:none;";
  btn.addEventListener("click",stopCaptureMode);
  document.body.appendChild(btn);
  return btn;
}

function stopCaptureMode(){
  isCaptureMode=false;currentProfileId=null;document.body.style.cursor="default";
  hideOverlay();
  if(stopCaptureButton)stopCaptureButton.style.display="none";
  showToast("Capture Mode OFF");
}

function startCaptureMode(profileId){
  isCaptureMode=true;currentProfileId=profileId;document.body.style.cursor="crosshair";
  if(stopCaptureButton)stopCaptureButton.style.display="block";
  showToast("Capture Mode ON - Press ESC or click Stop to exit");
}

function createStopAutofillButton(){
  const btn=document.createElement("button");
  btn.id="meesho-autofill-stop-autofill-btn";
  btn.innerText="\u2b1b STOP AUTOFILL";
  btn.style.cssText="position:fixed;top:20px;left:50%;transform:translateX(-50%);z-index:1000001;background:linear-gradient(180deg,#ff4444 0%,#cc0000 100%);color:white;border:3px solid #fff;padding:12px 24px;font-family:'VT323',monospace;font-size:18px;font-weight:bold;cursor:pointer;box-shadow:0 4px 12px rgba(0,0,0,0.5);display:none;text-transform:uppercase;letter-spacing:2px;";
  const style=document.createElement("style");
  style.textContent="@keyframes pulse-stop{from{box-shadow:0 4px 12px rgba(255,0,0,0.3)}to{box-shadow:0 4px 20px rgba(255,0,0,0.7)}}";
  document.head.appendChild(style);
  btn.addEventListener("click",()=>{shouldStopAutofill=true;showToast("STOPPING...");});
  document.body.appendChild(btn);
  return btn;
}

function showStopAutofillButton(){if(stopAutofillButton)stopAutofillButton.style.display="block";}
function hideStopAutofillButton(){if(stopAutofillButton)stopAutofillButton.style.display="none";}

// ── Dropdown Detection ────────────────────────────────────────────────────────
function isDropdown(el){
  if(!el)return false;
  if("SELECT"===el.tagName)return false;
  if("DIV"===el.tagName)return true;
  if(el.readOnly)return true;
  const role=el.getAttribute("role");
  const haspopup=el.getAttribute("aria-haspopup");
  const autocomplete=el.getAttribute("aria-autocomplete");
  return role==="combobox"||haspopup==="listbox"||autocomplete==="list"||autocomplete==="both";
}

function waitForDropdownPopup(timeout=3000){
  return new Promise(resolve=>{
    const selectors=[".MuiPopover-paper",".MuiMenu-paper",".MuiPopper-root",'div[role="presentation"] .MuiPaper-root','div[role="listbox"]','ul[role="listbox"]'];
    const find=()=>{
      for(const s of selectors){
        const el=document.querySelector(s);
        if(el&&el.offsetParent!==null&&el.offsetWidth>0)return el;
      }
      return null;
    };
    const found=find();
    if(found)return resolve(found);
    const obs=new MutationObserver(()=>{const e=find();if(e){obs.disconnect();resolve(e);}});
    obs.observe(document.body,{childList:true,subtree:true});
    setTimeout(()=>{obs.disconnect();resolve(null);},timeout);
  });
}

function waitForDropdownOptions(timeout=2000){
  return new Promise(resolve=>{
    const selectors=[".MuiMenuItem-root",".MuiPopper-root li",'div[role="presentation"] li',".MuiPaper-root li",".MuiMenu-list li",'li[role="option"]'];
    const find=()=>{
      for(const s of selectors){
        const els=document.querySelectorAll(s);
        for(const el of els){
          if(el.offsetParent!==null&&el.offsetWidth>0&&el.offsetHeight>0&&!el.querySelector("input"))return el;
        }
      }
      return null;
    };
    const found=find();
    if(found)return resolve(found);
    const obs=new MutationObserver(()=>{const e=find();if(e){obs.disconnect();resolve(e);}});
    obs.observe(document.body,{childList:true,subtree:true,characterData:true});
    setTimeout(()=>{obs.disconnect();resolve(null);},timeout);
  });
}

// ── Field Filling ─────────────────────────────────────────────────────────────
async function fillField(el,value){
  if(!el||value===undefined||value===null)return;
  el.scrollIntoView({behavior:"instant",block:"center"});
  await new Promise(r=>setTimeout(r,80));

  // ── Native SELECT ──────────────────────────────────────────────────────────
  if("SELECT"===el.tagName){
    let matched=false;
    for(const opt of el.options){
      if(opt.text.trim()===value.trim()||opt.value===value){el.value=opt.value;matched=true;break;}
    }
    if(!matched){
      const vl=value.toLowerCase();
      for(const opt of el.options){
        if(opt.text.toLowerCase().includes(vl)){el.value=opt.value;matched=true;break;}
      }
    }
    el.dispatchEvent(new Event("change",{bubbles:true}));
    return;
  }

  // ── MUI Select (DIV with role="button" and aria-haspopup="listbox") ────────
  const isMuiSelect="DIV"===el.tagName||(el.getAttribute&&el.getAttribute("role")==="button"&&el.getAttribute("aria-haspopup")==="listbox");
  if(isMuiSelect){
    el.click();
    el.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true,view:window}));
    const popup=await waitForDropdownPopup(3000);
    if(!popup){showToast(`Dropdown didn't open for "${value}"`,true);return;}
    await new Promise(r=>setTimeout(r,300));

    const vl=value.trim().toLowerCase();
    // Special handling for GST % values — "5" should match "5%", "GST 5%", etc.
    const _lblTxt = [el.getAttribute("aria-labelledby")||"", el.getAttribute("aria-label")||"", el.id||"", el.getAttribute("name")||"",
      el.closest(".MuiFormControl-root")?.querySelector("label")?.innerText||"",
      el.parentElement?.parentElement?.innerText?.slice(0,80)||"", el.parentElement?.parentElement?.parentElement?.innerText?.slice(0,80)||""].join(" ").toLowerCase();
    const isGstField = _lblTxt.includes("gst") || /^\s*\d+(\.\d+)?\s*%?\s*$/.test(value) && /gst|tax/.test(_lblTxt);
    let gstVal = isGstField ? value.replace(/[^0-9.]/g,"") : null;
    if (gstVal === "12") gstVal = "5"; else if (gstVal === "28") gstVal = "18";   // GST 2.0 slabs

    // ── Detect checkbox-based multi-select (e.g. Size → "Free Size" + Apply) ──
    const checkboxItems=document.querySelectorAll(
      '.MuiPopover-paper li input[type="checkbox"],.MuiMenu-paper li input[type="checkbox"],.MuiPopper-root li input[type="checkbox"],div[role="presentation"] li input[type="checkbox"]'
    );
    if(checkboxItems.length>0){
      // Find the li whose text matches value
      const liItems=document.querySelectorAll(
        '.MuiPopover-paper li,.MuiMenu-paper li,.MuiPopper-root li,div[role="presentation"] li'
      );
      let targetLi=null;
      for(const li of liItems){
        if(!li.offsetParent)continue;
        const txt=(li.innerText||"").trim().toLowerCase();
        if(txt===vl||txt.includes(vl)||vl.includes(txt)){targetLi=li;break;}
      }
      if(targetLi){
        const cb=targetLi.querySelector('input[type="checkbox"]');
        if(cb&&!cb.checked){
          cb.click();
          targetLi.click();
        }
        await new Promise(r=>setTimeout(r,200));
      }
      // Click the "Apply" button inside the popup
      const allBtns=document.querySelectorAll('button');
      for(const btn of allBtns){
        if(btn.offsetParent&&(btn.innerText||"").trim().toLowerCase()==="apply"){
          btn.click();
          await new Promise(r=>setTimeout(r,200));
          break;
        }
      }
      return;
    }

    // ── Standard single-select listbox ────────────────────────────────────────
    const optSelectors=['li[role="option"]','ul[role="listbox"] li','.MuiMenuItem-root','.MuiList-root li','.MuiPaper-root li'];
    let found=null;

    // Exact match
    for(const s of optSelectors){
      const opts=document.querySelectorAll(s);
      for(const opt of opts){
        if(!opt.offsetParent)continue;
        const optTxt = (opt.innerText||"").trim();
        const optNum = optTxt.replace(/[^0-9.]/g,"");
        if(optTxt===value.trim()){found=opt;break;}
        if(gstVal && optNum === gstVal){found=opt;break;}
      }
      if(found)break;
    }
    // Partial match
    if(!found){
      for(const s of optSelectors){
        const opts=document.querySelectorAll(s);
        for(const opt of opts){
          if(!opt.offsetParent)continue;
          const txt=(opt.innerText||"").trim().toLowerCase();
          const optNum = txt.replace(/[^0-9.]/g,"");
          if(gstVal){ if(optNum === gstVal){found=opt;break;} continue; }
          if(txt.includes(vl)||vl.includes(txt)){found=opt;break;}
        }
        if(found)break;
      }
    }

    // GST: nothing matched exactly → pick the closest available slab (never leave GST empty)
    if(!found && gstVal){
      let bestD=1e9;
      for(const s of optSelectors){
        for(const opt of document.querySelectorAll(s)){
          if(!opt.offsetParent)continue;
          const n=parseFloat((opt.innerText||"").replace(/[^0-9.]/g,""));
          if(isNaN(n))continue;
          const d=Math.abs(n-parseFloat(gstVal));
          if(d<bestD){bestD=d;found=opt;}
        }
        if(found)break;
      }
    }
    if(found){
      found.scrollIntoView({behavior:"instant",block:"center"});
      found.click();
      await new Promise(r=>setTimeout(r,150));
    } else {
      showToast(`Option "${value}" not found in dropdown`,true);
      document.body.click();
      await new Promise(r=>setTimeout(r,100));
    }
    return;
  }

  // ── MUI Autocomplete (INPUT with combobox/autocomplete) ────────────────────
  if("INPUT"===el.tagName&&isDropdown(el)){
    const values=value.split(",").map(v=>v.trim()).filter(v=>v);
    for(const val of values){
      el.focus();el.click();
      el.dispatchEvent(new MouseEvent("mousedown",{bubbles:true,cancelable:true,view:window}));
      el.dispatchEvent(new MouseEvent("mouseup",{bubbles:true,cancelable:true,view:window}));
      if(!await waitForDropdownPopup(3000)){showToast(`Dropdown didn't open for "${val}"`,true);continue;}
      await new Promise(r=>setTimeout(r,80));

      const searchInput=document.querySelector('.MuiPopover-paper input[placeholder="Search"],.MuiMenu-paper input[placeholder="Search"],.MuiPopper-root input[placeholder="Search"],div[role="presentation"] input[placeholder="Search"]');
      if(searchInput){
        searchInput.focus();setNativeValue(searchInput,val);
        searchInput.dispatchEvent(new Event("input",{bubbles:true}));
        searchInput.dispatchEvent(new Event("change",{bubbles:true}));
        await waitForDropdownOptions(2000);
        await new Promise(r=>setTimeout(r,150));
      }

      let found=null,first=null;
      const rowSelectors=[".MuiMenuItem-root",".MuiPopper-root li",'div[role="presentation"] li',".MuiPaper-root li",".MuiMenu-list li"];
      for(const s of rowSelectors){
        const opts=document.querySelectorAll(s);
        for(const opt of opts){
          if(!opt.offsetParent||opt.offsetWidth===0||opt.offsetHeight===0)continue;
          if(opt.querySelector("input"))continue;
          if(!first)first=opt;
          if((opt.innerText||"").trim()===val.trim()){found=opt;break;}
        }
        if(found)break;
      }

      const target=found||first;
      if(target){
        target.scrollIntoView({behavior:"instant",block:"center"});
        target.click();
        await new Promise(r=>setTimeout(r,100));
      } else {
        const el2=await waitForTextElement(val,2000);
        if(el2){el2.scrollIntoView({behavior:"instant",block:"center"});el2.click();await new Promise(r=>setTimeout(r,100));}
        else showToast(`Option "${val}" not found`,true);
      }
    }
    document.body.click();
    await new Promise(r=>setTimeout(r,80));
    return;
  }

  // ── Textarea (description, long text) ─────────────────────────────────────
  if("TEXTAREA"===el.tagName){
    if(el.readOnly||el.disabled)return;
    el.focus();
    // Small delay to let React settle after focus
    await new Promise(r=>setTimeout(r,50));

    // Reset React's internal value tracker so it detects the upcoming change.
    // Without this, React compares the new DOM value against its cached "last
    // known value", sees no diff, and silently ignores the input event.
    const tracker=el._valueTracker;
    if(tracker) tracker.setValue('');

    // Set value via native React prototype setter
    const textareaSetter=Object.getOwnPropertyDescriptor(window.HTMLTextAreaElement.prototype,"value")?.set;
    if(textareaSetter){
      textareaSetter.call(el,value);
    } else {
      el.value=value;
    }

    // Dispatch InputEvent (not generic Event) — React 18 requires InputEvent
    // to properly trigger its synthetic onChange and update component state.
    el.dispatchEvent(new InputEvent("input",{bubbles:true,cancelable:true}));
    el.dispatchEvent(new Event("change",{bubbles:true}));
    el.dispatchEvent(new Event("blur",{bubbles:true}));
    await new Promise(r=>setTimeout(r,100));
    return;
  }

  // ── Plain text input ───────────────────────────────────────────────────────
  if(el.readOnly||el.disabled)return;
  el.focus();
  const inputSetter=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value")?.set;
  if(inputSetter){
    inputSetter.call(el,value);
  } else {
    setNativeValue(el,value);
  }
  el.dispatchEvent(new Event("input",{bubbles:true}));
  el.dispatchEvent(new Event("change",{bubbles:true}));
  el.dispatchEvent(new Event("blur",{bubbles:true}));
}

// ── Field Label Extractor ─────────────────────────────────────────────────────
function getFieldLabel(el){
  if(el.id){
    const lbl=document.querySelector('label[for="'+CSS.escape(el.id)+'"]');
    if(lbl)return lbl.innerText.trim().replace(/\s*\*\s*$/,"").trim();
  }
  const ariaLabelledBy=el.getAttribute("aria-labelledby");
  if(ariaLabelledBy){
    const lbl=document.getElementById(ariaLabelledBy);
    if(lbl)return lbl.innerText.trim().replace(/\s*\*\s*$/,"").trim();
  }
  const ariaLabel=el.getAttribute("aria-label");
  if(ariaLabel)return ariaLabel.replace(/\s*\*\s*$/,"").trim();
  if(el.placeholder)return el.placeholder;
  const fc=el.closest(".MuiFormControl-root");
  if(fc){
    const lbl=fc.querySelector(".MuiFormLabel-root,.MuiInputLabel-root,label");
    if(lbl)return lbl.innerText.trim().replace(/\s*\*\s*$/,"").trim();
  }
  return el.id||el.name||"";
}

// ── Form Scanner ──────────────────────────────────────────────────────────────
function scanFormFields(){
  const fields=[];
  const seen=new Set();

  // 1. Standard inputs, textareas, native selects
  const inputs=document.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]):not([type="submit"]):not([type="button"]),textarea,select');
  for(const el of inputs){
    if(!el.offsetParent)continue;
    if(el.disabled)continue;
    // Use correct tag name for selector (textarea vs input)
    const tag=el.tagName.toLowerCase();
    const sel=el.id?(tag+'[id="'+el.id+'"]'):(typeof getStableSelector==="function"?getStableSelector(el):null);
    if(!sel||seen.has(sel))continue;
    seen.add(sel);
    const label=getFieldLabel(el);
    if(!label&&!el.id)continue;
    const dd=isDropdown(el);
    fields.push({
      selector:sel,
      label:label||el.id||el.name||sel,
      type:dd?"dropdown":(el.tagName==="TEXTAREA"?"textarea":"text"),
      id:el.id||""
    });
  }

  // 2. MUI Select dropdowns (render as divs, not inputs)
  const formControls=document.querySelectorAll(".MuiFormControl-root");
  for(const fc of formControls){
    const btn=fc.querySelector('div[role="button"][aria-haspopup="listbox"],div.MuiSelect-select[role="button"]');
    if(!btn||!btn.offsetParent)continue;
    const lbl=fc.querySelector(".MuiFormLabel-root,.MuiInputLabel-root,label");
    if(!lbl)continue;
    const labelText=lbl.innerText.trim().replace(/\s*\*\s*$/,"").trim();
    if(!labelText)continue;
    const sel="MUISELECT:"+labelText;
    if(seen.has(sel))continue;
    seen.add(sel);
    const currentVal=btn.innerText.trim().replace(/^Select$/i,"");
    const fieldObj={selector:sel,label:labelText,type:"select",id:"",value:currentVal||""};
    // Known static options
    if(/gst/i.test(labelText)) fieldObj.options=["5%","12%","18%"];
    else if(/shelf|best before/i.test(labelText)) fieldObj.options=["3 Months","6 Months","12 Months","18 Months","24 Months","36 Months"];
    else if(/country/i.test(labelText)) fieldObj.options=["India","China","USA","Other"];
    else if(/net quantity/i.test(labelText)) fieldObj.options=["1","2","3","4","5","6"];
    else if(/^size$/i.test(labelText)) fieldObj.options=["Free Size","XS","S","M","L","XL","XXL","XXXL"];
    fields.push(fieldObj);
  }

  return fields;
}

// ── Deep Scan: click each dropdown and capture ALL live options ───────────────
async function deepScanFormFields(){
  // First do regular scan
  const fields = scanFormFields();

  // Find all MUI dropdowns that still have no options or unknown options
  const formControls = document.querySelectorAll(".MuiFormControl-root");
  const knownLabels = /gst|shelf|best before|country|net quantity|^size$/i;

  for(const fc of formControls){
    const btn = fc.querySelector('div[role="button"][aria-haspopup="listbox"],div.MuiSelect-select[role="button"]');
    if(!btn || !btn.offsetParent) continue;
    const lbl = fc.querySelector(".MuiFormLabel-root,.MuiInputLabel-root,label");
    if(!lbl) continue;
    const labelText = lbl.innerText.trim().replace(/\s*\*\s*$/, "").trim();
    if(!labelText || knownLabels.test(labelText)) continue;

    // Find this field in fields array
    const fieldIdx = fields.findIndex(f => f.label === labelText && f.type === "select");
    if(fieldIdx < 0) continue;

    try {
      // Click to open dropdown
      btn.click();
      await new Promise(r => setTimeout(r, 350));

      // Collect options from open dropdown
      const optionSelectors = [
        'li[role="option"]',
        '.MuiMenuItem-root:not(:has(input))',
        'ul[role="listbox"] li',
        '.MuiMenu-list li',
        '.MuiPaper-root li'
      ];
      let opts = [];
      for(const sel of optionSelectors){
        const items = document.querySelectorAll(sel);
        if(items.length > 0){
          opts = Array.from(items)
            .map(el => el.innerText.trim())
            .filter(t => t && t !== "Select" && t.length < 60);
          if(opts.length > 0) break;
        }
      }

      // Close dropdown by pressing Escape
      document.dispatchEvent(new KeyboardEvent("keydown", {key:"Escape",bubbles:true}));
      await new Promise(r => setTimeout(r, 200));

      if(opts.length > 0){
        fields[fieldIdx].options = opts;
      }
    } catch(e) {
      // Skip on error, continue with next
    }
  }

  return fields;
}

// ── Autofill Profile ──────────────────────────────────────────────────────────
async function autofillProfile(data){
  if(!data||!data.fields)return;
  if(isAutofilling){showToast("Autofill already running!",true);return;}
  const forceAutofill=data.force||false;
  isAutofilling=true;shouldStopAutofill=false;
  showStopAutofillButton();

  // Check "Copy price to all sizes" checkbox
  let copyPriceChecked=false;
  try{
    const copyEl=Array.from(document.querySelectorAll("p,span,div")).find(e=>e.innerText&&e.innerText.trim()==="Copy price details to all sizes");
    if(copyEl){
      const parent=copyEl.closest(".MuiBox-root")||copyEl.parentElement;
      if(parent){const cb=parent.querySelector('input[type="checkbox"]');if(cb&&cb.checked)copyPriceChecked=true;}
    }
  }catch(e){}

  const dedupeIds=["meesho_price","only_wrong_return_price","product_mrp","inventory","supplier_gst_percent","hsn_code","product_weight_in_gms","supplier_product_id","product_name","color"];
  const filledIds=new Set();
  let filled=0,skipped=0;

  for(const field of data.fields){
    if(shouldStopAutofill){showToast(`STOPPED! Filled: ${filled}, Skipped: ${skipped}`);break;}

    const sel=field.selector;
    const val=String(field.value||"").trim();
    if(!val)continue;

    // Extract ID from selector for deduplication
    let fieldId=null;
    const idMatch=sel.match(/id=["']([^"']+)["']/)||sel.match(/#([a-zA-Z0-9_-]+)/);
    if(idMatch)fieldId=idMatch[1];

    let el=null;

    if(fieldId&&dedupeIds.includes(fieldId)){
      if(filledIds.has(fieldId)){skipped++;continue;}
      if(sel.startsWith("SIZE:")){
        const m=sel.match(/^SIZE:(.+?)::(.+)$/);
        if(m){el=parseAndQuerySelector(m[2])||await waitForElement(m[2]);if(el)filledIds.add(fieldId);}
      } else if(["meesho_price","only_wrong_return_price","product_mrp"].includes(fieldId)){
        // Fill ALL variant rows — try multiple row selectors (Meesho changes classes)
        const rowSelectors = [".css-1hw3sau", ".css-1d3bbye", ".css-46bh2p", "[class*='variantRow']", "[class*='VariantRow']"];
        let allRows = [];
        for(const rs of rowSelectors){
          const found = document.querySelectorAll(rs);
          if(found.length > 0){ allRows = Array.from(found); break; }
        }
        // Fallback: find rows by looking for input with this ID and going to parent
        if(allRows.length === 0){
          const allInputs = document.querySelectorAll(`input[id="${fieldId}"]`);
          allRows = Array.from(allInputs).map(inp => inp.closest("tr,li,[class*='row'],[class*='Row']")).filter(Boolean);
        }
        if(allRows.length > 0){
          filledIds.add(fieldId);
          for(const row of allRows){
            const rowEl = row.querySelector ? (row.id === fieldId ? row : row.querySelector(`input[id="${fieldId}"]`)) : null;
            const targetEl = rowEl || (allRows.length === 1 && allRows[0].id === fieldId ? allRows[0] : null);
            // If allRows are actual input elements (from fallback)
            const inputEl = row.tagName === "INPUT" ? row : row.querySelector(`input[id="${fieldId}"]`);
            if(inputEl){
              const cur=(inputEl.value||"").trim();
              if(cur!==val){
                try{ await fillField(inputEl,val); showFillEffect(inputEl); filled++; await new Promise(r=>setTimeout(r,150)); }catch(e){}
              }
            }
          }
          continue;
        } else {
          el=parseAndQuerySelector(sel)||await waitForElement(sel);
          if(el)filledIds.add(fieldId);
        }
      } else {
        el=parseAndQuerySelector(sel)||await waitForElement(sel);
        if(el)filledIds.add(fieldId);
      }
    } else {
      el=parseAndQuerySelector(sel)||await waitForElement(sel);
    }

    if(el){
      const currentVal=(el.value||el.innerText||"").trim();
      if(currentVal===val){showSkipEffect(el);skipped++;await new Promise(r=>setTimeout(r,100));continue;}
      if(currentVal&&!isDropdown(el)&&"SELECT"!==el.tagName&&!forceAutofill){showSkipEffect(el);skipped++;await new Promise(r=>setTimeout(r,100));continue;}
      try{
        await fillField(el,val);
        showFillEffect(el);
        filled++;
        await new Promise(r=>setTimeout(r,200));
      }catch(e){console.error("fillField error:",e);}
    } else {
      showNotFoundEffect(sel);
      skipped++;
    }
  }

  // Size table: copy the first size row (inventory, chest / length / shoulder size, etc.) to every other size
  if(!shouldStopAutofill){
    try{ const n=await copyFirstSizeRowToAll(); if(n){ filled+=n; showToast(`📏 ${n} size fields copy ho gaye (sab sizes)`);} }catch(e){console.log("copyFirstSizeRowToAll:",e);}
  }
  if(!shouldStopAutofill)showToast(`Done! Filled: ${filled}, Skipped: ${skipped}`);
  isAutofilling=false;shouldStopAutofill=false;
  hideStopAutofillButton();

  // Auto-tick "Same as Manufacturer Details" — try 3 times with increasing delays
  setTimeout(()=>tickSameAsMfrCheckbox(), 600);
  setTimeout(()=>tickSameAsMfrCheckbox(), 1800);
  setTimeout(()=>tickSameAsMfrCheckbox(), 3500);
}

// ── Size table: first row → all rows ───────────────────────────────────────────
function sizeRowCells(row){
  // inputs + MUI selects in visual (DOM) order; SKU / product id stays unique per size
  const cells=[];
  row.querySelectorAll('input:not([type="hidden"]):not([type="checkbox"]):not([type="radio"]),div[role="button"][aria-haspopup="listbox"],div.MuiSelect-select[role="button"],div[role="combobox"].MuiSelect-select').forEach(el=>{
    if(el.tagName==="INPUT"&&el.closest(".MuiSelect-root,.MuiInputBase-root")?.querySelector('div[role="button"],div[role="combobox"]'))return; // hidden native input of an MUI select
    if(cells.includes(el))return;
    const key=((el.id||"")+" "+(el.name||"")+" "+(el.placeholder||"")+" "+(el.getAttribute("aria-label")||"")).toLowerCase();
    el._kwSkip=/sku|product_id|supplier_product|style code/.test(key);
    cells.push(el);
  });
  return cells;
}
function cellValue(el){
  if(el.tagName==="INPUT"||el.tagName==="TEXTAREA")return (el.value||"").trim();
  const t=(el.innerText||"").trim();
  return /^select$/i.test(t)?"":t;
}
function findSizeRows(){
  const anchorSels=['input[id="meesho_price"]','input[id="inventory"]','input[id="only_wrong_return_price"]','input[id="product_mrp"]'];
  for(const sel of anchorSels){
    const anchors=Array.from(document.querySelectorAll(sel)).filter(e=>e.offsetParent);
    if(anchors.length<2)continue;
    // row = highest ancestor of an anchor that still contains only ONE anchor
    const rowOf=a=>{let r=a;while(r.parentElement&&r.parentElement.querySelectorAll(sel).length===1)r=r.parentElement;return r;};
    const rows=anchors.map(rowOf);
    if(new Set(rows).size===rows.length)return rows;
  }
  return [];
}
async function copyFirstSizeRowToAll(){
  const rows=findSizeRows();
  if(rows.length<2)return 0;
  const first=sizeRowCells(rows[0]);
  let n=0;
  for(let r=1;r<rows.length;r++){
    if(shouldStopAutofill)break;
    const cells=sizeRowCells(rows[r]);
    for(let i=0;i<Math.min(first.length,cells.length);i++){
      const src=first[i],dst=cells[i];
      if(src._kwSkip||dst._kwSkip)continue;
      const v=cellValue(src);
      if(!v||cellValue(dst)===v)continue;
      if(cellValue(dst)&&dst.tagName==="INPUT")continue;   // don't overwrite something the seller typed for this size
      try{
        dst.scrollIntoView({behavior:"instant",block:"center",inline:"center"});
        await fillField(dst,v);
        showFillEffect(dst);
        n++;
        await new Promise(res=>setTimeout(res,dst.tagName==="INPUT"?120:250));
      }catch(e){}
    }
  }
  return n;
}

// ── Auto-tick "Same as Manufacturer" checkbox ─────────────────────────────────
function tickSameAsMfrCheckbox(){
  try {
    // Method 1: Direct MuiFormControlLabel with "same" text
    const ctrls = document.querySelectorAll('.MuiFormControlLabel-root');
    for(const ctrl of ctrls){
      const txt = (ctrl.innerText||"").toLowerCase();
      if(txt.includes("same")){
        const cb = ctrl.querySelector('input[type="checkbox"]');
        if(cb && !cb.checked){
          cb.click();
          showToast("✅ Same as Manufacturer ticked!");
          return true;
        }
        if(cb && cb.checked) return true; // already ticked
      }
    }

    // Method 2: Any label/span with "same as manufacturer"
    const allEls = document.querySelectorAll("span, label, p");
    for(const el of allEls){
      const txt = (el.innerText||"").trim().toLowerCase();
      if(txt.includes("same as manufacturer")){
        const parent = el.closest(".MuiFormControlLabel-root,.MuiCheckbox-root") || el.parentElement;
        if(parent){
          const cb = parent.querySelector('input[type="checkbox"]') ||
                     parent.previousElementSibling?.querySelector('input[type="checkbox"]');
          if(cb && !cb.checked){ cb.click(); showToast("✅ Same as Manufacturer ticked!"); return true; }
        }
      }
    }
  } catch(e){ console.log("tickSameAsMfr:", e); }
  return false;
}

// ── Init ──────────────────────────────────────────────────────────────────────
if(isValidDomain())initVisualEffectStyles();

chrome.runtime.onMessage.addListener((msg,sender,respond)=>{
  if(msg.action==="PING"){respond({ready:true});return true;}
  if(msg.action==="SCAN_FORM"){respond({success:true,fields:scanFormFields()});return true;}
  if(msg.action==="DEEP_SCAN"){
    deepScanFormFields().then(fields=>respond({success:true,fields})).catch(e=>respond({success:false,error:e.message}));
    return true;
  }
  if(msg.action==="START_CAPTURE"){startCaptureMode(msg.profileId);respond({success:true});return true;}
  if(msg.action==="STOP_CAPTURE"){stopCaptureMode();respond({success:true});return true;}
  if(msg.action==="AUTOFILL"||msg.action==="AUTOFILL_FIELDS"){
    stopCaptureMode();
    const d=msg.data||{fields:msg.fields,force:true};
    autofillProfile(d);respond({success:true});return true;
  }
});

document.addEventListener("keydown",e=>{if(e.key==="Escape"&&isCaptureMode)stopCaptureMode();});

document.addEventListener("mouseover",e=>{
  if(!isCaptureMode)return;
  const t=e.target;
  if(["INPUT","TEXTAREA","SELECT"].includes(t.tagName)){
    const r=t.getBoundingClientRect();
    if(highlightOverlay){
      highlightOverlay.style.width=r.width+"px";
      highlightOverlay.style.height=r.height+"px";
      highlightOverlay.style.top=(window.scrollY+r.top)+"px";
      highlightOverlay.style.left=(window.scrollX+r.left)+"px";
      highlightOverlay.style.display="block";
    }
  } else hideOverlay();
});

document.addEventListener("click",async e=>{
  if(!isCaptureMode)return;
  const t=e.target;
  if(["INPUT","TEXTAREA","SELECT"].includes(t.tagName)){
    e.preventDefault();e.stopPropagation();
    const sel=typeof getStableSelector==="function"?getStableSelector(t):null;
    if(!sel){showToast("Error: Selector util not loaded",true);return;}
    const val=t.value;
    const newVal=prompt(`Save field: ${sel}\nValue:`,val);
    if(newVal!==null){
      chrome.runtime.sendMessage({action:"SAVE_FIELD",payload:{profileId:currentProfileId,field:{selector:sel,type:t.type||t.tagName.toLowerCase(),value:newVal}}},(res)=>{
        showToast(res&&res.success?"Field Saved!":"Error Saving");
      });
    }
  }
},true);

initializeUI();

// ============================================
// KIWTECH SHIPPING OPTIMIZER - Merged Module
// ============================================
// Meesho API Integration v7.0.0 - Enhanced Variation & Shipping Logic

const MeeshoAPI = {
  _initialized: false,
  endpoints: {
    // Meesho routes are in flux: prefer /api/cataloging/* and fallback to older /catalogingapi/api/*
    uploadImage:
      "https://supplier.meesho.com/api/cataloging/singleCatalogUpload/uploadSingleCatalogImages",
    uploadImageFallback:
      "https://supplier.meesho.com/catalogingapi/api/singleCatalogUpload/uploadSingleCatalogImages",
    fetchDuplicatePid:
      "https://supplier.meesho.com/api/cataloging/priceRecommendation/fetchDuplicatePid",
    getTransferPrice:
      "https://supplier.meesho.com/api/cataloging/singleCatalogUpload/getTransferPrice",
    // Meesho currently serves this endpoint under /api/cataloging (the /catalogingapi/* path often returns 463)
    fetchCategories:
      "https://supplier.meesho.com/api/cataloging/bulkCatalogUpload/fetchCategoryTreeOld",
  },

  cache: {
    supplierId: null,
    supplierTag: null,
    categoryId: null,
    browserId: null,
    price: 100,
    categories: null,
  },

  badgeCache: {},

  // Track shipping results
  shippingHistory: new Map(),

  init: function () {
    if (this._initialized) return;
    this._initialized = true;
    this.interceptNetwork(); // Capture sscat_id from page's own API calls
    this.detectAllValues();
    // Always try fetchCategories - even without supplierId it may work
    this.fetchCategories().catch(() => {});
    console.log("📦 MeeshoAPI v7.0 initialized, cache:", JSON.stringify(this.cache));
  },

  detectAllValues: function () {
    this.cache.browserId = this.getCookie("browser_id") || "";
    const urlMatch = window.location.href.match(/\/cataloging\/([^\/]+)/);
    if (urlMatch) this.cache.supplierTag = urlMatch[1];
    this.cache.supplierId = this.detectSupplierId();
    this.cache.categoryId = this.detectCategoryId();
    this.cache.price = this.detectPrice();
    console.log("🔍 Auto-detected:", this.cache);
  },

  getCookie: function (name) {
    const match = document.cookie.match(
      new RegExp("(^| )" + name + "=([^;]+)"),
    );
    return match ? decodeURIComponent(match[2]) : "";
  },

  detectSupplierId: function () {
    try {
      const mpCookie = this.getCookie(
        "mp_a66867feba42257f4b46689d52d48f86_mixpanel",
      );
      if (mpCookie) {
        const decoded = JSON.parse(mpCookie);
        if (decoded.Supplier_id) {
          console.log("✅ Supplier ID from cookie:", decoded.Supplier_id);
          return decoded.Supplier_id;
        }
      }
    } catch (e) {}
    return null;
  },

  detectCategoryId: function () {
    // Method 1: Already cached
    if (this.cache.categoryId) return this.cache.categoryId;

    // Method 2: Try React fiber on category-related elements
    const tryReactFiber = (el) => {
      if (!el) return null;
      const fiberKey = Object.keys(el).find(k => k.startsWith('__reactFiber') || k.startsWith('__reactInternalInstance'));
      if (!fiberKey) return null;
      let fiber = el[fiberKey];
      let depth = 0;
      while (fiber && depth < 40) {
        const props = fiber.memoizedProps || fiber.pendingProps;
        if (props) {
          if (props.sscatId) return parseInt(props.sscatId);
          if (props.categoryId) return parseInt(props.categoryId);
          if (props.sscat_id) return parseInt(props.sscat_id);
          // Check in nested data
          if (props.data && props.data.sscat_id) return parseInt(props.data.sscat_id);
          if (props.catalogData && props.catalogData.sscat_id) return parseInt(props.catalogData.sscat_id);
        }
        const state = fiber.memoizedState;
        if (state && state.memoizedState) {
          const s = state.memoizedState;
          if (s && s.sscat_id) return parseInt(s.sscat_id);
        }
        fiber = fiber.return;
        depth++;
      }
      return null;
    };

    // Method 3: Look in Redux/window store
    try {
      if (window.__REDUX_STORE__) {
        const state = window.__REDUX_STORE__.getState();
        const sscat = state?.catalog?.sscat_id || state?.listing?.sscat_id;
        if (sscat) return parseInt(sscat);
      }
    } catch(e) {}

    // Method 4: Scan all React roots for sscat_id in component state
    try {
      const allEls = document.querySelectorAll('[class*="MuiFormControl"], [class*="category"], form, [data-testid]');
      for (const el of allEls) {
        const id = tryReactFiber(el);
        if (id && id > 100) return id;
      }
    } catch(e) {}

    // Method 5: Scan page text for category hint
    try {
      const scripts = document.querySelectorAll('script:not([src])');
      for (const s of scripts) {
        const m = s.textContent.match(/"sscat_id"\s*:\s*(\d+)/);
        if (m) return parseInt(m[1]);
      }
    } catch(e) {}

    // Method 6: Network request intercept - check __meesho_sscat_id set by our interceptor
    if (window.__meesho_sscat_id) return window.__meesho_sscat_id;

    // Default: common category IDs to try (kurti/clothing = most common)
    return null;
  },

  detectPrice: function () {
    const inputs = document.querySelectorAll("input");
    for (const inp of inputs) {
      const name = (inp.name || "").toLowerCase();
      if (
        (name.includes("price") || name === "mrp") &&
        inp.value &&
        parseInt(inp.value) > 0
      ) {
        return parseInt(inp.value);
      }
    }
    return 100;
  },

  setCategory: function (id) {
    this.cache.categoryId = parseInt(id);
    console.log("📁 Category set to:", id);
  },

  getHeaders: function () {
    return {
      accept: "application/json, text/plain, */*",
      "content-type": "application/json;charset=UTF-8",
      "client-type": "d-web",
      "client-package-version": "1.0.1",
      "browser-id": this.cache.browserId || "",
      identifier: this.cache.supplierTag || "",
      "supplier-id": this.cache.supplierId ? String(this.cache.supplierId) : "",
    };
  },

  fetchCategories: async function () {
    if (this.cache.categories) return this.cache.categories;
    try {
      const resp = await fetch(this.endpoints.fetchCategories, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify({
          bulk_upload_enabled: false,
          supplier_id: this.cache.supplierId,
          identifier: this.cache.supplierTag,
        }),
        credentials: "include",
      });
      if (!resp.ok) {
        console.warn(
          "⚠️ fetchCategories failed:",
          resp.status,
          resp.statusText,
        );
        return null;
      }
      const result = await resp.json();
      if (result.items?.length > 0) {
        const subCat = result.items.find((i) => i.type === "sub-sub-category");
        if (subCat?.data) {
          this.cache.categories = subCat.data.map((c) => ({
            id: parseInt(c.id),
            name: c.name,
            parentName: c.parent_name,
          }));
          // DO NOT auto-pick first category — user MUST select correct one
          // (auto-picking gives wrong sscat_id, breaks PID matching, gives fake low prices)
          console.log("✅ Categories loaded:", this.cache.categories.length);
          return this.cache.categories;
        }
      }
      // Try alternate response format
      if (result.data && result.data.sscat_id) {
        this.cache.categoryId = result.data.sscat_id;
      }
    } catch (e) {
      console.error("Categories error:", e);
    }
    return null;
  },

  getCategories: function () {
    return this.cache.categories || [];
  },

  uploadImage: async function (blob, filename) {
    const formData = new FormData();
    formData.append("file", blob, filename || "img-" + Date.now() + ".jpg");
    formData.append("data", "undefined");
    try {
      const resp = await fetch(this.endpoints.uploadImage, {
        method: "POST",
        headers: {
          accept: "application/json, text/plain, */*",
          "browser-id": this.cache.browserId || "",
          "client-type": "d-web",
          "client-package-version": "1.0.1",
          identifier: this.cache.supplierTag || "",
          "supplier-id": this.cache.supplierId
            ? String(this.cache.supplierId)
            : "",
        },
        body: formData,
        credentials: "include",
      });
      if (!resp.ok) return null;
      const result = await resp.json();
      console.log("📤 Image uploaded:", result.image);
      return result.image;
    } catch (e) {
      console.error("Upload error:", e);
      return null;
    }
  },

  fetchDuplicatePid: async function (imageUrl, categoryId) {
    const sscatId = categoryId || this.cache.categoryId || 18044;
    try {
      const resp = await fetch(this.endpoints.fetchDuplicatePid, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify({
          is_old_image_match_enabled: true,
          sscat_id: sscatId,
          image_url: imageUrl,
        }),
        credentials: "include",
      });
      if (!resp.ok) return null;
      const result = await resp.json();
      console.log("🔍 Duplicate PID:", result.data?.duplicate_pid);
      return result.data?.duplicate_pid || null;
    } catch (e) {
      return null;
    }
  },

  getShippingCharges: async function (imageUrl) {
    const supplierId = this.cache.supplierId;
    const price = this.cache.price || 100;

    // Category MUST be set — no more guessing/fallback that gave fake prices
    const sscatId = this.cache.categoryId || window.__meesho_sscat_id;
    if (!sscatId) {
      console.warn("⚠️ No category set — skipping. Select category in UI first.");
      return null;
    }

    // Try to get PID match for this category
    let duplicatePid = null;
    if (imageUrl) {
      duplicatePid = await this.fetchDuplicatePid(imageUrl, sscatId);
    }

    try {
      const body = {
        sscat_id: sscatId,
        gst_percentage: 0,
        price: price,
        supplier_id: supplierId,
        gst_type: "GSTIN",
        image_url: imageUrl,
      };
      if (duplicatePid) body.duplicate_pid = duplicatePid;

      const resp = await fetch(this.endpoints.getTransferPrice, {
        method: "POST",
        headers: this.getHeaders(),
        body: JSON.stringify(body),
        credentials: "include",
      });

      if (!resp.ok) return null;
      const result = await resp.json();

      if (typeof result.shipping_charges === 'number' || result.shipping_charges > 0) {
        console.log(`🚚 Shipping: ₹${result.shipping_charges} cat:${sscatId}${duplicatePid?' PID:'+duplicatePid:' (no PID)'}`);
        return { shippingCharges: result.shipping_charges, duplicatePid };
      }
    } catch (e) {
      console.error("getShippingCharges error:", e);
    }

    return null;
  },

  // Intercept Meesho XHR/fetch to capture sscat_id automatically
  interceptNetwork: function() {
    if (window.__meesho_intercepted) return;
    window.__meesho_intercepted = true;

    const origFetch = window.fetch;
    window.fetch = function(url, opts) {
      if (typeof url === 'string' && url.includes('meesho.com') && opts && opts.body) {
        try {
          const body = JSON.parse(opts.body);
          if (body.sscat_id && !window.__meesho_sscat_id) {
            window.__meesho_sscat_id = body.sscat_id;
            console.log('🎯 Captured sscat_id from page:', body.sscat_id);
            if (window.MeeshoAPI) window.MeeshoAPI.cache.categoryId = body.sscat_id;
          }
        } catch(e) {}
      }
      return origFetch.apply(this, arguments);
    };

    const origXHR = window.XMLHttpRequest.prototype.open;
    window.XMLHttpRequest.prototype.open = function(method, url) {
      this._url = url;
      return origXHR.apply(this, arguments);
    };
    const origSend = window.XMLHttpRequest.prototype.send;
    window.XMLHttpRequest.prototype.send = function(body) {
      if (this._url && this._url.includes('meesho.com') && body) {
        try {
          const parsed = JSON.parse(body);
          if (parsed.sscat_id && !window.__meesho_sscat_id) {
            window.__meesho_sscat_id = parsed.sscat_id;
            if (window.MeeshoAPI) window.MeeshoAPI.cache.categoryId = parsed.sscat_id;
          }
        } catch(e) {}
      }
      return origSend.apply(this, arguments);
    };
  },

  // Smart Search - REQUIRES category to be set (for correct PID match and price)
  smartSearch: async function (
    originalBlob,
    targetShipping,
    maxAttempts,
    onProgress,
    onFound,
    shouldStopFn,
  ) {
    console.log(`🎯 Smart Search: Target ≤ ₹${targetShipping}, Max: ${maxAttempts}`);

    // Intercept network to capture sscat_id
    this.interceptNetwork();

    // Re-detect all values fresh — but DO NOT clear user-selected categoryId
    const userPickedCategory = this.cache.categoryId;
    this._initialized = false;
    this.init();
    if (userPickedCategory) this.cache.categoryId = userPickedCategory;

    // Wait a moment for interceptor to capture category from page
    await new Promise(r => setTimeout(r, 500));

    // Re-detect, but preserve user-selected category
    const savedCat = this.cache.categoryId;
    this.detectAllValues();
    if (savedCat) this.cache.categoryId = savedCat;
    console.log('🔍 MeeshoAPI cache after detect:', JSON.stringify(this.cache));

    if (!this.cache.categoryId) {
      console.warn("⚠️ No category set! Results will be unreliable.");
      return {
        success: false,
        results: [],
        bestResult: null,
        targetReached: false,
        attempts: 0,
        noPidCount: 0,
        verifiedCount: 0,
        error: "NO_CATEGORY"
      };
    }

    const results = [];
    const withPid = [];
    const withoutPid = [];
    let bestResult = null;
    let attempt = 0;
    let noPidCount = 0;

    while (attempt < maxAttempts) {
      if (shouldStopFn && shouldStopFn()) {
        console.log("⏹️ Stopped");
        break;
      }
      attempt++;
      if (onProgress)
        onProgress(attempt, maxAttempts, bestResult?.shippingCost, noPidCount);

      try {
        const variation = await this.generateVariation(originalBlob, attempt);
        const imageUrl = await this.uploadImage(variation.blob, `v${attempt}.jpg`);
        if (!imageUrl) { console.log(`[${attempt}] Upload failed`); continue; }

        const priceData = await this.getShippingCharges(imageUrl);
        if (!priceData) { console.log(`[${attempt}] No price data`); continue; }

        const pid = priceData.duplicatePid;
        const shipping = priceData.shippingCharges;

        // Accept ALL results that have a valid shipping cost
        if (typeof shipping === 'number' && shipping >= 0) {
          const result = {
            name: `Var-${attempt}`,
            dataUrl: variation.dataUrl,
            shippingCost: shipping,
            duplicatePid: pid || null,
            isVerified: !!pid,
          };

          if (pid) {
            withPid.push(result);
            console.log(`✅ [${attempt}] ₹${shipping} PID:${pid}`);
          } else {
            withoutPid.push(result);
            noPidCount++;
            console.log(`📦 [${attempt}] ₹${shipping} (no PID - still counted)`);
          }

          if (!bestResult || shipping < bestResult.shippingCost) {
            bestResult = result;
            console.log(`⭐ Best: ₹${shipping}`);
          }

          if (shipping <= targetShipping) {
            console.log(`🎉 TARGET REACHED! ₹${shipping}`);
            if (onFound) onFound(result);
            // Don't break - keep searching for better
          }
        } else {
          noPidCount++;
          console.log(`⚠️ [${attempt}] Invalid shipping value:`, shipping);
        }

        await new Promise((r) => setTimeout(r, 50));
      } catch (e) {
        console.error(`[${attempt}] Error:`, e.message);
      }
    }

    // Prioritize PID-verified results, then append non-PID
    const allResults = [
      ...withPid.sort((a, b) => a.shippingCost - b.shippingCost),
      ...withoutPid.sort((a, b) => a.shippingCost - b.shippingCost),
    ];

    return {
      success: allResults.length > 0,
      results: allResults.slice(0, 20),
      bestResult,
      targetReached: bestResult?.shippingCost <= targetShipping,
      attempts: attempt,
      noPidCount,
      verifiedCount: withPid.length,
    };
  },

  // Generate variation with random border 20-80px and badges 50-200px
  generateVariation: async function (originalBlob, seed) {
    return new Promise((resolve, reject) => {
      const img = new Image();
      img.onload = async () => {
        const w = img.width;
        const h = img.height;

        // Random border 20-80px
        const border = 20 + Math.floor(Math.random() * 60);
        const finalW = w + border * 2;
        const finalH = h + border * 2;

        const canvas = document.createElement("canvas");
        canvas.width = finalW;
        canvas.height = finalH;
        const ctx = canvas.getContext("2d");

        // Random gradient background
        const colors = [
          "#e74c3c",
          "#3498db",
          "#2ecc71",
          "#f39c12",
          "#9b59b6",
          "#1abc9c",
          "#e67e22",
          "#16a085",
          "#ff5722",
          "#673ab7",
          "#4caf50",
          "#03a9f4",
          "#e91e63",
          "#8bc34a",
          "#ff9800",
          "#00bcd4",
        ];
        const c1 = colors[Math.floor(Math.random() * colors.length)];
        const c2 = colors[Math.floor(Math.random() * colors.length)];
        const gradType = Math.floor(Math.random() * 4);

        if (gradType === 0) {
          ctx.fillStyle = c1;
        } else {
          let grad;
          if (gradType === 1) grad = ctx.createLinearGradient(0, 0, finalW, 0);
          else if (gradType === 2)
            grad = ctx.createLinearGradient(0, 0, 0, finalH);
          else grad = ctx.createLinearGradient(0, 0, finalW, finalH);
          grad.addColorStop(0, c1);
          grad.addColorStop(1, c2);
          ctx.fillStyle = grad;
        }
        ctx.fillRect(0, 0, finalW, finalH);

        // Draw image
        ctx.drawImage(img, border, border, w, h);

        // Add 2-3 badges (50-200px)
        const badgeCount = 2 + Math.floor(Math.random() * 2);
        await this.addBadges(ctx, finalW, finalH, border, badgeCount);

        // Add noise
        this.addNoise(ctx, finalW, finalH, seed);

        const quality = 0.75 + Math.random() * 0.15;

        canvas.toBlob(
          (blob) =>
            resolve({
              blob,
              dataUrl: canvas.toDataURL("image/jpeg", quality),
            }),
          "image/jpeg",
          quality,
        );
      };
      img.onerror = () => reject(new Error("Load failed"));
      img.src = URL.createObjectURL(originalBlob);
    });
  },

  // Add badges 50-200px
  addBadges: async function (ctx, w, h, border, count) {
    const positions = [
      { x: border + 5, y: border + 5 },
      { x: w - border - 150, y: border + 5 },
      { x: border + 5, y: h - border - 150 },
      { x: w - border - 150, y: h - border - 150 },
    ];

    const used = new Set();
    for (let i = 0; i < count && i < positions.length; i++) {
      let num;
      do {
        num = 1 + Math.floor(Math.random() * 25);
      } while (used.has(num));
      used.add(num);

      const size = 50 + Math.floor(Math.random() * 150); // 50-200px
      try {
        const badge = await this.loadBadge(num);
        if (badge) {
          ctx.drawImage(badge, positions[i].x, positions[i].y, size, size);
        }
      } catch (e) {}
    }
  },

  // Add noise
  addNoise: function (ctx, w, h, seed) {
    const data = ctx.getImageData(0, 0, w, h);
    const d = data.data;
    for (let i = 0; i < 50; i++) {
      const px = Math.floor(Math.random() * (d.length / 4)) * 4;
      d[px] = Math.min(
        255,
        Math.max(0, d[px] + Math.floor(Math.random() * 6) - 3),
      );
    }
    d[((Date.now() + seed) % (d.length / 4)) * 4] = seed % 256;
    ctx.putImageData(data, 0, 0);
  },

  loadBadge: async function (num) {
    if (this.badgeCache[num]) return this.badgeCache[num];
    return new Promise((resolve) => {
      const img = new Image();
      img.crossOrigin = "anonymous";
      img.onload = () => {
        this.badgeCache[num] = img;
        resolve(img);
      };
      img.onerror = () => resolve(null);
      img.src = chrome.runtime.getURL("Badge/badge" + num + ".png");
    });
  },

  isReady: function () {
    this.detectAllValues();
    return this.cache.supplierId !== null;
  },
  isValidCatalogPage: function () {
    return (
      window.location.href.includes("supplier.meesho.com") &&
      window.location.href.includes("/cataloging/")
    );
  },
};

window.MeeshoAPI = MeeshoAPI;

// === Shipping Optimizer UI + Logic ===

// ─── Shipping Optimizer UI ────────────────────────────────────────────────────

const ShippingOptimizerUI = {
  createMainHTML: function(isLicensed, shippingCost) {
    const costBadge = shippingCost ? `<div style="background:#1a1a2e;border:1px solid #ffd700;border-radius:8px;padding:8px 16px;margin:8px 0;display:inline-block;font-weight:700;font-size:15px;color:#ffd700;">Current: ₹${shippingCost}</div>` : "";
    return `
      <div style="background:linear-gradient(135deg,#1a1a2e,#16213e);border-radius:16px;padding:20px;color:#fff;font-family:'Segoe UI',sans-serif;">
        <div style="display:flex;align-items:center;justify-content:space-between;margin-bottom:16px;">
          <div>
            <h2 style="margin:0;font-size:18px;color:#ffd700;">🚚 Shipping Optimizer</h2>
            <p style="margin:4px 0 0;font-size:11px;color:#aaa;">Image variation se shipping kam karo</p>
          </div>
          <button id="opt-close" style="background:rgba(255,255,255,0.1);border:none;color:#fff;width:32px;height:32px;border-radius:50%;cursor:pointer;font-size:16px;">✕</button>
        </div>
        ${costBadge}
        <div id="opt-body">
          <!-- Category Selection -->
          <div style="margin-bottom:12px;padding:10px;background:rgba(255,215,0,0.06);border:1px solid rgba(255,215,0,0.25);border-radius:10px;">
            <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;">
              <label style="font-size:12px;color:#ffd700;font-weight:700;">📁 Category (Required)</label>
              <button id="opt-cat-refresh" style="background:rgba(255,215,0,0.15);border:none;color:#ffd700;padding:3px 8px;border-radius:4px;cursor:pointer;font-size:10px;display:none;" title="Refresh">🔄 Refresh</button>
            </div>
            <div style="position:relative;">
              <input type="text" id="opt-cat-search" placeholder="🔍 Search category..." style="width:100%;padding:8px 28px 8px 10px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:6px;color:#fff;font-size:12px;box-sizing:border-box;">
              <span id="opt-cat-clear" style="position:absolute;right:10px;top:50%;transform:translateY(-50%);cursor:pointer;color:#aaa;display:none;font-size:14px;">✕</span>
            </div>
            <div id="opt-cat-dropdown" style="display:none;max-height:180px;overflow-y:auto;background:#0f1424;border:1px solid rgba(255,255,255,0.15);border-radius:0 0 6px 6px;margin-top:2px;"></div>
            <div id="opt-cat-error" style="display:none;margin-top:6px;padding:6px;background:rgba(239,68,68,0.15);border-radius:4px;font-size:10px;color:#ef4444;">⚠️ Categories not loaded. Click 🔄 Refresh.</div>
            <div id="opt-cat-selected" style="margin-top:6px;padding:6px 8px;background:rgba(16,185,129,0.15);border-radius:4px;display:none;font-size:11px;color:#10b981;">✓ <span id="opt-cat-selected-name" style="font-weight:600;"></span></div>
            <input type="hidden" id="opt-cat-id" value="">
          </div>
          <div style="margin-bottom:12px;">
            <label style="font-size:11px;color:#aaa;display:block;margin-bottom:4px;">Target Max Shipping (₹)</label>
            <input id="opt-target" type="number" value="30" min="1" max="200" style="width:100%;padding:8px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:8px;color:#fff;font-size:14px;box-sizing:border-box;">
          </div>
          <div style="margin-bottom:12px;">
            <label style="font-size:11px;color:#aaa;display:block;margin-bottom:4px;">Max Variations to Test</label>
            <input id="opt-attempts" type="number" value="30" min="5" max="100" style="width:100%;padding:8px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:8px;color:#fff;font-size:14px;box-sizing:border-box;">
          </div>
          <div id="opt-image-area" style="border:2px dashed rgba(255,215,0,0.3);border-radius:12px;padding:20px;text-align:center;margin-bottom:12px;cursor:pointer;" onclick="document.getElementById('opt-file-input').click()">
            <div id="opt-image-preview" style="display:none;"><img id="opt-preview-img" style="max-height:100px;max-width:100%;border-radius:8px;"></div>
            <div id="opt-image-placeholder"><div style="font-size:28px;">📷</div><p style="margin:4px 0;font-size:12px;color:#aaa;">Product image select karein ya page se auto-detect</p></div>
          </div>
          <input type="file" id="opt-file-input" accept="image/*" style="display:none;">
          <button id="opt-autodetect-btn" style="width:100%;padding:10px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:8px;color:#fff;cursor:pointer;font-size:12px;margin-bottom:10px;">🔍 Page se Auto-detect Image</button>
          <button id="opt-start-btn" style="width:100%;padding:14px;background:linear-gradient(135deg,#ffd700,#c9a227);border:none;border-radius:10px;color:#000;font-weight:800;font-size:14px;cursor:pointer;">🚀 Start Optimization</button>
        </div>
        <div id="opt-processing" style="display:none;text-align:center;padding:10px 0;">
          <div id="opt-progress-text" style="font-size:14px;color:#ffd700;margin-bottom:8px;">Searching...</div>
          <div id="opt-progress-best" style="font-size:22px;font-weight:700;color:#10b981;margin-bottom:8px;"></div>
          <div style="background:rgba(255,255,255,0.1);border-radius:6px;height:8px;margin-bottom:8px;">
            <div id="opt-progress-bar" style="width:0%;background:linear-gradient(135deg,#ffd700,#c9a227);height:100%;border-radius:6px;transition:width 0.3s;"></div>
          </div>
          <div id="opt-progress-count" style="font-size:11px;color:#aaa;margin-bottom:10px;"></div>
          <button id="opt-stop-btn" style="padding:10px 24px;background:#f44;border:none;border-radius:8px;color:#fff;font-weight:700;cursor:pointer;">⏹ Stop</button>
        </div>
        <div id="opt-results" style="display:none;"></div>
      </div>
    `;
  },

  getResultsHTML: function(results) {
    const top = results.slice(0, 10);
    return `
      <div style="margin-top:12px;">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px;">
          <div style="font-size:13px;font-weight:700;color:#ffd700;">✅ Results (${results.length})</div>
          <div style="display:flex;gap:6px;">
            <button id="opt-apply-best" style="padding:6px 12px;background:linear-gradient(135deg,#10b981,#059669);border:none;border-radius:6px;color:#fff;font-size:11px;font-weight:700;cursor:pointer;">Apply Best</button>
            <button id="opt-restart" style="padding:6px 12px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:6px;color:#fff;font-size:11px;cursor:pointer;">Retry</button>
          </div>
        </div>
        ${top.map((r, i) => `
          <div style="background:${i===0?'rgba(16,185,129,0.15)':'rgba(255,255,255,0.05)'};border:1px solid ${i===0?'#10b981':'rgba(255,255,255,0.1)'};border-radius:10px;padding:10px;margin-bottom:8px;display:flex;align-items:center;gap:10px;">
            ${r.dataUrl ? `<img src="${r.dataUrl}" style="width:48px;height:48px;object-fit:cover;border-radius:6px;flex-shrink:0;">` : ''}
            <div style="flex:1;min-width:0;">
              <div style="font-size:13px;font-weight:700;color:${i===0?'#10b981':'#fff'};">${i===0?'⭐ ':''}<span style="font-size:16px;">₹${r.shippingCost}</span></div>
              <div style="font-size:10px;color:#aaa;">${r.name}${r.isVerified?' • PID verified':''}</div>
            </div>
            <div style="display:flex;flex-direction:column;gap:4px;">
              <button class="opt-apply-btn" data-i="${i}" style="padding:5px 10px;background:linear-gradient(135deg,#667eea,#764ba2);border:none;border-radius:6px;color:#fff;font-size:10px;font-weight:700;cursor:pointer;">Apply</button>
              <button class="opt-dl-btn" data-i="${i}" style="padding:5px 10px;background:rgba(255,255,255,0.1);border:1px solid rgba(255,255,255,0.2);border-radius:6px;color:#fff;font-size:10px;cursor:pointer;">Save</button>
            </div>
          </div>
        `).join('')}
      </div>
    `;
  }
};

// ─── Shipping Optimizer Controller ───────────────────────────────────────────

class KiwtechShippingOptimizer {
  constructor() {
    this.modal = null;
    this.results = [];
    this.shouldStop = false;
    this.originalBlob = null;
    this.isProcessing = false;
    this.currentShipping = null;
    this.init();
  }

  init() {
    chrome.runtime.onMessage.addListener((msg, sender, respond) => {
      if (msg.action === "OPEN_SHIPPING_OPTIMIZER") {
        this.openModal();
        respond({ success: true });
      }
    });

    // Add floating button on catalog pages
    if (window.location.href.includes("supplier.meesho.com")) {
      setTimeout(() => this.addFloatingButton(), 2000);
    }
  }

  addFloatingButton() {
    if (document.getElementById("kwt-shipping-fab")) return;
    const fab = document.createElement("button");
    fab.id = "kwt-shipping-fab";
    fab.innerHTML = "🚚";
    fab.title = "Kiwtech Shipping Optimizer";
    fab.style.cssText = "position:fixed;right:18px;bottom:80px;z-index:2147483640;background:linear-gradient(135deg,#ffd700,#c9a227);color:#000;border:none;width:48px;height:48px;border-radius:50%;font-size:20px;cursor:pointer;box-shadow:0 4px 15px rgba(0,0,0,0.3);";
    fab.onclick = () => this.openModal();
    document.documentElement.appendChild(fab);
  }

  detectShipping() {
    const selectors = [
      "p.MuiTypography-root.MuiTypography-body1.css-v40lxd",
      '[class*="css-v40lxd"]',
      '[class*="shipping"] span',
      ".MuiTypography-body1",
      ".MuiTypography-root",
    ];
    for (const sel of selectors) {
      try {
        const els = document.querySelectorAll(sel);
        for (const el of els) {
          const txt = el.textContent || "";
          if ((txt.toLowerCase().includes("shipping") || txt.toLowerCase().includes("delivery")) && txt.includes("₹")) {
            const m = txt.match(/₹\s*(\d+)/);
            if (m) { const cost = parseInt(m[1]); if (cost > 0 && cost < 2000) return cost; }
          }
        }
      } catch (e) {}
    }
    return null;
  }

  async autoDetectImage() {
    const imageInput = document.querySelector("#changeFrontImage");
    if (!imageInput?.files?.[0]) {
      // Try to get current displayed product image
      const imgEls = document.querySelectorAll("img[src*='meesho'], img[src*='cloudinary'], img[src*='cdn']");
      for (const img of imgEls) {
        if (img.naturalWidth > 100) {
          try {
            const canvas = document.createElement("canvas");
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            canvas.getContext("2d").drawImage(img, 0, 0);
            const blob = await new Promise(r => canvas.toBlob(r, "image/jpeg", 0.9));
            if (blob) return blob;
          } catch (e) {}
        }
      }
      return null;
    }
    return imageInput.files[0];
  }

  openModal() {
    if (this.modal) this.modal.remove();
    this.currentShipping = this.detectShipping();

    const overlay = document.createElement("div");
    overlay.id = "kwt-opt-overlay";
    overlay.style.cssText = "position:fixed;top:0;left:0;width:100%;height:100%;background:rgba(0,0,0,0.8);z-index:2147483647;display:flex;justify-content:center;align-items:center;backdrop-filter:blur(4px);";

    const wrap = document.createElement("div");
    wrap.style.cssText = "width:360px;max-height:90vh;overflow-y:auto;";
    wrap.innerHTML = ShippingOptimizerUI.createMainHTML(true, this.currentShipping);

    overlay.appendChild(wrap);
    document.body.appendChild(overlay);
    this.modal = overlay;

    overlay.onclick = (e) => { if (e.target === overlay) overlay.remove(); };
    document.getElementById("opt-close").onclick = () => overlay.remove();

    // Load category dropdown
    this.loadCategoryDropdown();

    // File input
    const fileInput = document.getElementById("opt-file-input");
    fileInput.onchange = (e) => {
      const file = e.target.files[0];
      if (file) {
        this.originalBlob = file;
        const url = URL.createObjectURL(file);
        document.getElementById("opt-preview-img").src = url;
        document.getElementById("opt-image-preview").style.display = "block";
        document.getElementById("opt-image-placeholder").style.display = "none";
      }
    };

    // Autodetect
    document.getElementById("opt-autodetect-btn").onclick = async () => {
      const btn = document.getElementById("opt-autodetect-btn");
      btn.textContent = "⏳ Detecting...";
      const blob = await this.autoDetectImage();
      if (blob) {
        this.originalBlob = blob;
        const url = URL.createObjectURL(blob);
        document.getElementById("opt-preview-img").src = url;
        document.getElementById("opt-image-preview").style.display = "block";
        document.getElementById("opt-image-placeholder").style.display = "none";
        btn.textContent = "✅ Image Detected!";
      } else {
        btn.textContent = "❌ Not Found - Manual select karein";
      }
    };

    // Start
    document.getElementById("opt-start-btn").onclick = () => this.startOptimization();
  }

  async startOptimization() {
    // Require category selected (this is what fixes the wrong price issue)
    const catId = document.getElementById("opt-cat-id")?.value;
    if (!catId) {
      alert("Pehle category select karein! Bina sahi category ke shipping price galat aayega.");
      return;
    }
    MeeshoAPI.init();
    MeeshoAPI.setCategory(parseInt(catId));

    if (!this.originalBlob) {
      alert("Pehle image select karein ya auto-detect karein");
      return;
    }
    if (this.isProcessing) return;

    const target = parseInt(document.getElementById("opt-target").value) || 30;
    const maxAttempts = parseInt(document.getElementById("opt-attempts").value) || 30;

    document.getElementById("opt-body").style.display = "none";
    document.getElementById("opt-processing").style.display = "block";

    this.results = [];
    this.shouldStop = false;
    this.isProcessing = true;

    document.getElementById("opt-stop-btn").onclick = () => {
      this.shouldStop = true;
      this.isProcessing = false;
    };

    MeeshoAPI.init();

    const result = await MeeshoAPI.smartSearch(
      this.originalBlob,
      target,
      maxAttempts,
      (attempt, total, best, noPid) => {
        const pct = Math.round((attempt / total) * 100);
        const el = document.getElementById("opt-progress-bar");
        if (el) el.style.width = pct + "%";
        const txt = document.getElementById("opt-progress-text");
        if (txt) txt.textContent = `Testing variation ${attempt}/${total}...`;
        const count = document.getElementById("opt-progress-count");
        if (count) count.textContent = `${noPid} skipped (no PID)`;
        if (best) {
          const bestEl = document.getElementById("opt-progress-best");
          if (bestEl) bestEl.textContent = `Best: ₹${best}`;
        }
      },
      (found) => {
        // target reached
      },
      () => this.shouldStop
    );

    this.isProcessing = false;
    this.results = result.results || [];
    document.getElementById("opt-processing").style.display = "none";

    if (result.error === "NO_CATEGORY") {
      document.getElementById("opt-body").style.display = "block";
      showToast("Pehle category select karein!", true);
      return;
    }

    if (this.results.length > 0) {
      // Warn user if NO PID-verified results (price won't match actual page)
      const hasVerified = this.results.some(r => r.isVerified);
      const resultsEl = document.getElementById("opt-results");
      resultsEl.style.display = "block";
      let warning = "";
      if (!hasVerified) {
        warning = `
          <div style="background:rgba(239,68,68,0.15);border:1px solid #ef4444;border-radius:8px;padding:8px 10px;margin-bottom:10px;font-size:11px;color:#ef4444;">
            ⚠️ <b>No PID-verified results.</b> Ye prices reliable nahi hain — Meesho apply karne par actual price alag aa sakta hai. Sahi category select hai? Different image try karein.
          </div>`;
      }
      resultsEl.innerHTML = warning + ShippingOptimizerUI.getResultsHTML(this.results);
      this.setupResultEvents();
    } else {
      document.getElementById("opt-body").style.display = "block";
      showToast("No results — page pe Meesho catalog form open karein", true);
    }
  }

  setupResultEvents() {
    document.querySelectorAll(".opt-apply-btn").forEach(btn => {
      btn.onclick = () => this.applyImage(this.results[parseInt(btn.dataset.i)]);
    });
    document.querySelectorAll(".opt-dl-btn").forEach(btn => {
      btn.onclick = () => this.downloadImage(this.results[parseInt(btn.dataset.i)]);
    });
    const applyBest = document.getElementById("opt-apply-best");
    if (applyBest) applyBest.onclick = () => this.applyImage(this.results[0]);
    const restart = document.getElementById("opt-restart");
    if (restart) restart.onclick = () => {
      if (this.modal) { this.modal.remove(); this.modal = null; }
      setTimeout(() => this.openModal(), 100);
    };
  }

  // Load category dropdown with searchable list — REQUIRED for correct PID/price
  async loadCategoryDropdown() {
    const search = document.getElementById("opt-cat-search");
    const dropdown = document.getElementById("opt-cat-dropdown");
    const clearBtn = document.getElementById("opt-cat-clear");
    const refreshBtn = document.getElementById("opt-cat-refresh");
    const errorEl = document.getElementById("opt-cat-error");

    if (!search || !dropdown) return;

    if (typeof MeeshoAPI === "undefined") {
      search.placeholder = "API not available";
      if (refreshBtn) refreshBtn.style.display = "block";
      if (errorEl) errorEl.style.display = "block";
      return;
    }

    // Initialize MeeshoAPI so supplierId etc. are set
    MeeshoAPI.init();

    if (refreshBtn) {
      refreshBtn.onclick = async () => {
        refreshBtn.textContent = "⏳...";
        MeeshoAPI.cache.categories = null;
        await this.loadCategoryDropdown();
        refreshBtn.textContent = "🔄 Refresh";
      };
    }

    search.placeholder = "Loading categories...";

    try {
      const categories = await MeeshoAPI.fetchCategories();

      if (categories && categories.length > 0) {
        this.allCategories = categories;
        search.placeholder = "🔍 Type to search category...";
        if (refreshBtn) refreshBtn.style.display = "none";
        if (errorEl) errorEl.style.display = "none";

        search.onfocus = () => {
          this.renderCategoryDropdown(this.allCategories.slice(0, 50));
          dropdown.style.display = "block";
        };

        search.oninput = () => {
          const query = search.value.toLowerCase().trim();
          if (clearBtn) clearBtn.style.display = query ? "block" : "none";

          if (query.length === 0) {
            this.renderCategoryDropdown(this.allCategories.slice(0, 50));
          } else {
            const filtered = this.allCategories
              .filter(cat =>
                cat.name.toLowerCase().includes(query) ||
                (cat.parentName || "").toLowerCase().includes(query)
              )
              .slice(0, 30);
            this.renderCategoryDropdown(filtered);
          }
          dropdown.style.display = "block";
        };

        if (clearBtn) {
          clearBtn.onclick = () => {
            search.value = "";
            clearBtn.style.display = "none";
            document.getElementById("opt-cat-id").value = "";
            document.getElementById("opt-cat-selected").style.display = "none";
            this.renderCategoryDropdown(this.allCategories.slice(0, 50));
          };
        }

        // Hide dropdown on click outside
        if (!this._catClickHandler) {
          this._catClickHandler = (e) => {
            if (
              !e.target.closest("#opt-cat-search") &&
              !e.target.closest("#opt-cat-dropdown")
            ) {
              const dd = document.getElementById("opt-cat-dropdown");
              if (dd) dd.style.display = "none";
            }
          };
          document.addEventListener("click", this._catClickHandler);
        }

        console.log("✅ Loaded", categories.length, "categories");
      } else {
        search.placeholder = "Not loaded (login/session) - Click Refresh";
        if (refreshBtn) refreshBtn.style.display = "block";
        if (errorEl) errorEl.style.display = "block";
      }
    } catch (err) {
      console.error("Failed to load categories:", err);
      search.placeholder = "Failed - Click Refresh";
      if (refreshBtn) refreshBtn.style.display = "block";
      if (errorEl) errorEl.style.display = "block";
    }
  }

  renderCategoryDropdown(categories) {
    const dropdown = document.getElementById("opt-cat-dropdown");
    if (!dropdown) return;

    if (categories.length === 0) {
      dropdown.innerHTML = '<div style="padding:10px;color:#aaa;font-size:11px;">No matching categories</div>';
      return;
    }

    let html = "";
    categories.forEach(cat => {
      const safeName = String(cat.name || "").replace(/"/g, '&quot;');
      const safeParent = String(cat.parentName || "").replace(/"/g, '&quot;');
      html += `
        <div class="opt-cat-item" data-id="${cat.id}" data-name="${safeName}" data-parent="${safeParent}"
             style="padding:8px 10px;cursor:pointer;border-bottom:1px solid rgba(255,255,255,0.05);font-size:11px;transition:background 0.15s;">
          <div style="color:#fff;font-weight:600;">${safeName}</div>
          <div style="font-size:9px;color:#888;margin-top:1px;">${safeParent}</div>
        </div>
      `;
    });
    dropdown.innerHTML = html;

    dropdown.querySelectorAll(".opt-cat-item").forEach(item => {
      item.onmouseenter = () => (item.style.background = "rgba(255,215,0,0.12)");
      item.onmouseleave = () => (item.style.background = "transparent");
      item.onclick = () => {
        const id = item.dataset.id;
        const name = item.dataset.name;
        const parent = item.dataset.parent;

        document.getElementById("opt-cat-id").value = id;
        document.getElementById("opt-cat-search").value = name;
        document.getElementById("opt-cat-selected").style.display = "block";
        document.getElementById("opt-cat-selected-name").textContent = `${name} (${parent})`;
        document.getElementById("opt-cat-dropdown").style.display = "none";
        const clearBtn = document.getElementById("opt-cat-clear");
        if (clearBtn) clearBtn.style.display = "block";

        if (typeof MeeshoAPI !== "undefined") {
          MeeshoAPI.setCategory(parseInt(id));
        }
      };
    });
  }

  async applyImage(result) {
    try {
      showToast("Applying image...");

      const imageInput = document.querySelector("#changeFrontImage");
      if (!imageInput) { showToast("Image input not found", true); return; }

      // Use the SAME image that was tested (consistency between test and apply)
      const resp = await fetch(result.dataUrl);
      const blob = await resp.blob();
      const file = new File([blob], "optimized-" + Date.now() + ".jpg", {
        type: "image/jpeg",
      });

      const oldShipping = this.detectShipping();

      const dt = new DataTransfer();
      dt.items.add(file);
      imageInput.files = dt.files;

      // Dispatch BOTH change and input events — React needs both
      imageInput.dispatchEvent(new Event("change", { bubbles: true }));
      imageInput.dispatchEvent(new Event("input", { bubbles: true }));

      if (this.modal) { this.modal.remove(); this.modal = null; }

      // Wait for Meesho to process the image upload
      await new Promise((r) => setTimeout(r, 3000));

      // Trigger Meesho's internal price recalculation multiple times
      // This is what actually makes Meesho upload + link the new image
      await this.triggerPriceRefresh();
      await new Promise((r) => setTimeout(r, 1500));
      await this.triggerPriceRefresh();
      await new Promise((r) => setTimeout(r, 2000));

      // Read the ACTUAL final price from page (what Meesho really calculated)
      const finalShipping = await this.waitForFinalShipping();

      // Update stats
      const savings = (oldShipping && result.shippingCost)
        ? Math.max(0, oldShipping - result.shippingCost) : 0;
      await this.updateStats(savings);

      // Notify user with real vs tested comparison
      const testedPrice = result.shippingCost;
      if (finalShipping) {
        if (finalShipping === testedPrice) {
          showToast(`✅ Shipping: ₹${finalShipping}`);
        } else if (finalShipping < testedPrice) {
          showToast(`🎉 Shipping: ₹${finalShipping} (Better than expected!)`);
          console.log(`✅ Price better — Page: ₹${finalShipping}, API: ₹${testedPrice}`);
        } else {
          showToast(`✅ Shipping: ₹${finalShipping} (API showed ₹${testedPrice})`);
          console.log(`⚠️ Page: ₹${finalShipping}, API: ₹${testedPrice}`);
        }
      } else {
        showToast(`✅ Applied! (API: ₹${testedPrice})`);
      }
    } catch (e) {
      console.error("Apply error:", e);
      showToast("Error: " + e.message, true);
    }
  }

  // Wait and read final shipping value from the page
  async waitForFinalShipping() {
    for (let attempt = 0; attempt < 5; attempt++) {
      await new Promise((r) => setTimeout(r, 500));
      const shipping = this.detectShipping();
      if (shipping && shipping > 0) {
        console.log("📦 Final shipping from page:", shipping);
        return shipping;
      }
    }
    return null;
  }

  // Trigger Meesho's internal price recalculation by simulating
  // a real user touching the price input (focus/select/edit/blur)
  // This is what makes Meesho actually upload + commit the new image
  async triggerPriceRefresh() {
    const priceSelectors = [
      'input[name="price"]',
      'input[name="mrp"]',
      'input[name="sellingPrice"]',
      'input[placeholder*="price" i]',
      'input[placeholder*="mrp" i]',
      'input[id*="price" i]',
      'input[class*="price" i]',
      ".MuiInputBase-input",
      'input[type="number"]',
    ];

    let priceInput = null;

    for (const sel of priceSelectors) {
      try {
        const inputs = document.querySelectorAll(sel);
        for (const inp of inputs) {
          if (
            inp.value &&
            inp.value.match(/^\d+$/) &&
            parseInt(inp.value) >= 10
          ) {
            priceInput = inp;
            break;
          }
        }
        if (priceInput) break;
      } catch (e) {}
    }

    if (priceInput) {
      const currentValue = priceInput.value;

      priceInput.focus();
      priceInput.click();
      await new Promise((r) => setTimeout(r, 100));

      priceInput.select();
      priceInput.value = currentValue;

      priceInput.dispatchEvent(new Event("input", { bubbles: true, cancelable: true }));
      priceInput.dispatchEvent(new Event("change", { bubbles: true, cancelable: true }));
      priceInput.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Tab", keyCode: 9 }));
      priceInput.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: "Tab", keyCode: 9 }));

      await new Promise((r) => setTimeout(r, 100));

      priceInput.blur();
      priceInput.dispatchEvent(new FocusEvent("blur", { bubbles: true }));
      priceInput.dispatchEvent(new FocusEvent("focusout", { bubbles: true }));

      document.body.click();
    }

    // Also click any Calculate/Update/Save button if present
    const buttons = document.querySelectorAll('button, [role="button"]');
    for (const btn of buttons) {
      const text = (btn.textContent || "").toLowerCase().trim();
      if (
        text.includes("calculate") ||
        text.includes("update") ||
        text === "save"
      ) {
        btn.click();
        await new Promise((r) => setTimeout(r, 500));
        break;
      }
    }
  }

  // Update stats in chrome.storage
  async updateStats(savings) {
    try {
      const result = await chrome.storage.sync.get(["stats"]);
      const stats = result.stats || { imagesOptimized: 0, totalSavings: 0 };
      stats.imagesOptimized = (stats.imagesOptimized || 0) + 1;
      stats.totalSavings = (stats.totalSavings || 0) + savings;
      await chrome.storage.sync.set({ stats: stats });
      console.log("📊 Stats updated:", stats);
    } catch (err) {
      console.error("Stats update error:", err);
    }
  }

  downloadImage(result) {
    const a = document.createElement("a");
    a.href = result.dataUrl;
    a.download = "kiwtech-" + result.name + "-" + Date.now() + ".jpg";
    a.click();
    showToast("Downloaded: " + result.name);
  }
}

// Initialize shipping optimizer
if (window.location.href.includes("supplier.meesho.com")) {
  window.__kiwtechShippingOpt = new KiwtechShippingOptimizer();
}

// ─── Handle popup messages for shipping optimizer ────────────────────────────
chrome.runtime.onMessage.addListener((msg, sender, respond) => {
  if (msg.action === "POPUP_SHIP_START") {
    (async () => {
      const { imageDataUrl, target, maxAttempts } = msg;
      // Convert dataUrl to blob
      const res = await fetch(imageDataUrl);
      const blob = await res.blob();

      MeeshoAPI.init();

      const result = await MeeshoAPI.smartSearch(
        blob,
        target,
        maxAttempts,
        (attempt, total, best, noPid) => {
          // Send progress to popup
          try {
            chrome.runtime.sendMessage({ type: "SHIP_PROGRESS", attempt, total, best, noPid });
          } catch(e) {}
          // Save to storage for polling
          chrome.storage.local.set({ shipProgress: { attempt, total, best, noPid } });
        },
        null,
        () => false
      );

      // Save final results
      chrome.storage.local.set({
        shipResults: { done: true, results: result.results || [] }
      });

      // Notify popup
      try {
        chrome.runtime.sendMessage({ type: "SHIP_DONE", results: result.results || [] });
      } catch(e) {}
    })();
    respond({ success: true });
    return true;
  }

  if (msg.action === "APPLY_SHIP_IMAGE") {
    (async () => {
      try {
        const imageInput = document.querySelector("#changeFrontImage");
        if (!imageInput) { respond({ success: false, error: "Image input not found" }); return; }

        const r = await fetch(msg.dataUrl);
        const blob = await r.blob();
        const file = new File([blob], "kiwtech-opt-" + Date.now() + ".jpg", { type: "image/jpeg" });

        const dt = new DataTransfer();
        dt.items.add(file);
        imageInput.files = dt.files;

        // Dispatch BOTH change and input events for React
        imageInput.dispatchEvent(new Event("change", { bubbles: true }));
        imageInput.dispatchEvent(new Event("input", { bubbles: true }));

        // Wait for Meesho to process the image
        await new Promise((r) => setTimeout(r, 3000));

        // Trigger price refresh — this is what commits the image to Meesho's backend
        const inst = window.__kiwtechShippingOpt;
        if (inst) {
          await inst.triggerPriceRefresh();
          await new Promise((r) => setTimeout(r, 1500));
          await inst.triggerPriceRefresh();
          await new Promise((r) => setTimeout(r, 2000));
          const finalShipping = await inst.waitForFinalShipping();
          respond({ success: true, finalShipping });
        } else {
          respond({ success: true });
        }
      } catch(e) { respond({ success: false, error: e.message }); }
    })();
    return true;
  }
});

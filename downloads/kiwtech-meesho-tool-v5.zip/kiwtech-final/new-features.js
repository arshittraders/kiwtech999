// ═══════════════════════════════════════════════════════════════════════
// Kiwtech v5 — NEW FEATURES
// 1. Fetch: Meesho product page se pura data
// 2. Compare: Do products A vs B
// 3. Visual Search: Image upload → Meesho similar products
// ═══════════════════════════════════════════════════════════════════════

// ── State ────────────────────────────────────────────────────────────────────
let fetchedProduct = null;   // last fetched product data
let compareSlotA   = null;   // Product A for comparison
let compareSlotB   = null;   // Product B for comparison

// ── Helper ───────────────────────────────────────────────────────────────────
function setStatus(elId, msg, color) {
  const el = document.getElementById(elId);
  if (el) { el.textContent = msg; el.style.color = color || '#555'; }
}

// ═══════════════════════════════════════════════════════════════════
// FEATURE 1 — FETCH: Meesho product page ka pura data
// ═══════════════════════════════════════════════════════════════════
async function handleFetchProduct() {
  setStatus('fetch-status', '🔍 Meesho product page dhundh raha hoon...', '#0066cc');
  document.getElementById('fetch-result').style.display = 'none';

  // Find meesho.com tab
  const tabs = await new Promise(r => chrome.tabs.query({}, r));
  const meeshoTab = tabs.find(t => t.url && t.url.includes('meesho.com') && !t.url.includes('supplier'));

  if (!meeshoTab) {
    setStatus('fetch-status', '❌ Meesho.com tab nahi mila. Meesho pe koi product open karo.', '#cc2222');
    return;
  }

  setStatus('fetch-status', '📡 Data fetch ho raha hai...', '#0066cc');

  try {
    const results = await chrome.scripting.executeScript({
      target: { tabId: meeshoTab.id },
      func: () => {
        try {
          const result = { title:'', price:'', mrp:'', shipping:'', discount:'', rating:'', reviews:'', description:'', category:'', images:[], attrs:{}, seller:{}, stats:{}, similar:[], insights:{}, url: window.location.href };

          // 1. __NEXT_DATA__ — try all paths + deep search
          const nd = window.__NEXT_DATA__;
          const pp = nd?.props?.pageProps;

          function deepFind(obj, depth) {
            if (!obj || depth > 5 || typeof obj !== 'object') return null;
            if ((obj.catalog_name || obj.name) && (obj.meesho_price || obj.price || obj.catalog_images)) return obj;
            for (const v of Object.values(obj)) { const f = deepFind(v, depth+1); if (f) return f; }
            return null;
          }

          // ── V26-style: direct path for complete data ─────────────────
          const v26d = pp?.initialState?.product?.details?.data;
          if (v26d) {
            const sup = v26d.suppliers?.[0] || {};
            const hi  = v26d.product_details?.product_highlights?.attributes || [];
            const ad  = v26d.product_details?.additional_details?.attributes  || [];
            const allA = [...hi, ...ad];

            // Title, price, etc
            result.title    = result.title    || (v26d.name || '').trim();
            result.price    = result.price    || String(v26d.price || '');
            result.mrp      = result.mrp      || String(v26d.mrp_details?.mrp || v26d.mrp || '');
            result.discount = result.discount || (v26d.discount ? v26d.discount + '% off' : '');
            result.description = result.description || (v26d.description || '').trim();
            result.category = result.category || v26d.breadcrumb?.map(b => b.title).filter(Boolean).join(' > ') || '';

            // Shipping from supplier
            result.shipping = result.shipping || String(sup.shipping?.charges || '');

            // Attributes from v26 paths
            allA.forEach(a => {
              const k = a.display_name || a.field_name || a.name;
              const v = a.value;
              if (k && v) result.attrs[k] = String(v).trim();
            });

            // Images from v26 — try ALL paths
            const imgSeen0 = new Set(result.images);
            const pushImg = u => {
              if (!u || typeof u !== 'string') return;
              // Clean Cloudinary URL
              const clean = u.replace(/\/upload\/[^/]+\//,'/upload/').replace(/,w_\d+|,h_\d+|,q_\d+/g,'').replace(/\?.*/,'');
              const final = clean || u;
              if (!imgSeen0.has(final)) { imgSeen0.add(final); result.images.push(final); }
            };
            // v26d.images array
            (v26d.images || []).forEach(img => pushImg(img.url || img.image_url || (typeof img==='string'?img:'')));
            // catalog_images
            (v26d.catalog_images || []).forEach(img => pushImg(img.url || img.image_url || (typeof img==='string'?img:'')));
            // variants
            (v26d.variants || []).forEach(v => pushImg(v.image_url || v.img_url || v.image || ''));
            // suppliers images
            (sup.catalog_images || []).forEach(img => pushImg(img.url || (typeof img==='string'?img:'')));
            // product_details images
            (v26d.product_details?.images || []).forEach(img => pushImg(img.url || (typeof img==='string'?img:'')));

            // MRP — try all possible paths
            result.mrp = result.mrp || String(
              v26d.mrp_details?.mrp ||
              v26d.original_price ||
              v26d.mrp ||
              sup.mrp ||
              ''
            );

            // Shipping — try all supplier shipping paths
            result.shipping = result.shipping || String(
              sup.shipping?.charges ||
              sup.shipping_charges ||
              sup.delivery_charges ||
              v26d.shipping_cost ||
              ''
            );
            let inv = null;
            try { inv = JSON.parse(atob(sup.app_event_data?.price_metadata || '')).inventoryCount; } catch(e) {}

            // ── DECODE price_metadata for hidden insights ──────────────
            // Try all possible locations in __NEXT_DATA__
            try {
              // Path 1: supplier app_event_data
              let pm64 = sup.app_event_data?.price_metadata || '';
              // Path 2: v26d directly
              if (!pm64) pm64 = v26d.app_event_data?.price_metadata || '';
              // Path 3: Deep search for price_metadata anywhere
              if (!pm64) {
                const ndStr = JSON.stringify(nd || {});
                const pmMatch = ndStr.match(/"price_metadata"\s*:\s*"([A-Za-z0-9+/=]+)"/);
                if (pmMatch) pm64 = pmMatch[1];
              }
              if (pm64 && pm64.length > 20) {
                const pm = JSON.parse(atob(pm64));
                const buyerPrice  = parseFloat(result.price || pm.servingPrice || 0);
                const supPrice    = pm.supplierPrice || 0;
                const logistics   = pm.logisticsCharge || 0;
                const codCharge   = pm.codCharge || 0;
                const invCount    = pm.inventoryCount;
                const margin      = supPrice > 0 && buyerPrice > 0
                  ? ((buyerPrice - supPrice) / buyerPrice * 100).toFixed(1)
                  : null;
                result.insights = {
                  supplier_price:   supPrice    ? `₹${supPrice}` : '',
                  buyer_price:      buyerPrice  ? `₹${buyerPrice}` : '',
                  logistics_charge: logistics   ? `₹${logistics.toFixed(2)}` : '',
                  cod_charge:       codCharge   ? `₹${codCharge.toFixed(2)}` : '',
                  inventory:        invCount !== undefined ? String(invCount) : '',
                  weight:           pm.weight   ? `${pm.weight}g` : '',
                  zone:             pm.zone     || '',
                  margin_pct:       margin      ? `${margin}%` : '',
                  cod_discount:     pm.codDiscount ? `₹${pm.codDiscount}` : '',
                  rto_pct_cod:      (() => {
                    if (!pm.rtoPercentageCod) return '';
                    // If value > 1, it's already a percentage (e.g. 65.4)
                    // If value <= 1, it's a decimal (e.g. 0.654)
                    const raw = pm.rtoPercentageCod;
                    const pct = raw > 1 ? raw : raw * 100;
                    return `${Math.min(pct, 99.9).toFixed(1)}%`;
                  })(),
                  price_path:       pm.servingPriceType || '',
                };
                if (!result.seller.inventory && invCount !== undefined) {
                  result.seller.inventory = String(invCount);
                }
              }
            } catch(e) {}
            result.seller = {
              name:           v26d.supplier_name || sup.name || '',
              rating:         String(sup.average_rating || ''),
              ratings_count:  String(sup.rating_count || ''),
              followers:      String(sup.shop_value_props?.find(v => v.type === 'follower')?.follower?.count || ''),
              products_count: String(sup.shop_value_props?.find(v => v.type === 'product')?.product?.count || ''),
              products_sold:  String(sup.shop_value_props?.find(v => v.type === 'products_sold')?.products_sold?.count || ''),
              dispatch_time:  String(sup.shipping_time || ''),
              cod_available:  sup.cod_available ? 'Yes' : 'No',
              inventory:      inv !== null ? String(inv) : '',
            };

            // PRODUCT STATS
            result.stats = {
              product_rating:  String(v26d.review_summary?.data?.average_rating || v26d.rating || ''),
              rating_count:    String(v26d.review_summary?.data?.rating_count || ''),
              review_count:    String(v26d.review_summary?.data?.review_count || ''),
              rating_map:      v26d.review_summary?.data?.rating_count_map || {},
              is_ad:           v26d.is_ad_product ? 'Yes (Ad Product)' : 'No (Organic)',
              product_id:      String(v26d.product_id || ''),
              catalog_id:      String(v26d.catalog?.catalog_id || ''),
              sscat:           v26d.catalog?.sub_sub_category_name || '',
            };

            // SIMILAR PRODUCTS from Meesho's own data
            result.similar = (v26d.catalog?.similarProducts || []).slice(0, 6).map(s => ({
              name:  s.name || '',
              price: String(s.min_price || ''),
              image: s.images?.[0] || '',
              slug:  s.slug || '',
            }));
          }

          const paths = [pp?.initialState?.product?.details?.data, pp?.initialState?.product?.data, pp?.product?.details?.data, pp?.catalogData, pp?.initialState?.catalog?.data, pp?.initialState?.pdp?.data, pp?.data];
          let d = paths.find(p => p && (p.catalog_name || p.name || p.product_name));
          if (!d) d = deepFind(pp, 0);

          if (d) {
            result.title = d.catalog_name || d.name || d.product_name || '';
            result.price = String(d.meesho_price || d.price || '');
            result.mrp      = String(d.mrp || '');
            result.discount = d.discount_percent ? d.discount_percent + '% off' : '';
            // Shipping cost — multiple possible fields
            result.shipping = String(
              d.shipping_cost || d.shipping_charges || d.delivery_charges ||
              d.shipping?.cost || d.delivery?.charges ||
              d.catalog_shipping?.cost || ''
            );
            result.rating  = String(d.rating || d.avg_rating || d.average_rating || '');
            result.reviews = String(d.ratings_count || d.reviews_count || d.rating_count || '');
            result.description = (d.description || d.catalog_description || d.about || '').trim();
            result.category = d.category || d.catalog_category || '';

            const imgSeen = new Set();
            const addImg = u => {
              if (!u || imgSeen.has(u)) return;
              imgSeen.add(u);
              result.images.push(u.replace(/\/upload\/[^/]+\//,'/upload/').replace(/,w_\d+|,h_\d+|,q_\d+/g,'').replace(/\?.*/,'') || u);
            };
            [d.catalog_images, d.images, d.product_images, d.story_images].forEach(arr =>
              Array.isArray(arr) && arr.forEach(i => addImg(typeof i==='string'?i:(i.url||i.image_url||''))));
            [d.variants, d.catalog_variants].forEach(arr =>
              Array.isArray(arr) && arr.forEach(v => addImg(v.image_url||v.img_url||v.image||'')));
            // product page: images under product_details
            const pdImgs = d.product_details?.images || d.product_details?.catalog_images || [];
            pdImgs.forEach(i => addImg(typeof i==='string'?i:(i.url||'')));
            // Deep scan JSON for any meesho image URL
            try {
              const dStr = JSON.stringify(d);
              for (const m of dStr.matchAll(/"(https:\/\/images\.meesho\.com\/[^"]+)"/g)) addImg(m[1]);
            } catch(e) {}

            // addAttr — try ALL possible key/value field names including v26's field_name+display_name
            const addAttr = arr => {
              if (!Array.isArray(arr)) return;
              arr.forEach(a => {
                const k = a.display_name || a.field_name || a.name || a.attribute_name || a.key || a.label || a.title;
                const v = a.value || a.attribute_value || a.val || a.display_value || a.text;
                if (k && v && String(v).trim() && String(k).trim()) result.attrs[String(k).trim()] = String(v).trim();
              });
            };

            // Try every known path for attributes
            addAttr(d.product_details?.product_highlights?.attributes);
            addAttr(d.product_details?.additional_details?.attributes);
            addAttr(d.product_details?.attributes);
            addAttr(d.attributes);
            addAttr(d.product_attributes);
            addAttr(d.catalog_attributes);
            addAttr(d.highlights?.attributes);
            // variants level attributes
            [d.variants, d.catalog_variants].forEach(arr => Array.isArray(arr) && arr[0] && addAttr(arr[0].attributes));
            // Deep search: any object key named 'attributes' that is an array
            function deepAttrs(obj, depth) {
              if (!obj || depth > 4 || typeof obj !== 'object') return;
              if (Array.isArray(obj)) return;
              for (const [key, val] of Object.entries(obj)) {
                if (key === 'attributes' && Array.isArray(val) && val.length > 0) addAttr(val);
                else deepAttrs(val, depth + 1);
              }
            }
            deepAttrs(d, 0);

            // Also extract category path
            if (!result.category) {
              result.category = d.breadcrumb?.map(b => b.title || b.name || b.label).filter(Boolean).join(' > ') || d.category || d.catalog_category || '';
            }

            const kf = {Color:d.color, Fabric:d.fabric||d.material, Brand:d.brand, Type:d.type,
              'Net Quantity':d.net_quantity, 'Country of Origin':d.country_of_origin,
              'Generic Name':d.generic_name, 'Shelf Life':d.shelf_life, Capacity:d.capacity,
              Pattern:d.pattern, Ornamentation:d.ornamentation, Occasion:d.occasion, 'Ideal For':d.ideal_for,
              'Sub Category':d.catalog?.sub_sub_category_name, Size:d.size, Weight:d.weight,
              Material:d.material||d.fabric, Style:d.style, 'Pack Of':d.pack_of||d.quantity};
            Object.entries(kf).forEach(([k,v]) => { if(v && !result.attrs[k]) result.attrs[k]=String(v); });
          }

          // 2. DOM fallback for title, price, images
          if (!result.title) result.title = document.querySelector('h1')?.innerText?.trim() || '';
          // Price from DOM (always run — JSON price often missing)
          if (!result.price) {
            for (const sel of ['h4[class*="sc-"]','[class*="pdp"] h4','[class*="price"] h4','h4','[class*="discounted"] span']) {
              for (const el of document.querySelectorAll(sel)) {
                const n = (el.innerText||'').replace(/[^0-9]/g,'');
                if (n && parseInt(n) > 0 && parseInt(n) < 100000) { result.price = n; break; }
              }
              if (result.price) break;
            }
          }
          if (!result.mrp) {
            for (const el of document.querySelectorAll('s,del,[class*="mrp"],[class*="strike"],[class*="original-price"]')) {
              const n = (el.innerText||'').replace(/[^0-9]/g,'');
              if (n && parseInt(n) > 0) { result.mrp = n; break; }
            }
          }
          if (!result.discount) {
            for (const el of document.querySelectorAll('[class*="discount"],[class*="off"]')) {
              const t = (el.innerText||'').trim();
              if (t.includes('%') || t.toLowerCase().includes('off')) { result.discount = t.slice(0,20); break; }
            }
          }
          if (!result.shipping) {
            const bt = document.body.innerText||'';
            if (/free\s*deliver/i.test(bt)) result.shipping = 'Free';
            else {
              const m = bt.match(/deliver[^\n]{0,30}?₹\s*(\d+)/i)||bt.match(/shipping[^\n]{0,30}?₹\s*(\d+)/i);
              if (m) result.shipping = m[1];
            }
            if (!result.shipping) {
              for (const el of document.querySelectorAll('[class*="deliver"],[class*="ship"]')) {
                const t=(el.innerText||'').trim();
                if(t.length>2&&t.length<60){result.shipping=t;break;}
              }
            }
          }
          // DOM image scraping — ALWAYS run (not just as fallback)
          {
            const seen2 = new Set(result.images);
            const addDomImg = u => {
              if (!u || seen2.has(u)) return;
              if (u.includes('images.meesho.com') || u.includes('meesho-media') || u.includes('meeshocdn') || u.includes('cloudinary') || u.includes('media.meesho') || u.includes('meesho.com/media')) {
                seen2.add(u); result.images.push(u);
              }
            };
            document.querySelectorAll('img').forEach(img => {
              // srcset — pick highest res URL
              if (img.srcset) {
                const parts = img.srcset.split(',').map(s => s.trim().split(' '));
                const best = parts.sort((a,b) => parseInt(b[1]||0) - parseInt(a[1]||0));
                best.forEach(p => addDomImg(p[0]));
              }
              addDomImg(img.src);
              addDomImg(img.dataset?.src);
              addDomImg(img.dataset?.lazySrc);
            });
            // Next.js image wrappers
            document.querySelectorAll('[data-lazy-src],[data-src],[data-original]').forEach(el => {
              addDomImg(el.dataset.lazySrc || el.dataset.src || el.dataset.original);
            });
          }
          result.images = [...new Set(result.images)].filter(u => u && u.startsWith('http')).slice(0, 12);

          // 3. DOM Attributes — multiple strategies
          if (Object.keys(result.attrs).length < 3) {
            // Strategy A: rows with 2 children
            const rowSels = ['[class*="Highlight"] [class*="row"]','[class*="highlight"] [class*="Row"]','[class*="ProductDetail"] tr','[class*="Attribute"] li','table tr','[class*="spec"] tr'];
            for (const sel of rowSels) {
              document.querySelectorAll(sel).forEach(row => {
                const kids = row.querySelectorAll('span,p,td,div');
                if (kids.length >= 2) {
                  const k = kids[0].innerText?.trim(); const v = kids[1].innerText?.trim();
                  if (k && v && k.length < 50 && v.length < 100 && !k.includes('\n') && !result.attrs[k]) result.attrs[k] = v;
                }
              });
              if (Object.keys(result.attrs).length > 3) break;
            }

            // Strategy B: dt/dd
            document.querySelectorAll('dl').forEach(dl => {
              dl.querySelectorAll('dt').forEach((dt,i) => {
                const dd = dl.querySelectorAll('dd')[i];
                if (dd) result.attrs[dt.innerText.trim()] = dd.innerText.trim();
              });
            });

            // Strategy C: Meesho specific — look for "Product Details" section
            document.querySelectorAll('[class*="ProductDetail"],[class*="product-detail"],[class*="highlights"],[class*="Highlights"]').forEach(section => {
              const text = section.innerText || '';
              text.split('\n').forEach(line => {
                if (line.includes(':')) {
                  const [k,...rest] = line.split(':');
                  const v = rest.join(':').trim();
                  if (k && v && k.trim().length < 40 && v.length < 100) result.attrs[k.trim()] = v;
                }
              });
            });
          }

          // 4. Category from DOM breadcrumb if not found
          if (!result.category) {
            const crumbs = [...document.querySelectorAll('[class*="breadcrumb"] a,[class*="Breadcrumb"] a,nav a')];
            const crumbText = crumbs.map(a => a.innerText?.trim()).filter(t => t && t.length > 1 && t !== 'Home');
            if (crumbText.length > 0) result.category = crumbText.join(' > ');
          }

          // 5. Description from DOM
          if (!result.description) {
            for (const sel of ['[class*="description"]','[class*="Description"]','[class*="about"]','[data-testid*="desc"]']) {
              const el = document.querySelector(sel);
              if (el?.innerText?.trim().length > 20) { result.description = el.innerText.trim(); break; }
            }
          }

          // 6. Filter out garbage — only keep real product attributes
          const JUNK_KEYS = new Set(['add to cart','buy now','copy','sold by','view shop','profile','cart',
            'popular','men','women western','lingerie','grocery','books','electronics','watches',
            'home & kitchen','kids & toys','sports & fitness','jewellery & accessories','bags & footwear',
            'pet supplies','musical instruments','office supplies & stationery','car & motorbike',
            'beauty & health','kurti, saree & lehenga','cash on delivery','7-day returns','lowest price',
            'contact us','reach out to us','become a supplier','investor relations','free size','select size',
            'shop non-stop on meesho','people also viewed','view all reviews','product ratings & reviews',
            'product highlights','additional details','trusted by crores of indians',
            'meesho technologies private limited','excellent','very good','good','average','poor',
            'followers','products','ratings','reviews','% off','similar products','1 similar products']);
          const JUNK_VAL_PATTERNS = [/^\d+$/, /^\d+\.\d+$/, /reviews$/i, /ratings$/i, /% off$/i,
            /^(popular|cart|profile|men|books|electronics|grocery|watches|lingerie)$/i];

          result.attrs = Object.fromEntries(
            Object.entries(result.attrs).filter(([k, v]) => {
              const kl = k.toLowerCase().trim();
              const vl = String(v).toLowerCase().trim();
              if (JUNK_KEYS.has(kl)) return false;
              if (kl.length < 2 || kl.length > 50) return false;
              if (vl.length < 1 || vl.length > 150) return false;
              if (JUNK_VAL_PATTERNS.some(p => p.test(vl))) return false;
              if (/^\d+\s+reviews?$/i.test(vl)) return false;
              if (/^\d+\s+ratings?/i.test(vl)) return false;
              if (kl.includes('review') || kl.includes('rating') || kl.includes('% off')) return false;
              return true;
            })
          );

          return result;
        } catch(e) { return { error: e.message }; }
      }
    });

    const data = results[0]?.result;
    if (!data || data.error || !data.title) {
      setStatus('fetch-status', '❌ Data nahi mila. Product detail page pe jao (search page nahi).', '#cc2222');
      return;
    }

    fetchedProduct = data;
    setStatus('fetch-status', `✅ Fetched: ${data.title.slice(0, 50)}...`, '#2e7d32');
    renderFetchResult(data);
    generateFetchListing(data);

  } catch(e) {
    setStatus('fetch-status', '❌ Error: ' + e.message, '#cc2222');
  }
}

async function handleFetchByCatalogId() {
  const input = document.getElementById('fetchCatalogIdInput');
  const rawId = (input?.value || '').trim();
  if (!rawId) { alert('Catalog ID ya PID daalo'); return; }

  setStatus('fetch-status', '🔍 Catalog ID se data fetch ho raha hai...', '#0066cc');
  document.getElementById('fetch-result').style.display = 'none';

  try {
    // Use search API with catalog ID as query to get its data
    const sessionId = `ctx_1_uid_-1_txt_-1_t_${Date.now()}`;
    const res = await new Promise(resolve => {
      chrome.runtime.sendMessage({
        type: 'FETCH_CATALOG_DATA',
        catalogId: rawId,
        sessionId
      }, r => resolve(r));
    });

    if (res?.success && res.data) {
      fetchedProduct = res.data;
      setStatus('fetch-status', `✅ Data fetch ho gaya!`, '#2e7d32');
      renderFetchResult(res.data);
      generateFetchListing(res.data);
    } else {
      setStatus('fetch-status', '❌ Data nahi mila — Meesho product page pe jao aur fetch karo', '#cc2222');
    }
  } catch(e) {
    setStatus('fetch-status', '❌ ' + e.message, '#cc2222');
  }
}
async function downloadAsJpg(url, idx, productTitle) {
  // Get highest resolution version — remove size suffix
  // e.g. tdc8o_512.jpg → tdc8o_1024.jpg or sqraw_512.jpg → sqraw_1024.jpg
  const hiResUrl = url
    .replace(/_\d+\.(jpg|jpeg|webp|avif|png)/i, '_1024.$1')  // _512 → _1024
    .replace(/width=\d+/, 'width=1024')                       // ?width=512 → ?width=1024
    .replace(/\/\d+x\d+\//, '/1024x1024/');                   // /512x512/ → /1024x1024/

  const finalUrl = hiResUrl || url;
  const safeTitle = (productTitle || 'product').replace(/[^a-zA-Z0-9\s]/g,'').trim().slice(0,40).replace(/\s+/g,'_');
  const ext = finalUrl.match(/\.(jpe?g|png|webp|avif)(\?|$)/i)?.[1] || 'jpg';
  const filename = safeTitle + '_img' + idx + '.' + ext;

  try {
    // Method 1: Direct URL download — NO canvas conversion, original file preserved
    const dlId = await new Promise((res, rej) => {
      chrome.downloads.download({
        url: finalUrl,
        filename: filename,
        saveAs: false
      }, id => {
        if (chrome.runtime.lastError) rej(chrome.runtime.lastError);
        else res(id);
      });
    });
    if (dlId) return true;
  } catch(e) {}

  // Method 2: Try original URL if hi-res failed
  try {
    const res = await new Promise((resolve, reject) => {
      chrome.runtime.sendMessage({ type: 'FETCH_IMAGE_AS_JPG', url: finalUrl }, r => {
        if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
        else resolve(r);
      });
    });
    if (res?.success && res.base64) {
      const mimeType = res.mimeType || 'image/jpeg';
      const dataUrl = `data:${mimeType};base64,${res.base64}`;
      const dlId2 = await new Promise((res2, rej2) => {
        chrome.downloads.download({
          url: dataUrl,
          filename: filename,
          saveAs: false
        }, id => {
          if (chrome.runtime.lastError) rej2(chrome.runtime.lastError);
          else res2(id);
        });
      });
      if (dlId2) return true;
    }
  } catch(e) {}

  // Method 3: Open in new tab
  chrome.tabs.create({ url: finalUrl });
  return true;
}



function renderFetchResult(data) {
  document.getElementById('fetch-result').style.display = 'block';

  // Title
  const titleEl = document.getElementById('fetch-title');
  if (titleEl) titleEl.textContent = data.title || '';

  // Price fields (new clean UI)
  const mp  = data.price    ? parseInt(data.price)    : 0;
  const mrp = data.mrp      ? parseInt(data.mrp)      : 0;
  const sp  = data.shipping ? (data.shipping === 'Free' || data.shipping === '0' ? 0 : parseInt(data.shipping)) : null;

  const priceEl    = document.getElementById('fetch-price');
  const mrpEl      = document.getElementById('fetch-mrp');
  const discountEl = document.getElementById('fetch-discount');
  const shipEl     = document.getElementById('fetch-shipping');
  const ratingEl   = document.getElementById('fetch-rating');

  if (priceEl)    priceEl.textContent    = mp  ? '₹' + mp  : '—';
  if (mrpEl)      mrpEl.textContent      = mrp ? '₹' + mrp : '—';
  if (discountEl) discountEl.textContent = data.discount || '';
  // Shipping: buyer pe Meesho "Free Delivery" dikhata hai ya COD pe extra charge
  // sp=0 means free delivery, null/undefined means unknown
  if (shipEl) {
    if (sp === 0 || sp === null) {
      shipEl.textContent = 'Free';
      shipEl.style.color = 'var(--green)';
      shipEl.style.fontSize = '13px';
      const parentDiv = shipEl.closest('div[style*="border"]');
      if (parentDiv) parentDiv.style.borderColor = 'var(--green)';
    } else if (sp > 0) {
      shipEl.textContent = '₹' + sp;
    } else {
      shipEl.textContent = 'Free';
      shipEl.style.color = 'var(--green)';
      shipEl.style.fontSize = '13px';
    }
  }
  if (ratingEl)   ratingEl.innerHTML     = data.rating ? `⭐ ${data.rating}<div style="font-size:8px;color:var(--text2);">${data.reviews ? Number(data.reviews).toLocaleString('en-IN') + ' ratings' : ''}</div>` : '—';

  // Competitive range
  const compRange = document.getElementById('fetch-comp-range');
  if (compRange && mp > 0) {
    const low  = Math.max(mp - 10, Math.round(mp * 0.95));
    const high = mp - 1;
    compRange.innerHTML = `<span style="font-size:9px;color:var(--text2);">🏷 Tumhara competitive range: </span><span style="font-weight:900;color:var(--accent);">₹${low} – ₹${high}</span><span style="font-size:9px;color:var(--text2);"> (competitor se thoda kam)</span>`;
    compRange.style.display = 'block';
  }

  // Attributes + Category
  const attrsEl = document.getElementById('fetch-attrs');
  if (attrsEl) {
    let html = '';
    if (data.category) {
      html += `<div style="background:var(--bg2);border:1.5px solid var(--accent);padding:5px 10px;margin-bottom:8px;font-size:10px;font-weight:800;color:var(--accent);border-radius:6px;">📂 ${data.category}</div>`;
    }
    const entries = Object.entries(data.attrs || {});
    if (entries.length) {
      html += entries.map(([k,v]) =>
        `<div style="display:flex;justify-content:space-between;border-bottom:1px solid var(--border2);padding:4px 0;gap:8px;">
          <span style="color:var(--text2);font-weight:700;font-size:10px;flex-shrink:0;">${k}</span>
          <span style="font-weight:800;font-size:10px;text-align:right;color:var(--text);">${v}</span>
        </div>`
      ).join('');
    } else {
      html += '<div style="font-size:10px;color:var(--text2);">Attributes nahi mile</div>';
    }
    attrsEl.innerHTML = html;
  }

  // Seller Info
  const sellerEl = document.getElementById('fetch-seller');
  if (sellerEl) {
    const s = data.seller || {};
    if (s.name || s.rating || s.followers) {
      sellerEl.style.display = 'block';
      sellerEl.innerHTML = `
        <div class="step-label">🏪 Seller Info</div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:5px;margin-top:6px;">
          ${s.name ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:6px 8px;border-radius:5px;grid-column:1/-1;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Seller</div><div style="font-size:12px;font-weight:900;">${s.name}</div></div>` : ''}
          ${s.rating ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:6px 8px;border-radius:5px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Seller Rating</div><div style="font-size:14px;font-weight:900;color:#f59e0b;">⭐ ${s.rating}</div><div style="font-size:9px;color:var(--text2);">${s.ratings_count || ''} ratings</div></div>` : ''}
          ${s.followers ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:6px 8px;border-radius:5px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Followers</div><div style="font-size:14px;font-weight:900;color:var(--accent);">${Number(s.followers).toLocaleString('en-IN')}</div></div>` : ''}
          ${s.products_sold ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:6px 8px;border-radius:5px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Products Sold</div><div style="font-size:14px;font-weight:900;color:var(--green);">${Number(s.products_sold).toLocaleString('en-IN')}</div></div>` : ''}
          ${s.dispatch_time ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:6px 8px;border-radius:5px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Dispatch</div><div style="font-size:12px;font-weight:900;">${s.dispatch_time}</div></div>` : ''}
          ${s.inventory ? `<div style="background:var(--bg2);border:1.5px solid var(--green);padding:6px 8px;border-radius:5px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Inventory</div><div style="font-size:14px;font-weight:900;color:var(--green);">${Number(s.inventory).toLocaleString('en-IN')} units</div></div>` : ''}
        </div>`;
    } else { sellerEl.style.display = 'none'; }
  }

  // Product Stats (rating breakdown)
  const statsEl = document.getElementById('fetch-stats');
  if (statsEl) {
    const st = data.stats || {};
    const rm = st.rating_map || {};
    const rmKeys = Object.keys(rm).sort((a,b) => b - a);
    const maxRm  = Math.max(...Object.values(rm).map(Number), 1);
    if (st.product_rating || st.rating_count || st.review_count) {
      statsEl.style.display = 'block';
      const bars = rmKeys.map(star => {
        const count = parseInt(rm[star]) || 0;
        const pct   = Math.round((count / maxRm) * 100);
        return `<div style="display:flex;align-items:center;gap:6px;margin-bottom:3px;">
          <span style="font-size:10px;font-weight:800;width:18px;color:var(--text);">${star}★</span>
          <div style="flex:1;background:var(--bg2);border-radius:20px;height:7px;overflow:hidden;">
            <div style="height:100%;width:${pct}%;background:linear-gradient(90deg,#f59e0b,#d97706);border-radius:20px;"></div>
          </div>
          <span style="font-size:9px;color:var(--text2);width:40px;text-align:right;">${count.toLocaleString('en-IN')}</span>
        </div>`;
      }).join('');

      statsEl.innerHTML = `
        <div class="step-label" style="background:linear-gradient(135deg,#f59e0b,#d97706);">📊 Product Stats</div>
        <div style="display:flex;gap:8px;flex-wrap:wrap;margin:8px 0;">
          ${st.product_rating ? `<div style="text-align:center;background:var(--bg2);border:1.5px solid var(--border2);padding:8px 12px;border-radius:8px;"><div style="font-size:22px;font-weight:900;color:#f59e0b;">⭐ ${st.product_rating}</div><div style="font-size:8px;color:var(--text2);">Avg Rating</div></div>` : ''}
          ${st.rating_count ? `<div style="text-align:center;background:var(--bg2);border:1.5px solid var(--border2);padding:8px 12px;border-radius:8px;"><div style="font-size:18px;font-weight:900;color:var(--text);">${Number(st.rating_count).toLocaleString('en-IN')}</div><div style="font-size:8px;color:var(--text2);">Total Ratings</div></div>` : ''}
          ${st.review_count ? `<div style="text-align:center;background:var(--bg2);border:1.5px solid var(--border2);padding:8px 12px;border-radius:8px;"><div style="font-size:18px;font-weight:900;color:var(--text);">${Number(st.review_count).toLocaleString('en-IN')}</div><div style="font-size:8px;color:var(--text2);">Reviews</div></div>` : ''}
          ${st.is_ad ? `<div style="text-align:center;background:var(--bg2);border:1.5px solid var(--border2);padding:8px 12px;border-radius:8px;"><div style="font-size:11px;font-weight:900;color:${st.is_ad.includes('Ad')?'var(--red)':'var(--green)'};">${st.is_ad}</div><div style="font-size:8px;color:var(--text2);">Type</div></div>` : ''}
        </div>
        ${bars}`;
    } else { statsEl.style.display = 'none'; }
  }

  // Hidden Insights (price_metadata decoded)
  const insightsEl = document.getElementById('fetch-insights');
  if (insightsEl) {
    const ins = data.insights || {};
    const hasInsights = ins.supplier_price || ins.inventory || ins.logistics_charge;
    if (hasInsights) {
      insightsEl.style.display = 'block';
      const buyerN     = parseFloat((ins.buyer_price    || '').replace('₹','')) || 0;
      const supplierN  = parseFloat((ins.supplier_price || '').replace('₹','')) || 0;
      const logisticsN = parseFloat((ins.logistics_charge || '').replace('₹','')) || 0;
      const meeshoCut  = buyerN > 0 && supplierN > 0 ? (buyerN - supplierN).toFixed(0) : 0;

      insightsEl.innerHTML = `
        <div class="step-label" style="background:linear-gradient(135deg,#dc2626,#b91c1c);">🔍 Hidden Insights</div>
        <div style="display:flex;gap:6px;margin:8px 0;flex-wrap:wrap;">
          ${ins.buyer_price ? `<div style="flex:1;min-width:70px;text-align:center;background:var(--bg2);border:1.5px solid var(--green);padding:8px;border-radius:8px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Buyer Pays</div><div style="font-size:16px;font-weight:900;color:var(--green);">${ins.buyer_price}</div></div>` : ''}
          ${ins.supplier_price ? `<div style="flex:1;min-width:70px;text-align:center;background:var(--bg2);border:1.5px solid #f59e0b;padding:8px;border-radius:8px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Supplier Gets</div><div style="font-size:16px;font-weight:900;color:#d97706;">${ins.supplier_price}</div></div>` : ''}
          ${meeshoCut > 0 ? `<div style="flex:1;min-width:70px;text-align:center;background:var(--bg2);border:1.5px solid #f59e0b;padding:8px;border-radius:8px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">Meesho Deduction</div><div style="font-size:16px;font-weight:900;color:#d97706;">₹${meeshoCut}</div><div style="font-size:7px;color:var(--text2);">Shipping + COD charges</div></div>` : ''}
        </div>
        <div style="display:grid;grid-template-columns:1fr 1fr;gap:6px;">
          ${ins.logistics_charge ? `<div style="background:var(--bg2);border:1.5px solid #f59e0b;padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">🚚 Shipping Cost (Seller Pe)</div><div style="font-size:14px;font-weight:900;color:#d97706;">${ins.logistics_charge}</div><div style="font-size:8px;color:var(--text2);">Meesho ka actual logistics charge</div></div>` : ''}
          ${ins.cod_charge ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">💳 COD Charge</div><div style="font-size:14px;font-weight:900;color:var(--text);">${ins.cod_charge}</div></div>` : ''}
          ${ins.inventory ? `<div style="background:var(--bg2);border:1.5px solid var(--green);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">📦 Inventory</div><div style="font-size:14px;font-weight:900;color:var(--green);">${Number(ins.inventory).toLocaleString('en-IN')} units</div></div>` : ''}
          ${ins.weight ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">⚖️ Weight</div><div style="font-size:14px;font-weight:900;color:var(--text);">${ins.weight}</div></div>` : ''}
          ${ins.rto_pct_cod ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">↩️ RTO Risk</div><div style="font-size:14px;font-weight:900;color:var(--red);">${ins.rto_pct_cod}</div></div>` : ''}
          ${ins.zone ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">📍 Zone</div><div style="font-size:14px;font-weight:900;color:var(--text);">Zone ${ins.zone}</div></div>` : ''}
          ${ins.cod_discount ? `<div style="background:var(--bg2);border:1px solid var(--border2);padding:7px;border-radius:6px;"><div style="font-size:8px;color:var(--text2);font-weight:700;text-transform:uppercase;">🎁 COD Discount</div><div style="font-size:14px;font-weight:900;color:var(--green);">${ins.cod_discount}</div></div>` : ''}
        </div>`;
    } else { insightsEl.style.display = 'none'; }
  }

  // Similar Products
  const simEl = document.getElementById('fetch-similar');
  if (simEl) {
    if (data.similar?.length) {
      simEl.style.display = 'block';
      simEl.innerHTML = `<div class="step-label" style="background:linear-gradient(135deg,#0891b2,#06b6d4);">🔗 Similar Products (Meesho)</div>
        <div style="display:flex;gap:6px;overflow-x:auto;padding:8px 0 4px;">
          ${data.similar.map(s => `
            <div style="flex-shrink:0;width:80px;cursor:pointer;" onclick="chrome.tabs.create({url:'https://www.meesho.com/${s.slug}'})">
              ${s.image ? `<img src="${s.image}" style="width:80px;height:90px;object-fit:cover;border-radius:6px;border:1.5px solid var(--border2);display:block;margin-bottom:3px;">` : ''}
              <div style="font-size:9px;font-weight:700;line-height:1.3;color:var(--text);overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;">${s.name}</div>
              ${s.price ? `<div style="font-size:11px;font-weight:900;color:var(--green);">₹${s.price}</div>` : ''}
            </div>`).join('')}
        </div>`;
    } else { simEl.style.display = 'none'; }
  }

  // Original Description
  const descOrig = document.getElementById('fetch-desc-orig');
  if (descOrig) descOrig.value = data.description || '';

  // First image download only — JPG with metadata
  const dlWrap = document.getElementById('fetch-dl-imgs');
  if (dlWrap) {
    const firstImg = data.images?.[0];
    if (firstImg) {
      const btn = document.createElement('button');
      btn.className = 'btn btn-black';
      btn.style.cssText = 'font-size:11px;font-weight:900;';
      btn.textContent = '⬇ First Image JPG Download Karo';
      btn.addEventListener('click', async () => {
        btn.disabled = true; btn.textContent = '⏳ Downloading...';
        const ok = await downloadAsJpg(firstImg, 1, data.title);
        btn.textContent = ok ? '✅ Downloaded!' : '❌ Failed — try again';
        setTimeout(() => { btn.disabled = false; btn.textContent = '⬇ First Image JPG Download Karo'; }, 3000);
      });
      dlWrap.innerHTML = '';
      dlWrap.appendChild(btn);
      // Preview
      const prev = document.createElement('img');
      prev.src = firstImg;
      prev.style.cssText = 'width:80px;height:90px;object-fit:cover;border-radius:6px;border:1.5px solid var(--border2);margin-top:8px;display:block;';
      prev.onerror = () => prev.style.display = 'none';
      dlWrap.appendChild(prev);
    } else {
      dlWrap.innerHTML = '<div style="font-size:10px;color:var(--text2);">⚠ Image nahi mili</div>';
    }
  }
}


async function generateFetchListing(data) {
  setStatus('fetch-ai-status', '🤖 AI title + description ban raha hai...', '#0066cc');
  document.getElementById('fetch-ai-title').value = '';
  document.getElementById('fetch-ai-desc').value = '';

  // Detect brands to exclude
  const brandWords = detectBrandWords(data.title, data.attrs);
  const cleanTitle = removeBrandWords(data.title, brandWords);
  const attrText = Object.entries(data.attrs || {}).map(([k,v]) => `${k}: ${v}`).join('\n');

  const prompt = buildFetchPrompt(cleanTitle, data.description, attrText, brandWords, data.category);

  try {
    const raw = await callOpenAI({ model: 'gpt-4o-mini', max_tokens: 2500, messages: [{ role: 'user', content: prompt }] });
    const parsed = parseJSON(raw);
    const toTitleCase = s => s.replace(/\b\w/g, c => c.toUpperCase());
    const stripSpecial = s => s.replace(/[,.\-|/\\:;!?@#$%^&*()[\]{}<>~`'"]/g, ' ').replace(/\s{2,}/g, ' ').trim();
    let title = (parsed.title || '').replace(/kiwtech/gi, '').trim();
    title = stripSpecial(title);
    title = toTitleCase(title);
    if (title.length > 150) title = title.substring(0, 150).replace(/\s+\S*$/, '').trim();
    const desc = (parsed.description || '').replace(/kiwtech/gi, '').trim();
    document.getElementById('fetch-ai-title').value = title;
    document.getElementById('fetch-ai-desc').value = desc;
    document.getElementById('fetch-title-chars').textContent = title.length;
    setStatus('fetch-ai-status', `✅ Done! Title: ${title.length} chars`, '#2e7d32');
  } catch(e) {
    setStatus('fetch-ai-status', '⚠️ AI failed: ' + e.message, '#cc2222');
    document.getElementById('fetch-ai-title').value = cleanTitle;
  }
}

function buildFetchPrompt(title, description, attrText, brands, category) {
  return `You are an expert Meesho India product listing writer. Study the original product title and description carefully and create an improved version.

ORIGINAL TITLE: ${title}
${category ? "CATEGORY: " + category : ""}
${description ? "ORIGINAL DESCRIPTION:\n" + description.slice(0, 800) : ""}
${attrText ? "PRODUCT ATTRIBUTES:\n" + attrText : ""}
${brands.length ? "BRAND NAMES (never use anywhere): " + brands.join(", ") : ""}

YOUR TASK:
Create a new TITLE and DESCRIPTION that uses ALL important keywords from the original — do not invent or remove features.

TITLE RULES — follow exactly:
- Length: STRICTLY 140 to 150 characters — count every character
- Format: Title Case — First Letter Of Every Word Capital
- NO special characters at all: no comma no hyphen no pipe no slash no dot no bracket no percent no ampersand no colon no dash no asterisk
- No brand names anywhere
- Structure: [Adjective] [Product Type] [Key Feature 1] [Key Feature 2] [Benefit] [For Whom] [Size or Quantity if available]
- If too short add more features from attributes; if too long trim last word cleanly

TITLE EXAMPLES — exact format required:
New Kitchen Oil And Grease Stain Remover Spray Degreaser Cleaner For Chimney Stove Grill Tiles Floor Sink PH Neutral 300ml
Premium Cotton Kurti For Women Casual Daily Wear Printed Floral Design Straight Cut Party Festive Collection

DESCRIPTION RULES:
- Length: 500 to 700 words
- 5 paragraphs each 2 to 3 sentences
- Paragraph 1: What the product is and its primary purpose
- Paragraph 2: Who it is for and where it works best
- Paragraph 3: Key ingredients or materials and how they work
- Paragraph 4: How to use it and safety or care instructions
- Paragraph 5: Why best value and closing recommendation
- NO special characters anywhere — no comma no hyphen no pipe no colon no percent no bracket
- Weave ALL keywords from original title naturally into paragraphs
- Natural human English — not robotic or AI sounding

Return ONLY valid JSON:
{"title": "...", "description": "..."}`;
}
async function handleFetchRegen() {
  if (!fetchedProduct) { alert('Pehle Fetch karo'); return; }
  await generateFetchListing(fetchedProduct);
}

async function handleFetchAutofill() {
  const btn       = document.getElementById('fetchAutofillBtn');
  const statusEl  = document.getElementById('fetch-ai-status');
  const cloneChk  = document.getElementById('fetchCloneCheckbox');
  const useClone  = cloneChk?.checked || false;
  const data      = fetchedProduct || {};

  // Decide title + description source
  let useTitle, useDesc;
  if (useClone) {
    useTitle = data.title || '';
    useDesc  = data.description || '';
    if (!useTitle) { setStatus(statusEl, '⚠ Original title nahi mila', 'error'); return; }
  } else {
    useTitle = document.getElementById('fetch-ai-title').value.trim();
    useDesc  = document.getElementById('fetch-ai-desc').value.trim();
    if (!useTitle) { setStatus(statusEl, '⚠ Pehle Generate karo', 'error'); return; }
  }

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner"></span> Autofill ho raha hai...';
  setStatus(statusEl, '🔍 Meesho supplier form scan ho raha hai...', 'info');

  try {
    // Step 1: Deep scan supplier form
    let scanned = [];
    const scanRes = await sendToBackground({ type: 'DEEP_SCAN' });
    if (scanRes?.success && scanRes.fields?.length > 0) scanned = scanRes.fields;

    setStatus(statusEl, '🤖 AI fields generate kar raha hai...', 'info');

    // Step 2: Build description for AI — include original attrs
    const attrText = Object.entries(data.attrs || {}).map(([k,v]) => `${k}: ${v}`).join('\n');
    const priceOverride = document.getElementById('fetchMeeshoPrice')?.value?.trim() || '';
    const descForAI = [
      `Product: ${useTitle}`,
      useDesc ? `Description: ${useDesc}` : '',
      attrText ? `Product Attributes:\n${attrText}` : '',
      data.category ? `Category: ${data.category}` : '',
      priceOverride ? `Meesho selling price: ₹${priceOverride}` : '',
    ].filter(Boolean).join('\n\n');

    // Step 3: Generate fields with AI (same as image tab)
    let fields = await generateFieldsWithAI(descForAI, scanned);
    fields = await postProcessFields(fields, scanned, priceOverride);
    fields = await applySellerDetails(fields, scanned);

    // Step 4: Override title + description with chosen source
    const overrideField = (labels, value) => {
      if (!value) return;
      const existing = fields.findIndex(f => labels.some(l => (f.label || '').toLowerCase().includes(l)));
      const sc = scanned.find(sf => labels.some(l => (sf.label || '').toLowerCase().includes(l)));
      if (existing >= 0) fields[existing].value = value;
      else if (sc) fields.push({ selector: sc.selector, label: labels[0], value });
    };
    overrideField(['product name', 'name', 'title'], useTitle);
    overrideField(['description', 'about', 'detail'], useDesc);

    // Step 5: Also inject attrs from fetched product into fields
    if (Object.keys(data.attrs || {}).length > 0) {
      Object.entries(data.attrs).forEach(([attrKey, attrVal]) => {
        const sc = scanned.find(sf => {
          const l = (sf.label || '').toLowerCase();
          return l === attrKey.toLowerCase() || l.includes(attrKey.toLowerCase());
        });
        if (sc) {
          const exists = fields.findIndex(f => f.selector === sc.selector);
          if (exists < 0) fields.push({ selector: sc.selector, label: attrKey, value: String(attrVal) });
        }
      });
    }

    setStatus(statusEl, '🚀 Meesho form fill ho raha hai...', 'info');

    // Step 6: Autofill
    const autofillRes = await sendToBackground({ type: 'AUTOFILL_FIELDS', fields });
    if (autofillRes?.success) {
      setStatus(statusEl, `✅ ${autofillRes.filled || fields.length} fields autofill ho gaye! ${useClone ? '(Original Clone)' : '(AI Generated)'}`, 'success');
    } else {
      setStatus(statusEl, `⚠ ${autofillRes?.error || 'Partial fill'}`, 'error');
    }

  } catch(e) {
    setStatus(statusEl, `❌ ${e.message}`, 'error');
  } finally {
    btn.disabled = false;
    btn.textContent = '🚀 Autofill on Meesho Tab';
  }
}

// Brand detection helpers
function detectBrandWords(title, attrs) {
  const brands = new Set();
  const brandVal = attrs?.Brand || attrs?.brand;
  if (brandVal) brands.add(brandVal.toLowerCase());
  (title || '').split(/\s+/).forEach(w => {
    if (/^[A-Z][a-z]{3,}$/.test(w) && !isCommonProductWord(w)) brands.add(w.toLowerCase());
  });
  return [...brands];
}

function removeBrandWords(title, brands) {
  let clean = title;
  brands.forEach(b => { clean = clean.replace(new RegExp('\\b' + b + '\\b', 'gi'), '').replace(/\s{2,}/g, ' ').trim(); });
  return clean;
}

function isCommonProductWord(w) {
  const c = new Set(['With','From','For','And','The','This','That','Pure','Soft','Free','Anti',
    'Pack','Set','Kit','New','Top','Red','Blue','Green','Black','White','Pink','Cotton','Print',
    'Wash','Care','Daily','Home','Women','Mens','Kids','Saree','Kurti','Shirt','Pant','Coat','Oil',
    'Gel','Face','Hair','Body','Hand','Baby','Mini','Maxi','Plus','Lite','Pro','Max','Star','Gold']);
  return c.has(w);
}

// ═══════════════════════════════════════════════════════════════════
// FEATURE 3 — VISUAL SEARCH: Image → Similar Meesho products
// ═══════════════════════════════════════════════════════════════════
let vizImageBase64 = null;

function handleVizImagePreview() {
  const file = document.getElementById('vizSearchImageInput').files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = e => {
    vizImageBase64 = e.target.result.split(',')[1];
    document.getElementById('viz-preview-img').src = e.target.result;
    document.getElementById('viz-preview-wrap').style.display = 'block';
  };
  reader.readAsDataURL(file);
}

async function handleVisualSearch() {
  if (!vizImageBase64) { alert('Pehle image select karo'); return; }
  const keyword = document.getElementById('vizSearchKeyword').value.trim();
  setStatus('viz-status', '🤖 Image deeply analyze ho rahi hai...', '#7c3aed');
  document.getElementById('viz-results').style.display = 'none';

  try {
    // Step 1: AI se exact product attributes nikalo — very specific
    const descPrompt = `You are a visual product analyst for e-commerce. Look at this product image VERY carefully.

Extract EXACT attributes:
1. product_type: The SPECIFIC product name (e.g. "round plastic flower pot with saucer" not just "pot")
2. main_keyword: Best 2-3 word search query for finding this EXACT product on Meesho (specific, not generic)
3. search_queries: Array of 4 different specific search queries, most specific first
4. color: exact color(s) visible
5. material: material/fabric visible
6. style: design style, shape, pattern
7. size_clue: any size indicators visible
8. filter_keywords: Array of 8-10 specific keywords that MUST appear in a matching product title
9. reject_keywords: Array of words that would indicate a DIFFERENT type of product

Return ONLY valid JSON, nothing else.`;

    const raw = await callOpenAI({
      model: 'gpt-4o-mini',
      max_tokens: 700,
      messages: [{
        role: 'user',
        content: [
          { type: 'image_url', image_url: { url: `data:image/jpeg;base64,${vizImageBase64}` } },
          { type: 'text', text: descPrompt }
        ]
      }]
    });

    const aiResult = parseJSON(raw);
    if (!aiResult || !aiResult.product_type) throw new Error('Image analyze nahi ho saki');

    const mainKw = keyword || aiResult.main_keyword || aiResult.product_type;
    setStatus('viz-status', `🔍 "${mainKw}" — Meesho pe dhundh raha hoon...`, '#7c3aed');

    // Show detected info
    const detEl = document.getElementById('viz-detected');
    const detInfo = document.getElementById('viz-detected-info');
    if (detEl && detInfo) {
      detEl.style.display = 'block';
      detInfo.innerHTML = `
        <div style="font-weight:800;font-size:11px;margin-bottom:4px;">${aiResult.product_type}</div>
        <div style="font-size:10px;color:#555;margin-bottom:5px;">${aiResult.description || ''}</div>
        <div style="display:flex;gap:4px;flex-wrap:wrap;">
          ${aiResult.color ? `<span style="background:#e8f5e9;padding:2px 8px;border:1px solid #86efac;font-size:9px;border-radius:10px;">🎨 ${aiResult.color}</span>` : ''}
          ${aiResult.material ? `<span style="background:#eff6ff;padding:2px 8px;border:1px solid #93c5fd;font-size:9px;border-radius:10px;">🧵 ${aiResult.material}</span>` : ''}
          ${aiResult.style ? `<span style="background:#fdf4ff;padding:2px 8px;border:1px solid #e9d5ff;font-size:9px;border-radius:10px;">✨ ${aiResult.style}</span>` : ''}
        </div>`;
    }

    // Step 2: Meesho search with most specific query
    const queries = aiResult.search_queries || [mainKw];
    let allProducts = [];

    const tabs = await new Promise(r => chrome.tabs.query({}, r));
    let meeshoTab = tabs.find(t => t.url && t.url.includes('meesho.com') && !t.url.includes('supplier'));

    for (let qi = 0; qi < Math.min(queries.length, 3); qi++) {
      const q = queries[qi];
      setStatus('viz-status', `🔍 Query ${qi+1}/${Math.min(queries.length,3)}: "${q}"...`, '#7c3aed');

      try {
        const searchUrl = 'https://www.meesho.com/search?q=' + encodeURIComponent(q);
        if (meeshoTab) {
          await new Promise(r => chrome.tabs.update(meeshoTab.id, { url: searchUrl }, r));
        } else {
          meeshoTab = await new Promise(r => chrome.tabs.create({ url: searchUrl, active: false }, r));
        }
        await new Promise(r => setTimeout(r, 2800));

        const results = await chrome.scripting.executeScript({
          target: { tabId: meeshoTab.id },
          func: () => {
            try {
              const nd = window.__NEXT_DATA__;
              const pp = nd?.props?.pageProps?.initialState;
              const catalogs = pp?.catalog?.feed?.catalogs || pp?.search?.feed?.catalogs || pp?.catalog?.catalogs || [];
              if (catalogs.length > 0) {
                return catalogs.slice(0, 24).map(c => ({
                  title: c.catalog_name || c.name || '',
                  price: String(c.meesho_price || c.price || ''),
                  mrp: String(c.mrp || ''),
                  discount: c.discount_percent ? c.discount_percent + '% off' : '',
                  rating: String(c.rating || ''),
                  reviews: String(c.ratings_count || ''),
                  image: c.catalog_images?.[0]?.url || '',
                  url: window.location.origin + '/' + (c.slug || ''),
                }));
              }
              // DOM fallback
              const cards = document.querySelectorAll('[class*="ProductCard"],[class*="CatalogCard"],[data-testid="product-card"]');
              const out = [];
              cards.forEach(card => {
                if (out.length >= 20) return;
                const t = card.querySelector('p,h4,[class*="name"]')?.innerText?.trim() || '';
                const p = card.querySelector('[class*="price"]')?.innerText?.replace(/[^0-9]/g,'') || '';
                const img = card.querySelector('img')?.src || '';
                const link = card.querySelector('a')?.href || '';
                if (t.length > 3) out.push({ title:t, price:p, image:img, url:link });
              });
              return out;
            } catch(e) { return []; }
          }
        });

        const qProducts = results[0]?.result || [];
        qProducts.forEach(p => {
          if (!allProducts.find(x => x.title === p.title)) allProducts.push(p);
        });
      } catch(e) { console.log('Query failed:', q, e.message); }
    }

    if (!allProducts.length) {
      setStatus('viz-status', '⚠️ Products nahi mile.', '#e65100'); return;
    }

    // Step 3: AI similarity scoring — filter out unrelated products
    setStatus('viz-status', `🤖 ${allProducts.length} products mein se similar filter kar raha hoon...`, '#7c3aed');

    const filterKWs = (aiResult.filter_keywords || []).map(k => k.toLowerCase());
    const rejectKWs = (aiResult.reject_keywords || []).map(k => k.toLowerCase());
    const targetColor = (aiResult.color || '').toLowerCase();
    const targetMaterial = (aiResult.material || '').toLowerCase();
    const targetStyle = (aiResult.style || '').toLowerCase();
    const targetType = (aiResult.product_type || '').toLowerCase();

    // Score each product for visual similarity
    const scored = allProducts.map(p => {
      const titleLower = p.title.toLowerCase();
      let score = 0;

      // Reject if reject keywords found
      if (rejectKWs.some(rk => titleLower.includes(rk))) return { ...p, score: -1 };

      // Filter keyword matches (most important)
      filterKWs.forEach(fk => { if (titleLower.includes(fk)) score += 3; });

      // Color match
      if (targetColor && titleLower.includes(targetColor.split(' ')[0])) score += 2;

      // Material match
      if (targetMaterial) {
        targetMaterial.split(' ').forEach(m => { if (m.length > 3 && titleLower.includes(m)) score += 2; });
      }

      // Style match
      if (targetStyle) {
        targetStyle.split(' ').forEach(s => { if (s.length > 3 && titleLower.includes(s)) score += 1; });
      }

      // Product type words match
      targetType.split(' ').forEach(w => { if (w.length > 3 && titleLower.includes(w)) score += 2; });

      // Penalize if title seems totally different category
      const mainTypeWord = targetType.split(' ')[0];
      if (mainTypeWord && mainTypeWord.length > 3 && !titleLower.includes(mainTypeWord)) score -= 2;

      return { ...p, score };
    });

    // Sort by score, filter out negative
    const filtered = scored
      .filter(p => p.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 12);

    const finalProducts = filtered.length >= 4 ? filtered : scored.sort((a,b) => b.score - a.score).slice(0, 12);

    setStatus('viz-status', `✅ ${finalProducts.length} similar products mile!`, '#2e7d32');
    renderVizProducts(finalProducts, aiResult);

  } catch(e) {
    setStatus('viz-status', '❌ Error: ' + e.message, '#cc2222');
  }
}

function renderVizProducts(products, aiResult) {
  document.getElementById('viz-count').textContent = products.length;
  document.getElementById('viz-results').style.display = 'block';
  document.getElementById('viz-keyword-used').textContent =
    'Detected: ' + (aiResult.product_type || '') +
    (aiResult.color ? ' | ' + aiResult.color : '') +
    (aiResult.material ? ' | ' + aiResult.material : '');

  const list = document.getElementById('viz-products-list');
  list.innerHTML = products.map((p, i) => {
    const price = p.price ? parseInt(p.price) : 0;
    const scoreBar = Math.min(100, Math.round((p.score / 15) * 100));
    return `
    <div style="display:flex;gap:8px;border:1.5px solid var(--border2);border-radius:8px;padding:8px;margin-bottom:7px;background:#fff;box-shadow:0 1px 4px rgba(91,91,214,0.07);">
      <div style="flex-shrink:0;position:relative;">
        ${p.image ? `<img src="${p.image}" style="width:62px;height:72px;object-fit:cover;border-radius:5px;border:1px solid var(--border2);" onerror="this.style.display='none'">` : '<div style="width:62px;height:72px;background:var(--bg2);border-radius:5px;"></div>'}
        <div style="position:absolute;top:2px;left:2px;background:var(--accent);color:#fff;font-size:8px;font-weight:900;padding:1px 5px;border-radius:10px;">#${i+1}</div>
        ${p.score >= 8 ? '<div style="position:absolute;bottom:2px;left:2px;background:#059669;color:#fff;font-size:7px;font-weight:900;padding:1px 4px;border-radius:10px;">✓ MATCH</div>' : ''}
      </div>
      <div style="flex:1;min-width:0;">
        <div style="font-size:10px;font-weight:700;line-height:1.4;margin-bottom:4px;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;">${p.title}</div>
        <div style="display:flex;align-items:center;gap:8px;margin-bottom:4px;">
          <span style="font-size:15px;font-weight:900;color:#059669;">₹${price || '—'}</span>
          ${p.rating ? `<span style="font-size:9px;color:#f59e0b;font-weight:700;">⭐ ${p.rating}</span>` : ''}
          ${p.reviews ? `<span style="font-size:9px;color:var(--text2);">${p.reviews} reviews</span>` : ''}
        </div>
        <div style="background:var(--bg2);border-radius:20px;height:4px;margin-bottom:5px;overflow:hidden;">
          <div style="height:100%;width:${scoreBar}%;background:linear-gradient(135deg,var(--accent),#7c3aed);border-radius:20px;"></div>
        </div>
        <div style="display:flex;gap:5px;">
          ${p.url ? `<button onclick="chrome.tabs.create({url:'${p.url}'})" style="flex:1;padding:4px 0;background:var(--accent);color:#fff;border:none;border-radius:5px;font-size:9px;font-weight:800;cursor:pointer;">🔗 Open</button>` : ''}
          <button onclick="navigator.clipboard.writeText('${p.title.replace(/'/g,"\'")}').then(()=>this.textContent='✓').catch(()=>{})" style="padding:4px 8px;background:var(--bg2);color:var(--text2);border:1px solid var(--border);border-radius:5px;font-size:9px;cursor:pointer;">📋</button>
        </div>
      </div>
    </div>`;
  }).join('');
}
// ═══════════════════════════════════════════════════════════════════════
// Kiwtech Meesho Tool v4.0 — popup.js (Serverless + Integrated SEO)
// ═══════════════════════════════════════════════════════════════════════

let licenseKey       = "";
let lastFields       = null;
let scannedFields    = null;
let imgScannedFields = null;
let imgLastText      = "";
let adminPass        = "";

// Global state for integrated SEO in Image tab
let imgGeneratedTitle = "";
let imgGeneratedDesc  = "";
let imgSelectedKeywords = [];
let imgOriginalFile   = null;  // Keep original file for metadata writing
let imgVariationCount = 0;     // Har generate pe badh ta hai — AI ko alag likhe ne pe force karta hai

// ── Prompts ───────────────────────────────────────────────────────────────────
const FORM_SYSTEM_PROMPT = `You are a Meesho supplier panel expert. You receive a product description and the EXACT scanned form fields from the Meesho listing page.

Your job: fill AS MANY fields as possible — leave NOTHING empty that you can reasonably infer.

Return ONLY a valid JSON array (no markdown, no explanation):
[
  {"selector": "EXACT_SELECTOR_FROM_INPUT", "label": "Field Label", "value": "generated value"},
  ...
]

FIELD-FILLING RULES:
- Use the EXACT selector strings from input — never modify them
- Fill EVERY field you can, even if you have to infer/guess reasonably
- Numbers only (no symbols) for: price, weight, pincode, HSN, MRP, inventory fields

DROPDOWN RULES (MUISELECT fields):
- GST: use exactly "5%" or "12%" or "18%" — match the dropdown option text with % symbol
- Shelf Life / Best Before: use "24 Months" as default for most products; use "6 Months" for perishables
- Country of Origin: use exactly "India"
- Net Quantity: use "1"
- Size: use "Free Size" for clothing unless specific size mentioned
- Add On: leave empty / skip if unsure

SPECIFIC FIELD RULES:
- Product Name: clear, keyword-rich, max 100 chars
- Net Weight (gms): weight in grams as number only (estimate if not given — e.g. 200 for shampoo, 500 for clothing)
- HSN Code: infer from product type:
    clothing/apparel = 6109, shampoo/hair oil = 33051010, hair care = 33059090,
    footwear = 6402, electronics = 8517, cosmetics = 3304, oils = 1515, food = 2106
- Description: Write 5-6 detailed sentences covering: key features, ingredients/material, benefits, how to use, who it's for, and results to expect. Then add a line: "Keywords: [10-15 relevant SEO keywords separated by commas]" at the end of the description. Make the full description minimum 80 words.
- Color: primary color(s) of product
- Style Code / Product ID: leave as-is if already set by system
- Manufacturer/Packer/Importer Name, Address, Pincode: leave EMPTY — these come from seller settings
- Importer Name/Address/Pincode: use "Not Required" if field is visible
- Wrong/Defective Returns Price: Meesho selling price MINUS 1 (e.g. if price=289, wrong return=288)
- MRP: 3x the Meesho selling price (round to nearest 10)
- Brand: leave empty unless clearly mentioned in description

Return ONLY the JSON array. No markdown. No explanation. No extra text.`;

const TEXT_SYSTEM_PROMPT = `You are a Meesho product listing expert. Given a product description, extract and generate structured listing fields.

Return ONLY a valid JSON object with these exact keys (use empty string "" if unknown):
{
  "product_name": "Full product name (max 100 chars)",
  "color": "Primary color(s)",
  "meesho_price": "Selling price in INR (numbers only)",
  "product_mrp": "MRP in INR (numbers only)",
  "only_wrong_return_price": "Wrong return price in INR (meesho_price minus 1)",
  "inventory": "999",
  "supplier_gst_percent": "GST % number only (5/12/18)",
  "hsn_code": "HSN code",
  "product_weight_in_gms": "Weight in grams (number only)",
  "supplier_product_id": "Short unique SKU",
  "category": "Meesho product category",
  "brand": "",
  "description": "5-6 detailed sentences covering features, ingredients/material, benefits, how to use, and results. End with: Keywords: [10-15 SEO keywords separated by commas]. Minimum 80 words."
}

Rules:
- All price/number fields: ONLY digits
- GST if not mentioned: infer from product type (clothing/apparel=5, hair care/shampoo/cosmetics/electronics/general products=18)
- HSN if not mentioned: infer from category
- Return ONLY the JSON object, no markdown`;

const IMAGE_SYSTEM_PROMPT = `You are a Meesho product listing expert. Analyze the product image and generate a complete listing description including: product name, color, material, style, use case, estimated weight, and suggested price range in Indian Rupees. Be specific and detailed.`;

// ── Integrated SEO Prompts (used inside Image tab) ────────────────────────────
const SEO_KEYWORDS_PROMPT = `You are a Meesho India SEO expert. Given a product keyword, generate exactly 15 high-converting SEO keywords for Meesho product listings targeting Indian buyers.

Rules:
- Keywords should be in English (as used on Meesho)
- Mix of short-tail and long-tail keywords
- Include buyer intent terms: "for women", "for men", "buy online", "price", "stylish", "latest", "new", "best", etc.
- Include size/material/occasion terms relevant to this product category
- No duplicate meanings
- Return ONLY a JSON array of 15 strings, nothing else. Example: ["keyword 1","keyword 2",...]`;

const SEO_TITLE_DESC_PROMPT = `You are an expert Meesho India product listing writer. Write SEO-optimized titles and descriptions exactly like the examples shown below.

CRITICAL RULE — BRAND NAMES (highest priority):
- NEVER include any brand name anywhere — not Zvizoro, Amazon, Meesho, Himalaya, Patanjali, Dabur, Mamaearth, WOW, Boat, Nykaa, Lakme, Garnier, Loreal, Nivea, Dove, or any other company or brand name
- If a keyword contains a brand name, silently use only the non-brand product part
- This rule overrides everything else

UNIQUENESS RULE:
- Every variation must open with a DIFFERENT word from this rotation:
  1:New 2:Trendy 3:Natural 4:Advanced 5:Premium 6:Herbal 7:Pure 8:Elegant 9:Classic 10:Latest
  11:Stylish 12:Exclusive 13:Stunning 14:Charming 15:Vibrant 16:Superior 17:Radiant 18:Gorgeous 19:Splendid 20:Fabulous
  (for 21+ cycle back but change the rest completely)

TITLE FORMAT (follow exactly):
[Opening Word from rotation] [Product Name] [Key Ingredient or Feature 1] [Key Ingredient or Feature 2] [Main Benefit] [For Men And Women OR For Women OR For Men] [Secondary Use or Occasion] [Size or Quantity if available]

TITLE RULES:
- STRICTLY 140 to 150 characters — count carefully, trim at last complete word if needed
- Title Case: First Letter Of Every Word Capital
- NO special characters: no commas no hyphens no slashes no brackets no percent no at no ampersand no asterisk no pipe no hash no trademark no registered
- Must read like a real product title — natural and logical flow
- Include the primary keyword near the beginning

TITLE EXAMPLES — this is the exact quality required:
New Jamalgota Hair Growth Powder Ayurvedic Hair Fall Control With Bhringraj Amla And Brahmi Regrowth For Men And Women Herbal Hair Care 50ml
Trendy Jamalgota Powder For Hair Growth With Amla Reetha Shikakai Bhringraj Natural Herbal Solution For Women And Men 100 Percent Herbal And Safe 100gm
New Varicose Veins Spray Natural Herbal Formula For Athletes Fast Relief Reduces Pain And Promotes Blood Circulation Easy To Use Health Care Spray 60ml
Advanced 16 Percent Vitamin C Face Serum Brightening With Vitamin E And Ferulic Acid For Glowing Skin For Men And Women Anti Aging Skin Care 30ml
Premium Cotton Kurti For Women Casual Daily Wear Printed Floral Design Straight Cut Party Festive Collection Latest Designer Indian Ethnic Dress
Natural Argan Hair Oil For Women And Men Deep Conditioning Controls Frizz Promotes Hair Growth With Keratin And Vitamin E 100ml

DESCRIPTION FORMAT — 5 sentences each with a specific job:
Sentence 1: What the product is and its primary material or ingredient or key feature — weave in 1 to 2 keywords
Sentence 2: Who it is for and occasions or uses where it excels — weave in 3 to 4 keywords naturally
Sentence 3: How it works and key benefits and what makes it special — weave in 3 to 4 keywords
Sentence 4: How to use it and size or quantity or care instructions — weave in 2 to 3 keywords
Sentence 5: Why it is the best choice and value for money and closing — weave in 3 to 4 remaining keywords

DESCRIPTION RULES:
- Total 400 to 500 words
- NO special characters — no commas no hyphens no brackets no asterisks no slashes
- Every sentence must be grammatically correct and make complete logical sense
- Weave keywords naturally — do NOT dump keywords in a list
- Do NOT repeat any keyword more than 2 times across all 5 sentences
- Write in natural flowing English; Hindi product terms like kurti dupatta saree are fine where natural

DESCRIPTION EXAMPLES — this is the exact quality required:
Example hair powder: This ayurvedic hair growth powder is crafted with pure jamalghota beej combined with bhringraj amla and brahmi powder for a complete hair care solution. It is ideal for women and men facing hair fall dandruff and slow hair regrowth who are seeking a 100 percent natural and herbal remedy. The powerful combination of reetha shikakai and jamalgota works deep into the roots to control hair fall strengthen follicles and promote faster regrowth with regular use. Simply mix a small quantity with water or coconut oil and apply directly to the scalp twice a week leaving it for 30 minutes before washing. This trusted herbal hair care formula is completely safe for all hair types and delivers visible results within weeks making it the best natural solution for healthy thick and shiny hair.
Example face serum: This advanced vitamin C face serum contains 16 percent pure vitamin C combined with vitamin E ferulic acid and fullerenes for deep skin brightening and cellular repair. It is suitable for all skin types and is especially effective for men and women dealing with dark spots uneven skin tone dullness and early signs of aging in their daily skin care routine. The potent antioxidant formula boosts collagen production reduces pigmentation and delivers a natural glowing skin effect with consistent morning application. Apply 2 to 3 drops on a clean face every morning before sunscreen and allow it to absorb fully for maximum brightening and anti aging benefits. A complete brightening serum that combines the best of vitamin C serum vitamin E and ferulic acid into one powerful 30ml bottle for visibly radiant and youthful skin.

Return ONLY valid JSON — no markdown no explanation:
{"title": "...", "description": "..."}`;

const HINDI_KEYWORDS_PROMPT = `You are a Meesho India SEO expert. Given a product name and English keywords, generate exactly 10 Hindi product keywords written in Hinglish (Hindi words written in English/Roman script, as Indians type on Meesho).

Rules:
- Write Hindi words in Roman/English letters (Hinglish style) — e.g. "lal saree", "kapde for ladies", "sasta kurti", "ghar ke liye bedsheet"
- These are for image metadata Tags field
- Make them natural search phrases Indian buyers actually type
- No English, only Hinglish
- Return ONLY a JSON array of exactly 10 strings. Example: ["lal saree online","sasta kurti","ladies kapde"]`;

const MANUFACTURER_COMMENT_PROMPT = `You are a product description writer. Given a manufacturer/company name, write a professional 200-word description about this manufacturer for image metadata Comments field.

Rules:
- Write about the company: their products, quality commitment, heritage, values, customer focus
- Sound professional and trustworthy
- 200 words exactly (between 190-210 words)
- NO special characters — only plain letters spaces and numbers
- Return ONLY the plain text description, no JSON, no quotes`;

// ── Init ──────────────────────────────────────────────────────────────────────
document.addEventListener("DOMContentLoaded", async () => {
  await initExtension();
  wireListeners();
  loadDefaultsUI();
  loadSellerDetailsUI();
  loadPricingRulesUI();
  loadCaptureProfiles();
  scribbleLoadSavedList();
  loadOpenAIKeyUI();
  wireImageMetadataInputs();
});

async function initExtension() {
  // Backend-based: validate via background which uses backend
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "CHECK_LOGIN" }, r => resolve(r || { success: false }));
  });
  if (res.success && res.valid) {
    const stored = await chromeGet(["licenseKey"]);
    licenseKey = stored.licenseKey || "";
    showMain(licenseKey);
  } else {
    licenseKey = "";
    showAuth();
  }
}

// ── Screens ───────────────────────────────────────────────────────────────────
function showAuth() {
  document.getElementById("auth-screen").style.display = "block";
  document.getElementById("main-content").style.display = "none";
  document.getElementById("admin-panel").style.display = "none";
}
function showMain(key) {
  document.getElementById("auth-screen").style.display = "none";
  document.getElementById("main-content").style.display = "block";
  document.getElementById("admin-panel").style.display = "none";
  const badge = document.getElementById("license-badge");
  if (badge) badge.textContent = `✓ Active: ${key.slice(0,14)}...`;
  chromeGet(["sellerDetails"]).then(stored => {
    const d = stored.sellerDetails || {};
    if (!d.manufacturer_name) {
      switchTab("tab-defaults");
      const warn = document.getElementById("setup-warning");
      if (warn) warn.style.display = "block";
    }
  });
}
function showAdminPanel() {
  document.getElementById("auth-screen").style.display = "none";
  document.getElementById("main-content").style.display = "none";
  document.getElementById("admin-panel").style.display = "block";
}

// Open web-based admin panel (Cloudflare Worker hosted)
function openWebAdmin() {
  chrome.runtime.sendMessage({ type: "GET_BACKEND_URL" }, res => {
    if (res && res.url && !res.url.includes("YOUR-SUBDOMAIN")) {
      chrome.tabs.create({ url: res.url + "/admin" });
    } else {
      alert("Backend URL configure nahi hai. background.js mein BACKEND_URL set karein.");
    }
  });
}

// ── License (local) ───────────────────────────────────────────────────────────
async function validateLicenseLocal(key) {
  return new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "VALIDATE_LICENSE", key }, res => {
      if (chrome.runtime.lastError || !res) resolve(false);
      else resolve(res.valid === true);
    });
  });
}

// ── Wire Listeners ────────────────────────────────────────────────────────────
function wireListeners() {
  // Auth
  document.getElementById("authLoginBtn").addEventListener("click", handleLogin);
  document.getElementById("authLicenseKey").addEventListener("keydown", e => { if (e.key === "Enter") handleLogin(); });
  document.getElementById("openAdminFromAuth").addEventListener("click", openWebAdmin);
  document.getElementById("authDemoBtn").addEventListener("click", handleDemoRequestFromAuth);

  // Main
  document.getElementById("logoutBtn").addEventListener("click", async () => {
    await new Promise(r => chrome.runtime.sendMessage({ type: "LOGOUT" }, r));
    licenseKey = "";
    showAuth();
  });
  document.getElementById("adminBtn").addEventListener("click", openWebAdmin);
  document.querySelectorAll(".tab-btn").forEach(btn => btn.addEventListener("click", () => switchTab(btn.dataset.tab)));

  // ── NEW: Fetch tab ──────────────────────────────────────────────────
  document.getElementById("fetchProductBtn")?.addEventListener("click", handleFetchProduct);
  document.getElementById("fetchByCatalogIdBtn")?.addEventListener("click", handleFetchByCatalogId);
  document.getElementById("fetchRegenBtn")?.addEventListener("click", handleFetchRegen);
  document.getElementById("fetchAutofillBtn")?.addEventListener("click", handleFetchAutofill);

  // ── NEW: Compare tab ────────────────────────────────────────────────
  document.getElementById("saveProductABtn")?.addEventListener("click", () => saveCompareSlot("A"));
  document.getElementById("saveProductBBtn")?.addEventListener("click", () => saveCompareSlot("B"));
  document.getElementById("compareNowBtn")?.addEventListener("click", handleCompare);

  // ── NEW: Visual Search tab ──────────────────────────────────────────
  document.getElementById("vizSearchImageInput")?.addEventListener("change", handleVizImagePreview);
  document.getElementById("vizSearchBtn")?.addEventListener("click", handleVisualSearch);

  // Image tab
  document.getElementById("imgScanFormBtn").addEventListener("click", scanFormImg);
  document.getElementById("imgGetKeywordsBtn").addEventListener("click", handleImgGetKeywords);
  document.getElementById("generateFromImage").addEventListener("click", handleGenerateFromImage);
  document.getElementById("imgAutofillBtn").addEventListener("click", handleImgAutofill);
  document.getElementById("quickImgAutofillBtn").addEventListener("click", handleQuickAutofill);
  document.getElementById("imgWriteMetaBtn").addEventListener("click", handleWriteImageMetadata);
  document.getElementById("imgRegenerateBtn").addEventListener("click", handleGenerateFromImage);

  // Copy buttons for integrated SEO
  document.getElementById("imgCopyTitleBtn").addEventListener("click", () => {
    const val = document.getElementById("img-seo-title").value;
    navigator.clipboard.writeText(val).then(() => {
      document.getElementById("imgCopyTitleBtn").textContent = "✅ Copied!";
      setTimeout(() => document.getElementById("imgCopyTitleBtn").textContent = "📋 Title Copy", 2000);
    });
  });
  document.getElementById("imgCopyDescBtn").addEventListener("click", () => {
    const val = document.getElementById("img-seo-desc").value;
    navigator.clipboard.writeText(val).then(() => {
      document.getElementById("imgCopyDescBtn").textContent = "✅ Copied!";
      setTimeout(() => document.getElementById("imgCopyDescBtn").textContent = "📋 Description Copy", 2000);
    });
  });

  // Text tab
  // Keyword Hunter
  document.getElementById("kwh-start-btn").addEventListener("click", kwhStart);
  document.getElementById("kwh-stop-btn").addEventListener("click", kwhStop);
  document.getElementById("kwh-copy-btn").addEventListener("click", kwhCopyAll);
  document.getElementById("kwh-clear-btn").addEventListener("click", kwhClear);
  document.getElementById("kwh-send-scribbles-btn").addEventListener("click", kwhSendToScribbles);

  // Defaults
  document.getElementById("addFieldBtn").addEventListener("click", addDefaultField);
  document.getElementById("saveDefaultsBtn").addEventListener("click", saveDefaults);
  document.getElementById("clearDefaultsBtn").addEventListener("click", clearDefaults);
  document.getElementById("saveSellerBtn").addEventListener("click", saveSellerDetails);
  document.getElementById("savePricingRulesBtn").addEventListener("click", savePricingRules);

  // Packer same-as-mfr toggle
  document.getElementById("packer-same-as-mfr").addEventListener("change", function() {
    const extra = document.getElementById("packer-fields-extra");
    const note  = document.getElementById("packer-same-note");
    if (this.checked) { extra.style.display = "none"; note.style.display = "block"; }
    else              { extra.style.display = "block"; note.style.display = "none"; }
  });

  // Importer not-required toggle
  document.getElementById("importer-not-required").addEventListener("change", function() {
    const extra = document.getElementById("importer-fields-extra");
    extra.style.display = this.checked ? "none" : "block";
  });

  // Buy Now + Demo
  document.getElementById("buyNowBtn").addEventListener("click", handleBuyNow);
  document.getElementById("demoBtn").addEventListener("click", handleDemoRequest);

  // Scribbles
  document.getElementById("scribble-load-kw-btn").addEventListener("click", scribbleLoadKeywords);
  document.getElementById("scribble-clear-kw-btn").addEventListener("click", scribbleClearKeywords);
  document.getElementById("scribble-ai-gen-btn")?.addEventListener("click", scribbleAiGenerate);
  document.getElementById("scribble-save-btn").addEventListener("click", scribbleSave);
  document.getElementById("scribble-reset-btn").addEventListener("click", scribbleReset);
  document.getElementById("scribble-use-in-ai").addEventListener("change", function() {
    document.getElementById("scribble-ai-select-wrap").style.display = this.checked ? "block" : "none";
    if (this.checked) scribblePopulateAiSelect();
  });
  document.getElementById("scribble-apply-targets-btn").addEventListener("click", scribbleRenderDensityTable);
  // Image tab — Title & Description source (AI / saved scribble)
  document.querySelectorAll('input[name="imgTdSrc"]').forEach(r => r.addEventListener("change", async () => { await scribblePopulateAiSelect(); imgTdSourceUpdate(); }));
  document.getElementById("img-scribble-select")?.addEventListener("change", imgTdSourceUpdate);
  (async () => {
    await scribblePopulateAiSelect();
    const st = await chromeGet(["imgTdSrc", "imgTdScribble"]);
    if (st.imgTdSrc === "scribble") { const r = document.querySelector('input[name="imgTdSrc"][value="scribble"]'); if (r) r.checked = true; }
    const sel = document.getElementById("img-scribble-select");
    if (sel && st.imgTdScribble) sel.value = st.imgTdScribble;
    imgTdSourceUpdate();
  })();
  document.getElementById("scribble-title-editor").addEventListener("input", () => { scribbleUpdateHighlights("title"); scribbleRenderDensityTable(); });
  document.getElementById("scribble-desc-editor").addEventListener("input", () => { scribbleUpdateHighlights("desc"); scribbleRenderDensityTable(); });
  // Load saved scribbles on tab open
  document.querySelectorAll(".tab-btn").forEach(btn => {
    if (btn.dataset.tab === "tab-scribbles") {
      btn.addEventListener("click", () => {
        scribbleLoadSavedList();
        scribbleRenderDensityTable();
      });
    }
    if (btn.dataset.tab === "tab-kwhunter") {
      btn.addEventListener("click", async () => {
        const stored = await chromeGet(["kwhSavedKWs"]);
        const saved = stored.kwhSavedKWs;
        if (saved && saved.kws && saved.kws.length && !kwhResults.length) {
          kwhResults = saved.kws;
          document.getElementById("kwh-seed").value = saved.seed || "";
          const allKws = saved.allKws || saved.kws;
          const remaining = allKws.filter(k => !saved.kws.includes(k));
          kwhSelected = new Set(saved.kws);
          kwhShowResults(saved.kws, remaining, allKws.length, saved.seed || "");
        }
      });
    }
  });

  // Admin panel
  document.getElementById("adminBackBtn").addEventListener("click", () => { if (licenseKey) showMain(licenseKey); else showAuth(); });
  document.getElementById("adminLoginBtn").addEventListener("click", handleAdminLogin);
  document.getElementById("adminGenKeyBtn").addEventListener("click", handleAdminGenKey);
  document.getElementById("adminGenDemoBtn").addEventListener("click", handleAdminGenDemoKey);
  document.getElementById("adminRefreshBtn").addEventListener("click", loadAdminKeys);

  // Shipping tab
  // FOMO Timer + Coupon
  startFomoTimer();
  // Auto-show coupon applied after 2 seconds (create urgency)
  setTimeout(() => {
    const appliedEl = document.getElementById('couponApplied');
    if (appliedEl) appliedEl.style.display = 'block';
  }, 2000);
  document.getElementById("btnCheckRank").addEventListener("click", startRankCheck);
  document.getElementById("btnStopRank").addEventListener("click", stopRankCheck);
  // Hint when catalog ID typed
  document.getElementById("rankCatalogId").addEventListener("input", function() {
    const hint = document.getElementById("rankIdHint");
    const v = this.value.trim();
    if (!v) { hint.textContent = ""; return; }
    if (/^\d{6,12}$/.test(v)) hint.textContent = "✅ Numeric Catalog ID — sahi format";
    else if (/^[a-z0-9]{4,20}$/i.test(v)) hint.textContent = "✅ Slug ID — URL se liya hua";
    else hint.textContent = "⚠ URL se /p/ ke baad wala part daalo";
  });

  // Settings - OpenAI key
  const saveOAIBtn = document.getElementById("saveOpenaiKeyBtn");
  if (saveOAIBtn) saveOAIBtn.addEventListener("click", async () => {
    const key = document.getElementById("openaiKeyInput").value.trim();
    const st  = document.getElementById("openai-status");
    if (!key) { showStatus(st, "⚠ Key daalein", "error"); return; }
    await new Promise(r => chrome.runtime.sendMessage({ type: "SAVE_OPENAI_KEY", key }, r));
    showStatus(st, "✅ API Key saved!", "success");
    document.getElementById("openaiKeyInput").value = "";
  });
  document.getElementById("adminCopyKeyBtn").addEventListener("click", () => {
    const val = document.getElementById("admin-new-key-val").textContent;
    navigator.clipboard.writeText(val).then(() => { document.getElementById("adminCopyKeyBtn").textContent = "✅ Copied!"; setTimeout(() => document.getElementById("adminCopyKeyBtn").textContent = "📋 Copy Key", 2000); });
  });
  document.getElementById("adminExportBtn").addEventListener("click", handleAdminExport);
  document.getElementById("adminImportFile").addEventListener("change", handleAdminImport);

  // Track file selection to keep original for metadata
  document.getElementById("aiImage").addEventListener("change", (e) => {
    imgOriginalFile = e.target.files[0] || null;
    // Reset SEO outputs when new image selected
    imgVariationCount = 0;
    imgGeneratedTitle = "";
    imgGeneratedDesc = "";
    imgSelectedKeywords = [];
    document.getElementById("img-seo-title-panel").style.display = "none";
    document.getElementById("img-seo-desc-panel").style.display = "none";
    document.getElementById("img-metadata-panel").style.display = "none";
    document.getElementById("imgAutofillBtn").style.display = "none";
    document.getElementById("imgRegenerateBtn").style.display = "none";
    document.getElementById("img-keywords-box").style.display = "none";
    document.getElementById("img-keyword-status").className = "status";
  });
}

// ── Login ─────────────────────────────────────────────────────────────────────
async function handleLogin() {
  const gmail = document.getElementById("authGmail").value.trim().toLowerCase();
  const key = document.getElementById("authLicenseKey").value.trim().toUpperCase();
  const btn = document.getElementById("authLoginBtn");

  if (!gmail || !gmail.includes("@")) { showAuthStatus("Valid Gmail ID daalein", "error"); return; }
  if (!key) { showAuthStatus("License key daalein", "error"); return; }

  btn.disabled = true;
  btn.innerHTML = '<span class="spinner-auth"></span> Backend par validate kar rahe hain...';
  showAuthStatus("", "");

  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "VALIDATE_LICENSE", gmail, key }, r => resolve(r || { success: false }));
  });

  if (res.success && res.valid) {
    licenseKey = key;
    const expStr = res.expiry ? new Date(res.expiry).toLocaleDateString() : "—";
    showAuthStatus(`✅ Activated! Plan: ${res.plan || "—"}, Expires: ${expStr}`, "success");
    setTimeout(() => showMain(key), 800);
  } else {
    const reason = res.reason || res.error || "Invalid or expired license key";
    showAuthStatus("❌ " + reason, "error");
  }
  btn.disabled = false;
  btn.textContent = "✅ Activate Extension";
}
function showAuthStatus(msg, type) {
  const el = document.getElementById("auth-status");
  el.textContent = msg;
  el.className = `status ${type}`;
}

// ── Tab Switch ────────────────────────────────────────────────────────────────
function switchTab(tabId) {
  document.querySelectorAll(".tab-btn").forEach(b => b.classList.toggle("active", b.dataset.tab === tabId));
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.toggle("active", p.id === tabId));
}

// ── OpenAI API call (via background) ─────────────────────────────────────────
async function callOpenAI(payload) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage({ type: "OPENAI_CALL", payload }, res => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else if (!res || !res.success) reject(new Error(res?.error || "OpenAI call failed"));
      else resolve(res.content);
    });
  });
}

function parseJSON(raw) {
  let cleaned = raw.trim();
  if (cleaned.startsWith("```")) {
    cleaned = cleaned.replace(/^```(?:json)?/,"").replace(/```$/,"").trim();
  }
  return JSON.parse(cleaned);
}

// ── Clean text: remove special characters ────────────────────────────────────
function cleanText(str) {
  if (!str) return "";
  // Remove commas, hyphens, slashes, brackets, quotes, asterisks, colons, semicolons, pipes
  return str.replace(/[,\-\/\\()\[\]{}'"""''*@#$%^&+=|<>;:!?~`]/g, " ")
            .replace(/\s+/g, " ")
            .trim();
}

// ── Scan form helpers ─────────────────────────────────────────────────────────
async function scanFormImg() {
  const badge = document.getElementById("img-scan-badge");
  badge.className = "scan-badge none"; badge.textContent = "⏳ Scanning...";
  try {
    const res = await sendToBackground({ type: "DEEP_SCAN" });
    if (res && res.success && res.fields && res.fields.length > 0) {
      imgScannedFields = res.fields;
      badge.className = "scan-badge found";
      badge.textContent = `✅ ${res.fields.length} fields found`;
    } else {
      badge.textContent = `⚠ ${res?.error || "Meesho listing page kholen"}`;
    }
  } catch { badge.textContent = "⚠ Scan failed"; }
}

// ═══════════════════════════════════════════════════════════════════════
// ── KEYWORD HUNTER (v26 engine ported) ────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════

let kwhRunning = false;
let kwhPollTimer = null;
let kwhResults = []; // stored keywords

// Listen for messages from content script
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type === 'KW_PROGRESS') {
    const st = document.getElementById("kwh-status");
    if (st) { st.style.display="block"; st.textContent = msg.text; }
  }
  if (msg.type === 'KW_DONE') {
    kwhProcessResults(msg.keywords || [], document.getElementById("kwh-seed")?.value?.trim() || "");
    document.getElementById("kwh-start-btn").style.display = "";
    document.getElementById("kwh-stop-btn").style.display = "none";
    document.getElementById("kwh-progress-wrap").style.display = "none";
    kwhRunning = false;
  }
});

async function kwhStart() {
  const seed = document.getElementById("kwh-seed").value.trim();
  if (!seed) { alert("Seed keyword daalo pehle"); return; }

  // Sirf meesho.com (buyer side) — supplier panel exclude karo
  const allMeeshoTabs = await new Promise(r => chrome.tabs.query({ url: "*://*.meesho.com/*" }, r));
  const mTabs = allMeeshoTabs.filter(t => !t.url.includes("supplier.meesho.com"));
  if (!mTabs?.length) { alert("meesho.com ka buyer tab kholo (supplier panel nahi)!\n\nmeesho.com/saree jaisa koi page kholo phir try karo."); return; }
  const tab = mTabs[0];

  kwhRunning = true;
  kwhResults = [];
  document.getElementById("kwh-start-btn").style.display = "none";
  document.getElementById("kwh-stop-btn").style.display = "";
  document.getElementById("kwh-result-box").style.display = "none";
  document.getElementById("kwh-status").style.display = "block";
  document.getElementById("kwh-status").textContent = "Meesho tab mein inject ho raha hai...";
  document.getElementById("kwh-progress-wrap").style.display = "block";
  document.getElementById("kwh-progress-bar").style.width = "0%";

  // Try content script first
  let csWorked = false;
  try {
    await new Promise((res, rej) => {
      chrome.tabs.sendMessage(tab.id, { type: "FETCH_KEYWORDS", seed }, resp => {
        if (chrome.runtime.lastError) rej(new Error(chrome.runtime.lastError.message));
        else res(resp);
      });
    }).then(resp => {
      if (resp?.ok) {
        kwhProcessResults(resp.keywords || [], seed);
        document.getElementById("kwh-start-btn").style.display = "";
        document.getElementById("kwh-stop-btn").style.display = "none";
        document.getElementById("kwh-progress-wrap").style.display = "none";
        kwhRunning = false;
        csWorked = true;
      }
    });
  } catch(e) { /* fallback to inject */ }

  if (csWorked) return;

  // Fallback: executeScript inject
  document.getElementById("kwh-status").textContent = "Typing chal rahi hai (a-z)... Meesho tab touch mat karo!";
  try {
    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: () => { window._kw = { done: false, results: [], progress: 0, text: "", stop: false }; }
    });

    await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      func: (seedWord) => {
        const kw = window._kw;
        const sleep = ms => new Promise(r => setTimeout(r, ms));
        const nl = String.fromCharCode(10);

        function findInp() {
          const all = [...document.querySelectorAll("input")];
          for (const i of all) {
            const ph = (i.placeholder || "").toLowerCase();
            if (ph.includes("search") || ph.includes("saree") || ph.includes("kurti") || ph.includes("product")) return i;
          }
          const st = document.querySelector("input[type=\"search\"]");
          if (st) return st;
          for (const i of all) {
            const r = i.getBoundingClientRect();
            if (r.top >= 0 && r.top <= 110 && r.width > 100) return i;
          }
          for (const i of all) {
            if ((i.className || "").toLowerCase().includes("search")) return i;
          }
          return null;
        }

        function setV(inp, val) {
          inp.focus();
          try {
            const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
            s.call(inp, val);
            inp.dispatchEvent(new InputEvent("input", { bubbles: true, data: val, inputType: "insertText" }));
            inp.dispatchEvent(new Event("change", { bubbles: true }));
            inp.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: val.slice(-1) }));
            inp.dispatchEvent(new KeyboardEvent("keyup", { bubbles: true, key: val.slice(-1) }));
          } catch(e) {}
          try { inp.select(); document.execCommand("selectAll", false); document.execCommand("insertText", false, val); } catch(e) {}
        }

        function clearV(inp) {
          try {
            const s = Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype, "value").set;
            s.call(inp, "");
            inp.dispatchEvent(new InputEvent("input", { bubbles: true, inputType: "deleteContentBackward" }));
          } catch(e) {}
          try { inp.select(); document.execCommand("selectAll", false); document.execCommand("delete", false); } catch(e) {}
          inp.dispatchEvent(new KeyboardEvent("keydown", { bubbles: true, key: "Escape" }));
          inp.blur();
        }

        let obs = null, observed = new Set();

        function startObs() {
          observed = new Set();
          if (obs) { obs.disconnect(); obs = null; }
          obs = new MutationObserver(muts => {
            for (const m of muts) {
              for (const node of m.addedNodes) {
                if (node.nodeType !== 1) continue;
                for (const el of [node, ...node.querySelectorAll("*")]) {
                  const r = el.getBoundingClientRect();
                  if (r.top < 0 || r.top > 500 || r.width < 20) continue;
                  const raw = (el.innerText || el.textContent || "").trim();
                  const line = raw.split(nl)[0].trim();
                  if (line.length > seedWord.length && line.length < 80 &&
                      /[a-zA-Z]/.test(line) && !line.includes("{") && !line.includes("Rs") && !line.includes("₹"))
                    observed.add(line.toLowerCase());
                }
              }
            }
          });
          obs.observe(document.body, { childList: true, subtree: true });
        }

        function getKWs() {
          const f = new Set([...observed]);
          document.querySelectorAll("[role=\"option\"],[role=\"listbox\"] li,li,[class*=\"suggest\" i],[class*=\"Suggest\"]").forEach(el => {
            const r = el.getBoundingClientRect();
            if (r.top > 40 && r.top < 500 && r.width > 30) {
              const t = (el.innerText || "").trim().split(nl)[0].trim();
              if (t.length > seedWord.length && t.length < 80 && /[a-zA-Z]/.test(t) && !t.includes("₹")) f.add(t.toLowerCase());
            }
          });
          return [...f].filter(k => k.length > 2);
        }

        (async () => {
          const inp = findInp();
          if (!inp) { kw.done = true; kw.text = "Search box nahi mila is page pe"; return; }
          const all = new Set();
          const letters = "abcdefghijklmnopqrstuvwxyz".split("");
          inp.scrollIntoView({ behavior: "smooth", block: "center" });
          await sleep(500);
          inp.click(); inp.focus();
          await sleep(500);
          startObs();
          for (let i = 0; i < letters.length; i++) {
            if (kw.stop) break;
            const q = seedWord + " " + letters[i];
            kw.progress = Math.round(((i + 1) / 26) * 100);
            kw.text = "\"" + q + "\" | Found: " + all.size + " | " + kw.progress + "%";
            clearV(inp); await sleep(200);
            inp.focus(); setV(inp, q); await sleep(1500);
            getKWs().forEach(s => { if (!all.has(s) && s.length > seedWord.length && s.length < 65) all.add(s); });
            observed = new Set(); await sleep(200);
          }
          if (obs) { obs.disconnect(); obs = null; }
          clearV(inp);
          kw.results = [...all];
          kw.done = true;
          kw.text = "Complete! " + kw.results.length + " keywords mila";
        })();
      },
      args: [seed]
    });

    // Poll for results
    const poll = async () => {
      if (!kwhRunning) return;
      try {
        const res = await chrome.scripting.executeScript({
          target: { tabId: tab.id },
          func: () => window._kw || { done: false, progress: 0, text: "", results: [] }
        });
        const state = res?.[0]?.result || {};
        const st = document.getElementById("kwh-status");
        if (st) st.textContent = state.text || "Working...";
        const bar = document.getElementById("kwh-progress-bar");
        if (bar) bar.style.width = (state.progress || 0) + "%";

        if (state.done) {
          kwhProcessResults(state.results || [], seed);
          document.getElementById("kwh-start-btn").style.display = "";
          document.getElementById("kwh-stop-btn").style.display = "none";
          document.getElementById("kwh-progress-wrap").style.display = "none";
          kwhRunning = false;
        } else {
          kwhPollTimer = setTimeout(poll, 1500);
        }
      } catch(e) { kwhPollTimer = setTimeout(poll, 2000); }
    };
    kwhPollTimer = setTimeout(poll, 2500);

  } catch(e) {
    const st = document.getElementById("kwh-status");
    if (st) st.textContent = "Error: " + e.message;
    document.getElementById("kwh-start-btn").style.display = "";
    document.getElementById("kwh-stop-btn").style.display = "none";
    kwhRunning = false;
  }
}

function kwhStop() {
  kwhRunning = false;
  if (kwhPollTimer) { clearTimeout(kwhPollTimer); kwhPollTimer = null; }
  chrome.tabs.query({ url: "*://*.meesho.com/*" }, tabs => {
    const buyerTab = tabs.find(t => !t.url.includes("supplier.meesho.com"));
    if (buyerTab) chrome.scripting.executeScript({
      target: { tabId: buyerTab.id },
      func: () => { if (window._kw) window._kw.stop = true; }
    }).catch(() => {});
  });
  document.getElementById("kwh-start-btn").style.display = "";
  document.getElementById("kwh-stop-btn").style.display = "none";
  const st = document.getElementById("kwh-status");
  if (st) { st.textContent = "⏹ Stopped."; }
}

function kwhProcessResults(rawKWs, seed) {
  const root = (seed || "").toLowerCase().split(" ")[0];

  // Deduplicate — remove keywords that are substrings of each other (keep longer)
  const deduped = rawKWs
    .filter(k => k.length > 3 && k.length < 65)
    .sort((a, b) => b.length - a.length) // longest first
    .filter((k, i, arr) => {
      // Remove if a longer keyword already contains this one
      return !arr.slice(0, i).some(prev => prev.includes(k));
    });

  // Score for top-30 selection
  function score(k) {
    let sc = 0;
    if (k.includes(root)) sc += 5;
    if (k.split(" ").length >= 2) sc += 3; // multi-word better
    if (k.split(" ").length >= 3) sc += 2;
    if (k.length < 30) sc += 2;
    if (k.length < 20) sc -= 1; // too short = less specific
    ["women","men","girl","boy","cotton","silk","party","casual","printed",
     "designer","latest","festive","wedding","daily","online","buy","price",
     "new","stylish","kurta","kurti","saree","dress","top","set"].forEach(q => {
      if (k.includes(q)) sc += 2;
    });
    if (/under|below|combo/.test(k)) sc += 3;
    return sc;
  }

  const ranked = [...deduped]
    .map(k => ({ k, sc: score(k) }))
    .sort((a, b) => b.sc - a.sc)
    .map(x => x.k);

  // Top 30 = pre-selected, rest = available
  const top30 = ranked.slice(0, 30);
  const remaining = ranked.slice(30);

  // Store all for later use
  window._kwhAllRaw = deduped;
  window._kwhTop30 = [...top30];
  kwhResults = [...top30]; // default selected = top 30

  kwhShowResults(top30, remaining, deduped.length, seed);
  chrome.storage.local.set({ kwhSavedKWs: { kws: top30, allKws: deduped, seed, ts: Date.now() } });
}

// Track selected keywords globally
let kwhSelected = new Set();

function kwhShowResults(top30, remaining, totalCount, seed) {
  const st = document.getElementById("kwh-status");
  if (st) st.style.display = "none";
  document.getElementById("kwh-progress-wrap").style.display = "none";
  document.getElementById("kwh-result-box").style.display = "block";

  kwhSelected = new Set(top30);

  const countEl = document.getElementById("kwh-count");
  function updateCount() {
    countEl.textContent = `${totalCount} keywords found → ${kwhSelected.size} selected (click to deselect/select)`;
    kwhResults = [...kwhSelected];
  }
  updateCount();

  function makeInteractiveChips(list, containerId, preSelected) {
    const c = document.getElementById(containerId);
    if (!c) return;
    c.innerHTML = list.map(k => {
      const sel = preSelected;
      return `<span class="kw-chip-sel" data-kw="${k.replace(/"/g,"'")}"
        style="display:inline-flex;align-items:center;gap:3px;padding:3px 8px;border-radius:20px;font-size:10px;font-weight:700;cursor:pointer;border:2px solid #000;margin:2px;
        background:${sel?"#000":"#e5e7eb"};color:${sel?"#fde047":"#6b7280"};">${k}
        <span style="font-size:9px;opacity:0.7;">${sel?"✓":"+"}</span>
      </span>`;
    }).join("");

    c.querySelectorAll(".kw-chip-sel").forEach(chip => {
      chip.addEventListener("click", () => {
        const kw = chip.dataset.kw;
        if (kwhSelected.has(kw)) {
          kwhSelected.delete(kw);
          chip.style.background = "#e5e7eb";
          chip.style.color = "#6b7280";
          chip.querySelector("span").textContent = "+";
        } else {
          kwhSelected.add(kw);
          chip.style.background = "#000";
          chip.style.color = "#fde047";
          chip.querySelector("span").textContent = "✓";
        }
        updateCount();
      });
    });
  }

  makeInteractiveChips(top30, "kwh-top-list", true);
  makeInteractiveChips(remaining, "kwh-all-list", false);
}

function kwhCopyAll() {
  const toCopy = kwhSelected.size > 0 ? [...kwhSelected] : kwhResults;
  if (!toCopy.length) { alert("Pehle research karo"); return; }
  navigator.clipboard.writeText(toCopy.join("\n"))
    .then(() => alert("✅ " + toCopy.length + " selected keywords copy ho gaye!"));
}

function kwhClear() {
  kwhResults = [];
  document.getElementById("kwh-result-box").style.display = "none";
  document.getElementById("kwh-seed").value = "";
  document.getElementById("kwh-status").style.display = "none";
  document.getElementById("kwh-progress-bar").style.width = "0%";
}

async function kwhSendToScribbles() {
  // Use selected keywords (clicked ones), fallback to top kwhResults
  const selectedKWs = kwhSelected.size > 0 ? [...kwhSelected] : kwhResults;
  if (!selectedKWs.length) { alert("Pehle keyword research karo aur keywords select karo"); return; }
  const seed = document.getElementById("kwh-seed").value.trim();

  // Load selected keywords into scribbles
  scribbleKeywords = [...selectedKWs];
  document.getElementById("scribble-keywords").value = selectedKWs.join("\n");

  // Switch to scribbles tab
  document.querySelectorAll(".tab-btn").forEach(b => b.classList.remove("active"));
  document.querySelectorAll(".tab-panel").forEach(p => p.classList.remove("active"));
  const scribTab = document.querySelector("[data-tab='tab-scribbles']");
  if (scribTab) scribTab.classList.add("active");
  const scribPanel = document.getElementById("tab-scribbles");
  if (scribPanel) scribPanel.classList.add("active");

  renderScribbleChips();

  const titleEl = document.getElementById("scribble-title-editor");
  const descEl  = document.getElementById("scribble-desc-editor");
  titleEl.innerHTML = '<span style="color:#888;font-style:italic;">🤖 AI title likh raha hai...</span>';
  descEl.innerHTML  = '<span style="color:#888;font-style:italic;">🤖 AI description likh raha hai...</span>';

  try {
    const out = await lstBuildListing(seed, selectedKWs);
    titleEl.innerText = out.title;
    descEl.innerText  = out.desc;
    const st = document.getElementById("scribble-save-status");
    if (st) showStatus(st, out.note, out.ok ? "success" : "info");
    // auto-save so it can be picked in the Image tab
    const nameEl = document.getElementById("scribble-save-name");
    if (nameEl) nameEl.value = lstTitleCase(seed || out.head || "listing").slice(0, 40);
    scribbleUpdateHighlights("title");
    scribbleUpdateHighlights("desc");
    scribbleRenderDensityTable();
    await scribbleSave();
    await lstSelectScribbleInImageTab(nameEl ? nameEl.value : "");
  } catch (e) {
    titleEl.innerText = "";
    descEl.innerText = "";
    alert("AI title nahi bana: " + (e.message || e) + "\nLicense active hai? Net check karke dobara try karein.");
  }
  scribbleUpdateHighlights("title");
  scribbleUpdateHighlights("desc");
  scribbleRenderDensityTable();
}

// ═══════════════════════════════════════════════════════════════════════
// LISTING ENGINE (KW Hunter → Scribbles) — works for any product category
//  • Title: main product word (e.g. "saree", "shoes", "shampoo") exactly ONCE
//  • Description: main word 2–3 times, top keyword phrases kept unbroken
// ═══════════════════════════════════════════════════════════════════════
const LST_BRANDS = ["zvizoro","amazon","meesho","flipkart","myntra","nykaa","ajio","boat","mamaearth","wow","himalaya","patanjali","dabur","biotique","lotus","lakme","garnier","loreal","dove","nivea","ponds","vaseline","gillette","colgate","dettol","lifebuoy","surf","ariel","tide","hul","nike","adidas","puma","reebok","sony","canon","nikon","samsung","apple","mi","redmi","realme","oppo","vivo","boult","noise","fastrack","titan","bata","sparx","campus","woodland"];
const LST_STOP = new Set(["for","with","and","the","a","an","of","in","on","to","by","new","latest","best","top","women","woman","womens","ladies","lady","men","mens","man","girls","girl","boys","boy","kids","kid","baby","unisex","combo","pack","set","online","buy","price","low","cheap","sale","under","offer","stylish","trendy","fancy","designer","premium","quality","party","wear","partywear","daily","casual","office","wedding","festive","traditional","black","white","red","blue","green","pink","yellow","maroon","grey","gray","golden","silver","beige","brown","purple","orange","navy","cotton","silk","net","organza","georgette","chiffon","rayon","linen","leather","small","big","large","medium","size","free","plus","combo","original","pure","natural","herbal","organic","soft","light","heavy","full","half","long","short","mini"]);
const lstNorm = s => String(s || "").toLowerCase().replace(/[^a-z0-9\s]/g, " ").replace(/\s+/g, " ").trim();
const lstEsc = s => s.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
const lstTitleCase = s => String(s || "").toLowerCase().replace(/\b[a-z]/g, c => c.toUpperCase());
function lstStripBrands(t) { let o = " " + t + " "; LST_BRANDS.forEach(b => { o = o.replace(new RegExp("\\b" + b + "\\b", "gi"), " "); }); return o.replace(/\s+/g, " ").trim(); }
function lstHeadRe(head) { const w = head.split(" ").map(lstEsc); w[w.length - 1] += "(?:s|es)?"; return new RegExp("\\b" + w.join("\\s+") + "\\b", "gi"); }
function lstCount(text, head) { return head ? ((String(text).match(lstHeadRe(head)) || []).length) : 0; }

// main product word/phrase: seed word found in most keywords, grown left while the words always travel together
// ("shirt" → "polo t shirt", "oil" → "hair oil", "shoes" stays "shoes")
function lstHeadTerm(seed, kws) {
  const K = kws.map(lstNorm), has = (k, t) => (" " + k + " ").includes(" " + t + " ");
  let st = lstNorm(seed).split(" ").filter(Boolean);
  if (!st.length) { const freq = {}; K.forEach(k => k.split(" ").forEach(t => { if (!LST_STOP.has(t) && t.length > 2) freq[t] = (freq[t] || 0) + 1; })); st = Object.keys(freq).sort((a, b) => freq[b] - freq[a]).slice(0, 3); }
  let best = "", bs = -1;
  st.forEach((t, i) => { if (LST_STOP.has(t) || t.length < 3 || /^\d+$/.test(t)) return; const sc = K.filter(k => has(k, t) || has(k, t + "s") || has(k, t.replace(/s$/, ""))).length * 10 + i; if (sc > bs) { bs = sc; best = t; } });
  if (!best) best = st[st.length - 1] || "";
  let i = st.lastIndexOf(best), head = best;
  while (i > 0) {
    const prev = st[i - 1], cand = prev + " " + head;
    if (LST_STOP.has(prev) || /^\d+$/.test(prev)) break;
    if (K.filter(k => has(k, cand)).length < Math.max(2, Math.ceil(K.length * 0.6))) break;
    head = cand; i--;
  }
  return head;
}

// who is it for — men / women / kids (boys, girls, baby) / unisex
const LST_AUD = { men: /\b(men|mens|man|gents|male|him)\b/, women: /\b(women|womens|woman|ladies|lady|female|her)\b/, kids: /\b(kids|kid|boys|boy|girls|girl|baby|babies|child|children|infant|toddler|junior)\b/ };
function lstAudOf(text) { const t = " " + lstNorm(text) + " "; return Object.keys(LST_AUD).filter(a => LST_AUD[a].test(t)); }
function lstPickAudience(kws, analysis) {
  if (analysis) {
    const t = lstNorm(analysis);
    if (/\bunisex\b/.test(t)) return "unisex";
    const sc = { men: (t.match(/\b(men|mens|man|male|gents)\b/g) || []).length, women: (t.match(/\b(women|womens|woman|ladies|female|girl s)\b/g) || []).length, kids: (t.match(/\b(kids|kid|boys|boy|girls|girl|baby|child|children)\b/g) || []).length };
    const top = Object.keys(sc).sort((a, b) => sc[b] - sc[a])[0];
    if (sc[top] > 0) return top;
  }
  const c = { men: 0, women: 0, kids: 0 };
  kws.forEach(k => lstAudOf(k).forEach(a => c[a]++));
  const tot = c.men + c.women + c.kids;
  if (!tot) return "";
  const top = Object.keys(c).sort((a, b) => c[b] - c[a])[0];
  return c[top] / tot >= 0.5 ? top : "unisex";
}
const LST_AUD_LABEL = { men: "Men", women: "Women", kids: "Kids", unisex: "Men And Women" };

async function lstAi(system, user) {
  const raw = await callOpenAI({ model: "gpt-4o-mini", max_tokens: 1500, temperature: 0.55, messages: [{ role: "system", content: system }, { role: "user", content: user }] });
  const j = parseJSON(String(raw).replace(/```json|```/g, "").trim());
  if (!j || !j.title) throw new Error("AI ne sahi format nahi diya");
  return j;
}

function lstCleanTitle(t, head) {
  t = lstStripBrands(String(t || "").replace(/[,\-\/\\()\[\]{}'"*@#$%^&+=|<>;:!?~`™®.]/g, " ").replace(/\s+/g, " ").trim());
  let n = 0; t = t.replace(lstHeadRe(head), m => (++n === 1 ? m : "")).replace(/\s+/g, " ").trim();
  if (head && n === 0) t = head + " " + t;
  t = t.split(" ").filter((w, i, a) => i === 0 || w.toLowerCase() !== a[i - 1].toLowerCase()).join(" ");
  t = t.replace(/\b(for|with|and|of|in)\s+(for|with|and|of|in)\b/gi, "$2").replace(/\s+(for|with|and|of|in|the|a)$/i, "");
  t = lstTitleCase(t).replace(/\b(\d+)(Ml|Gm|G|Kg|L|Cm|Mm|Mp)\b/g, (m, a, b) => a + b.toLowerCase());
  if (t.length > 190) t = t.slice(0, 190).replace(/\s+\S*$/, "");
  return t;
}
function lstCleanDesc(d) {
  return lstStripBrands(String(d || "").replace(/[%@&*|#\/\\™®<>{}\[\]"]/g, " ").replace(/[ \t]+/g, " ")).replace(/\s+([.,])/g, "$1").trim().slice(0, 1500);
}
function lstCheck(r, head, must, aud) {
  const issues = [];
  const th = lstCount(r.title, head), dh = lstCount(r.desc, head);
  if (th !== 1) issues.push(`title mein "${head}" ${th} baar hai (1 chahiye)`);
  const other = aud && aud !== "unisex" ? Object.keys(LST_AUD).filter(a => a !== aud) : [];
  const badT = other.filter(a => LST_AUD[a].test(" " + lstNorm(r.title) + " "));
  const badD = other.filter(a => LST_AUD[a].test(" " + lstNorm(r.desc) + " "));
  if (badT.length) issues.push(`title mein galat grahak (${badT.join(", ")}) — sirf ${aud} ke liye likho`);
  if (badD.length) issues.push(`description mein galat grahak (${badD.join(", ")}) — sirf ${aud} ke liye likho`);
  const dl = " " + lstNorm(r.desc) + " ";
  const miss = must.filter(p => !dl.includes(" " + lstNorm(p) + " "));
  if (miss.length > 1) issues.push(`ye keyword phrases description mein poore (unbroken) nahi aaye: ${miss.join(" | ")}`);
  if (r.desc.length < 600) issues.push("description chhota hai (700–1000 characters chahiye)");
  if (r.title.length < 90) issues.push("title chhota hai (120–190 characters chahiye)");
  return { issues, th, dh, miss };
}

// ctx.analysis = image analysis text (Image tab) → listing matches what is actually in the photo
async function lstBuildListing(seed, kwsRaw, ctx = {}) {
  const all = [...new Set(kwsRaw.map(k => lstStripBrands(lstNorm(k))).filter(k => k.length > 2))];
  const head = lstHeadTerm(seed, all);
  const aud = lstPickAudience(all, ctx.analysis || "");
  // keep only keywords for this buyer (a men's polo should not say women / kids / boys)
  const fits = k => { if (!aud || aud === "unisex") return true; const a = lstAudOf(k); return !a.length || a.includes(aud); };
  const kws = all.filter(fits), skipped = all.filter(k => !fits(k));
  const hre = lstHeadRe(head);
  const natural = k => { const n = lstNorm(k), h = hre.source; return new RegExp(h + "$", "i").test(n) || new RegExp(h + "\\s+(for|with|in|under|of)\\b", "i").test(n); };
  // description: as many full keyword phrases as read naturally in a sentence (max 10)
  const must = kws.filter(k => k.split(" ").length <= 7 && (natural(k) || !lstCount(k, head))).slice(0, 10);
  const audWords = /\b(for\s+)?(men|mens|man|gents|male|women|womens|woman|ladies|lady|female|kids|kid|boys|boy|girls|girl|baby|babies|child|children|unisex)\b/g;
  const mods = [...new Set(kws.map(k => k.replace(hre, " ").replace(audWords, " ").replace(/\b(for|with|and)\s*$/, "").replace(/^\s*(for|and)\b/, "").replace(/\s+/g, " ").trim()).filter(m => m && m.length > 1))];
  const who = aud ? LST_AUD_LABEL[aud] : "";

  const sys = `You write Meesho India product listings for ANY category — clothing, t shirts, sarees, footwear, bags, jewellery, electronics, cameras, mobile accessories, beauty, hair care, home, kitchen, toys. Simple natural Indian English. Return ONLY valid JSON {"title":"...","description":"..."}.
${ctx.analysis ? "THE PRODUCT IN THE PHOTO (from image analysis) — everything you write must match it (colour, sleeve, pattern, material, who it is for, quantity in pack). Never mention a feature that contradicts the photo.\n" : ""}${who ? `BUYER: this product is for ${who} only. Never mention any other buyer group (${Object.keys(LST_AUD).filter(a => a !== aud && aud !== "unisex").join(", ") || "none"}).\n` : ""}TITLE RULES:
- The main product word "${head}" must appear EXACTLY ONE time in the title, near the start.
- Then cover as many of the title words as possible in natural buyer order: [style / material / colour / key feature] ${head}${who ? " For " + who : ""} [pack or combo] [sleeve / fit / with what] [occasion or use] [size or quantity].
- 120 to 190 characters. Title Case. Never repeat a word. No brand names. No special characters.
- It must read like a real product name, not a list.
DESCRIPTION RULES:
- 6 to 8 complete, grammatically correct sentences, 700 to 1000 characters.
- Use EVERY "REQUIRED PHRASE" exactly word-for-word and unbroken (never insert words inside a phrase), each one time, spread across different sentences so they read naturally. This is for Meesho search reach — the more phrases used, the better.
- Write what matters for this kind of product (clothing: fabric, fit, sleeve, comfort, occasions, wash care; footwear: comfort, sole, grip; electronics/camera: features, use, in the box; beauty/hair: benefit, how to use; home/kitchen: material, size, use). Do not invent exact specifications or claims.
- No brand names. No special characters except full stops and commas.`;
  const usr = (extra = "") => `PRODUCT: ${seed || head}
MAIN PRODUCT WORD: ${head}${who ? "\nBUYER: " + who : ""}${ctx.analysis ? "\nIMAGE ANALYSIS: " + String(ctx.analysis).slice(0, 1200) : ""}
BUYER SEARCH KEYWORDS (already filtered for this buyer): ${kws.join(" | ")}
TITLE WORDS TO COVER AROUND THE MAIN WORD: ${mods.join(" | ")}
REQUIRED PHRASES FOR DESCRIPTION (exact, unbroken, use all): ${must.map(m => `"${m}"`).join(", ")}${extra}`;

  let best = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    let extra = "";
    if (best) extra = `\n\nYOUR PREVIOUS ANSWER HAD PROBLEMS — fix ALL of them and rewrite:\n- ${best.chk.issues.join("\n- ")}\nPrevious title: ${best.title}\nPrevious description: ${best.desc}`;
    const j = await lstAi(sys, usr(extra));
    let tt = j.title;
    if (aud && aud !== "unisex") Object.keys(LST_AUD).filter(a => a !== aud).forEach(a => { tt = String(tt).replace(new RegExp("\\b(for\\s+)?" + LST_AUD[a].source.replace(/^\\b|\\b$/g, "") + "\\b", "gi"), " "); });   // never sell a men's item to women/kids in the title
    const r = { title: lstCleanTitle(tt, head), desc: lstCleanDesc(j.description) };
    r.chk = lstCheck(r, head, must, aud);
    if (!best || r.chk.issues.length < best.chk.issues.length || (r.chk.issues.length === best.chk.issues.length && r.chk.miss.length < best.chk.miss.length)) best = r;
    if (!best.chk.issues.length) break;
  }
  const used = must.length - best.chk.miss.length;
  const ok = !best.chk.issues.length;
  const audTxt = who ? ` · sirf ${who} ke liye` : "";
  const skipTxt = skipped.length ? ` · hataye (dusre grahak): ${skipped.join(", ")}` : "";
  return { title: best.title, desc: best.desc, head, aud, ok, skipped,
    note: (ok ? "✅ " : "⚠ ") + `Title mein "${head}" ${best.chk.th} baar · description mein ${used}/${must.length} keyword phrases poore${audTxt}${skipTxt}${ok ? "" : " · check: " + best.chk.issues.join("; ")} · auto-save ho gaya` };
}

// Scribbles tab: keywords pasted by hand → AI title + description (+ auto-save)
async function scribbleAiGenerate() {
  scribbleLoadKeywords();
  if (!scribbleKeywords.length) { alert("Pehle keywords paste karein (ek line mein ek)"); return; }
  const btn = document.getElementById("scribble-ai-gen-btn");
  const titleEl = document.getElementById("scribble-title-editor"), descEl = document.getElementById("scribble-desc-editor");
  const old = btn.textContent; btn.disabled = true; btn.textContent = "⏳ AI likh raha hai...";
  try {
    const kwSeed = (document.getElementById("kwh-seed")?.value || "").trim();
    const kwSeedOk = kwSeed && scribbleKeywords.some(k => lstNorm(k).includes(lstNorm(kwSeed).split(" ").pop()));
    const seed = kwSeedOk ? kwSeed : lstHeadTerm("", scribbleKeywords);
    const out = await lstBuildListing(seed, scribbleKeywords);
    titleEl.innerText = out.title; descEl.innerText = out.desc;
    scribbleUpdateHighlights("title"); scribbleUpdateHighlights("desc"); scribbleRenderDensityTable(); renderScribbleChips();
    const nameEl = document.getElementById("scribble-save-name");
    if (nameEl) nameEl.value = lstTitleCase(seed).slice(0, 40);
    await scribbleSave();
    await lstSelectScribbleInImageTab(nameEl ? nameEl.value : "");
    const st = document.getElementById("scribble-save-status"); if (st) showStatus(st, out.note, out.ok ? "success" : "info");
  } catch (e) { alert("AI title nahi bana: " + (e.message || e)); }
  finally { btn.disabled = false; btn.textContent = old; }
}

// select a scribble in the Image tab "Title & Description source" box
async function lstSelectScribbleInImageTab(name) {
  await scribblePopulateAiSelect();
  const sel = document.getElementById("img-scribble-select");
  if (sel && name) { sel.value = name; imgTdSourceUpdate(); }
}
function imgTdSourceUpdate() {
  const src = document.querySelector('input[name="imgTdSrc"]:checked')?.value || "ai";
  const sel = document.getElementById("img-scribble-select");
  const pv = document.getElementById("img-scribble-preview");
  if (!sel) return;
  sel.style.display = src === "scribble" ? "block" : "none";
  if (pv) {
    pv.style.display = src === "scribble" && sel.value ? "block" : "none";
    if (src === "scribble" && sel.value) chromeGet(["scribbleSaved"]).then(st => { const e = (st.scribbleSaved || {})[sel.value]; pv.textContent = e ? "📌 " + (e.title || "") : ""; });
  }
  chromeSet({ imgTdSrc: src, imgTdScribble: sel.value || "" });
}

// Stubs for removed text tab (referenced elsewhere)
async function scanFormText() {}
async function handleGenerateFromText() {}
async function handleAutofill() {}
async function handleSaveProfile() {
  const name = prompt("Profile ka naam daalein:");
  if (!name) return;
  const fields = [];
  document.querySelectorAll("#fields-list .field-value").forEach(inp => {
    fields.push({ selector: inp.dataset.selector, value: inp.value });
  });
  const stored = await chromeGet(["captureProfiles"]);
  const profiles = stored.captureProfiles || {};
  profiles[name] = { fields, savedAt: new Date().toISOString() };
  await chromeSet({ captureProfiles: profiles });
  alert(`✅ Profile "${name}" save ho gayi!`);
  loadCaptureProfiles();
}

// ── generateFieldsWithAI — AI se form fields generate karo ───────────────────
async function generateFieldsWithAI(description, scanned) {
  const defaults = await loadDefaultFields();

  if (scanned && scanned.length > 0) {
    const fieldsSummary = scanned.map(f => {
      let line = `- selector: "${f.selector}" | label: "${f.label}" | type: ${f.type || "text"}`;
      if (f.options && f.options.length) line += ` | options: [${f.options.slice(0,8).join(", ")}]`;
      if (f.value) line += ` | current: "${f.value}"`;
      return line;
    }).join("\n");

    const userPrompt = `Product description: ${description}\n\nALL form fields found on Meesho page (fill as many as possible):\n${fieldsSummary}\n\nIMPORTANT: Return a value for EVERY field above that you can fill. Do not skip fields.`;

    const raw = await callOpenAI({
      model: "gpt-4o-mini",
      max_tokens: 1500,
      temperature: 0.3,
      messages: [
        { role: "system", content: FORM_SYSTEM_PROMPT },
        { role: "user", content: userPrompt }
      ]
    });

    const parsed = parseJSON(raw);
    if (!Array.isArray(parsed)) throw new Error("AI returned unexpected format");

    const defaultFields = Object.entries(defaults)
      .filter(([,v]) => v)
      .map(([key, value]) => ({ selector: `LABEL:${key}`, label: key, value: String(value) }));

    const fieldMap = {};
    defaultFields.forEach(f => fieldMap[f.selector] = f);
    parsed.forEach(f => { if (f.selector && f.value !== undefined) fieldMap[f.selector] = f; });
    return Object.values(fieldMap);

  } else {
    const raw = await callOpenAI({
      model: "gpt-4o-mini",
      max_tokens: 600,
      temperature: 0.3,
      messages: [
        { role: "system", content: TEXT_SYSTEM_PROMPT },
        { role: "user", content: `Product description: ${description}` }
      ]
    });

    const parsed = parseJSON(raw);
    let fields = Object.entries(parsed)
      .filter(([,v]) => v && String(v).trim())
      .map(([key, value]) => ({ selector: `input[id="${key}"]`, label: key, value: String(value) }));

    const defaultFields = Object.entries(defaults)
      .filter(([,v]) => v)
      .map(([key, value]) => ({ selector: `input[id="${key}"]`, label: key, value: String(value) }));
    const fieldMap = {};
    defaultFields.forEach(f => fieldMap[f.selector] = f);
    fields.forEach(f => fieldMap[f.selector] = f);
    return Object.values(fieldMap);
  }
}

// ── postProcessFields — pricing, inventory, style code ───────────────────────
// ── GST (India GST 2.0, from 22 Sep 2025: main slabs 0 / 5 / 18 / 40, imitation jewellery 3) ──
function normGst(v) {
  const n = parseFloat(String(v || "").replace(/[^0-9.]/g, ""));
  if (isNaN(n)) return "";
  if (n === 12) return "5";          // 12% slab merged into 5%
  if (n === 28) return "18";         // 28% slab merged into 18% (most goods)
  if ([0, 3, 5, 18, 40].includes(n)) return String(n);
  return "";
}
function inferGst(text, price) {
  const t = " " + String(text || "").toLowerCase().replace(/[^a-z0-9 ]/g, " ") + " ";
  const has = re => re.test(t);
  const p = parseFloat(price || 0);
  if (has(/\b(imitation|artificial|fashion|oxidi[sz]ed|kundan|american diamond|ad)\s+(jewell?ery|necklace|earrings?|bangles?|rings?|set|jhumka)|\b(jhumka|jhumki|mangalsutra|bangles?|earrings?|necklace|anklets?|payal|nose ?pin|maang ?tikka|bracelet|pendant)\b/)) return "3";
  if (has(/\b(saree|sari|kurti|kurta|lehenga|dupatta|salwar|suit|gown|dress|tops|t ?shirt|tshirt|shirt|jeans|trouser|pant|pants|palazzo|leggings?|jeggings?|skirt|blouse|nightwear|night ?suit|nighty|pyjama|innerwear|bra|panty|panties|briefs?|vest|kids wear|frock|romper|jacket|hoodie|sweatshirt|sweater|shawl|stole|scarf|socks|cap|bedsheet|bed sheet|pillow cover|cushion cover|curtains?|towel|blanket|dohar|quilt|comforter|fabric|cloth|unstitched|dress material)\b/)) return p > 2500 ? "18" : "5";
  if (has(/\b(shoes?|sneakers?|sandals?|slippers?|chappals?|flip ?flops?|heels|bellies|loafers?|boots?|mojari|juttis?|footwear|crocs|clogs)\b/)) return p > 2500 ? "18" : "5";
  if (has(/\b(shampoo|hair ?oil|soap|toothpaste|tooth ?brush|toothbrush|shaving cream|talcum|talc|comb|hair ?brush|feeding bottle|diapers?|sanitary|napkins?|agarbatti|incense|dhoop|candles?|umbrella|ghee|namkeen|pickle|biscuits?|chocolates?|ayurvedic medicine|churna|kadha|utensils?|kadai|tawa|pressure cooker|steel (bottle|plate|glass|tiffin)|lunch ?box|tiffin|toys?|puzzle|playing cards|bicycle|cycle|notebooks?|pencils?|crayons?|handicraft|idols?|murti)\b/)) return "5";
  if (has(/\b(mobile|phone|charger|cable|earphones?|earbuds?|headphones?|neckband|speaker|smart ?watch|watch|camera|tripod|ring light|power ?bank|led|bulb|trimmer|hair dryer|straightener|mixer|grinder|iron|fan|electronic|gadget|laptop|keyboard|mouse|perfume|deo|deodorant|lipstick|makeup|kajal|eyeliner|foundation|nail polish|face wash|serum|face cream|cream|lotion|sunscreen|cosmetic|sunglasses|goggles|handbag|bag|wallet|purse|backpack|belt|plastic|wall sticker|decor|artificial flowers?|furniture|organi[sz]er)\b/)) return "18";
  return "";
}

// put our title + description into the form exactly (AI form-fill sometimes rewrites them)
function forceTitleDesc(fields, scanned, title, desc) {
  const put = (re, selRe, label, value) => {
    if (!value) return;
    const sc = scanned.find(sf => re.test(sf.label || "") || selRe.test(sf.selector || ""));
    const i = fields.findIndex(f => re.test(f.label || "") || selRe.test(f.selector || ""));
    if (i >= 0) fields[i] = { ...fields[i], value };
    else if (sc) fields.push({ selector: sc.selector, label, value });
  };
  put(/^(product )?name$|product name|product title/i, /product_name/i, "Product Name", title);
  put(/description/i, /description/i, "Description", desc);
  return fields;
}

async function postProcessFields(fields, scanned, priceOverride, productText = "") {
  const stored = await chromeGet(["pricingRules"]);
  const rules = stored.pricingRules || { autoMrp: true, autoWrongReturn: true };

  const findF = (keywords) => fields.findIndex(f =>
    keywords.some(k =>
      (f.label || "").toLowerCase().includes(k) ||
      (f.selector || "").toLowerCase().includes(k.replace(/ /g, "_"))
    )
  );
  const findS = (keywords) => scanned.find(sf =>
    keywords.some(k => (sf.label || "").toLowerCase().includes(k))
  );
  const forceSet = (keywords, label, value) => {
    if (!value && value !== 0) return;
    const idx = findF(keywords);
    const sc = findS(keywords);
    const sel = sc?.selector || `LABEL:${label}`;
    if (idx >= 0) fields[idx] = { ...fields[idx], value: String(value) };
    else fields.push({ selector: sel, label, value: String(value) });
  };

  let actualPrice = parseFloat(priceOverride || 0);
  if (!actualPrice) {
    const pf = fields.find(f =>
      (f.label || "").toLowerCase().includes("meesho price") ||
      (f.label || "").toLowerCase().includes("selling price") ||
      (f.selector || "").includes("meesho_price")
    );
    actualPrice = parseFloat(pf?.value || 0);
  }
  if (priceOverride) forceSet(["meesho price", "selling price", "meesho_price"], "Meesho Price", priceOverride);
  if (actualPrice > 0 && rules.autoMrp !== false) {
    const mrp = Math.round(actualPrice * 3);
    forceSet(["mrp", "maximum retail"], "MRP", mrp);
    if (rules.autoWrongReturn !== false) {
      forceSet(["wrong", "defective return"], "Wrong/Defective Returns Price", Math.max(1, actualPrice - 1));
    }
  }
  forceSet(["inventory"], "Inventory", "999");
  forceSet(["net quantity"], "Net Quantity (N)", "1");
  forceSet(["style code", "supplier_product_id", "product id"], "Style code / Product ID", generateStyleCode());

  const brandIdx = findF(["brand"]);
  if (brandIdx >= 0) fields.splice(brandIdx, 1);

  const countryScanned = findS(["country"]);
  if (countryScanned) forceSet(["country"], "COUNTRY OF ORIGIN", "India");

  const importerNameSc = findS(["importer name"]);
  if (importerNameSc) forceSet(["importer name"], "Importer Name", "Not Required");
  const importerAddrSc = findS(["importer address"]);
  if (importerAddrSc) forceSet(["importer address"], "Importer Address", "Not Required");
  const importerPinSc = findS(["importer pincode"]);
  if (importerPinSc) forceSet(["importer pincode"], "Importer Pincode", "Not Required");

  const storedSD = await chromeGet(["sellerDetails"]);
  const sd = storedSD.sellerDetails || {};
  if (sd.manufacturer_pincode) {
    const mfrPinSc = scanned.find(sf => {
      const l = (sf.label || "").toLowerCase();
      return l.includes("manufacturer") && l.includes("pincode");
    });
    if (mfrPinSc) {
      const existIdx = fields.findIndex(f =>
        (f.label || "").toLowerCase().includes("manufacturer") &&
        (f.label || "").toLowerCase().includes("pin")
      );
      if (existIdx >= 0) fields.splice(existIdx, 1);
      fields.push({ selector: mfrPinSc.selector, label: "Manufacturer Pincode", value: String(sd.manufacturer_pincode) });
    }
    const packerPinVal = sd.packer_same !== false ? sd.manufacturer_pincode : (sd.packer_pincode || "");
    if (packerPinVal) {
      const pkrPinSc = scanned.find(sf => {
        const l = (sf.label || "").toLowerCase();
        return l.includes("packer") && l.includes("pincode");
      });
      if (pkrPinSc) {
        const existIdx = fields.findIndex(f =>
          (f.label || "").toLowerCase().includes("packer") &&
          (f.label || "").toLowerCase().includes("pin")
        );
        if (existIdx >= 0) fields.splice(existIdx, 1);
        fields.push({ selector: pkrPinSc.selector, label: "Packer Pincode", value: String(packerPinVal) });
      }
    }
  }

  const shelfSc = findS(["shelf", "best before"]);
  const shelfIdx = findF(["shelf", "best before"]);
  if (shelfSc && shelfIdx < 0) forceSet(["shelf", "best before"], "Shelf Life (Best Before)", "24 Months");

  // GST — always filled. Rule table (GST 2.0 slabs) wins; else AI value mapped to current slabs; default 18.
  {
    const gstScanned = findS(["gst"]);
    const gstIdx = findF(["gst", "supplier_gst"]);
    const aiVal = gstIdx >= 0 ? String(fields[gstIdx].value || "").replace(/[^0-9.]/g, "") : "";
    const nameF = fields.find(f => /product name|title/i.test(f.label || "") || /product_name/.test(f.selector || ""));
    const pt = typeof productText === "object" ? productText : { primary: String(productText || ""), extra: "" };
    // title / keyword first (most reliable), image analysis text only as fallback
    const gstNum = inferGst([pt.primary, nameF?.value || ""].join(" "), actualPrice) || inferGst(pt.extra, actualPrice) || normGst(aiVal) || "18";
    if (gstIdx >= 0) fields.splice(gstIdx, 1);
    fields.push({ selector: gstScanned?.selector || "LABEL:GST", label: "GST", value: gstNum });
  }

  return fields;
}

// ── applySellerDetails ────────────────────────────────────────────────────────
async function applySellerDetails(fields, scanned) {
  const stored = await chromeGet(["sellerDetails"]);
  const d = stored.sellerDetails || {};

  const impName    = d.importer_name    || "Not Required";
  const impAddress = d.importer_address || "Not Required";
  const impPincode = d.importer_pincode || "Not Required";

  const alwaysApply = [
    { labels: ["importer name"],    value: impName    },
    { labels: ["importer address"], value: impAddress },
    { labels: ["importer pincode"], value: impPincode },
  ];
  for (const sm of alwaysApply) {
    const sc = scanned.find(sf => sm.labels.some(l => (sf.label || "").toLowerCase().includes(l)));
    if (!sc) continue;
    const existIdx = fields.findIndex(f => sm.labels.some(l => (f.label || "").toLowerCase().includes(l)));
    if (existIdx >= 0) fields[existIdx].value = sm.value;
    else fields.push({ selector: sc.selector, label: sm.labels[0], value: sm.value });
  }

  if (!d.manufacturer_name) return fields;

  const packerPin     = d.packer_pincode || (d.packer_same !== false ? d.manufacturer_pincode : "");
  const packerName    = d.packer_name    || (d.packer_same !== false ? d.manufacturer_name    : "");
  const packerAddress = d.packer_address || (d.packer_same !== false ? d.manufacturer_address : "");

  const scanMatch = (conditions) => scanned.find(sf => {
    const l = (sf.label || "").toLowerCase();
    return conditions.every(c => l.includes(c));
  });
  const upsertField = (scanField, label, value) => {
    if (!value || !scanField) return;
    const existIdx = fields.findIndex(f => f.selector === scanField.selector);
    if (existIdx >= 0) fields[existIdx].value = String(value);
    else fields.push({ selector: scanField.selector, label, value: String(value) });
  };

  upsertField(scanMatch(["manufacturer","name"]),    "Manufacturer Name",    d.manufacturer_name);
  upsertField(scanMatch(["manufacturer","address"]), "Manufacturer Address", d.manufacturer_address);
  upsertField(scanMatch(["manufacturer","pin"]),     "Manufacturer Pincode", d.manufacturer_pincode);
  upsertField(scanMatch(["packer","name"]),    "Packer Name",    packerName);
  upsertField(scanMatch(["packer","address"]), "Packer Address", packerAddress);
  upsertField(scanMatch(["packer","pin"]),     "Packer Pincode", packerPin);
  return fields;
}

function generateStyleCode() {
  const ts = Date.now().toString(36).toUpperCase();
  const rand = Math.random().toString(36).slice(2,5).toUpperCase();
  return `KWT-${ts}-${rand}`;
}

// ── Quick Autofill ────────────────────────────────────────────────────────────
async function handleQuickAutofill() {
  const btn = document.getElementById("quickImgAutofillBtn");
  const statusEl = document.getElementById("image-status");
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Scanning & Filling...';
  showStatus(statusEl, "🔍 Deep scan ho raha hai (dropdowns check kar raha hai)...", "info");
  try {
    const scanRes = await sendToBackground({ type: "DEEP_SCAN" });
    const defaults = await loadDefaultFields();
    const fields = buildFieldsFromDefaults(defaults, scanRes?.fields || []);
    const autofillRes = await sendToBackground({ type: "AUTOFILL_FIELDS", fields });
    if (autofillRes?.success) showStatus(statusEl, "✅ Quick AutoFill complete!", "success");
    else showStatus(statusEl, `⚠ ${autofillRes?.error || "Autofill failed"}`, "error");
  } catch (e) {
    showStatus(statusEl, `❌ ${e.message}`, "error");
  } finally {
    btn.disabled = false; btn.textContent = "⚡ Quick Scan & AutoFill";
  }
}

function buildFieldsFromDefaults(defaults, scanned) {
  return Object.entries(defaults)
    .filter(([,v]) => v)
    .map(([key, value]) => {
      const sc = scanned.find(sf => (sf.label || "").toLowerCase().includes(key.toLowerCase()));
      return { selector: sc?.selector || `LABEL:${key}`, label: key, value: String(value) };
    });
}

// ── STEP: Get keyword suggestions for Image tab ───────────────────────────────
async function handleImgGetKeywords() {
  const primaryKw = document.getElementById("imgPrimaryKeyword").value.trim();
  const statusEl  = document.getElementById("img-keyword-status");
  const btn       = document.getElementById("imgGetKeywordsBtn");

  if (!primaryKw) { showStatus(statusEl, "⚠ Primary keyword likhein pehle", "error"); return; }

  btn.disabled = true; btn.innerHTML = '<span class="spinner-dark spinner"></span> Keywords aa rahe hain...';
  showStatus(statusEl, "⏳ AI keywords dhundh raha hai...", "info");
  document.getElementById("img-keywords-box").style.display = "none";

  try {
    const raw = await callOpenAI({
      model: "gpt-4o-mini",
      max_tokens: 400,
      temperature: 0.5,
      messages: [
        { role: "system", content: SEO_KEYWORDS_PROMPT },
        { role: "user", content: `Product keyword: ${primaryKw}` }
      ]
    });

    const keywords = parseJSON(raw);
    if (!Array.isArray(keywords) || keywords.length === 0) throw new Error("Keywords nahi mile, dobara try karein");

    const listEl = document.getElementById("img-keywords-list");
    listEl.innerHTML = "";
    keywords.forEach((kw, i) => {
      const chip = document.createElement("label");
      chip.className = "kw-chip";
      chip.dataset.kw = kw;
      chip.innerHTML = `<input type="checkbox" checked data-index="${i}"><span>${escHtml(kw)}</span>`;
      chip.addEventListener("click", function() {
        const cb = this.querySelector("input");
        setTimeout(() => {
          if (!cb.checked) this.classList.add("off");
          else this.classList.remove("off");
        }, 0);
      });
      listEl.appendChild(chip);
    });

    document.getElementById("img-keywords-box").style.display = "block";
    showStatus(statusEl, `✅ ${keywords.length} keywords ready! Jo nahi chahiye unhe uncheck karo`, "success");
  } catch(e) {
    showStatus(statusEl, `❌ ${e.message}`, "error");
  } finally {
    btn.disabled = false;
    btn.textContent = "🔍 Keyword Suggestions Laao";
  }
}

// ── Generate from Image (with integrated SEO title+desc) ─────────────────────
async function handleGenerateFromImage() {
  const fileInput = document.getElementById("aiImage");
  const priceInput = document.getElementById("imgMeeshoPrice");
  const primaryKw  = document.getElementById("imgPrimaryKeyword").value.trim();
  const btn = document.getElementById("generateFromImage");
  const statusEl = document.getElementById("image-status");
  const resultEl = document.getElementById("image-result");
  const autofillBtn = document.getElementById("imgAutofillBtn");
  const regenBtn    = document.getElementById("imgRegenerateBtn");

  if (!fileInput.files[0] && !imgOriginalFile) { showStatus(statusEl, "⚠ Pehle image select karein", "error"); return; }

  // Collect selected keywords if available
  const chips = document.querySelectorAll("#img-keywords-list .kw-chip");
  imgSelectedKeywords = [];
  chips.forEach(chip => {
    const cb = chip.querySelector("input");
    if (cb && cb.checked) imgSelectedKeywords.push(chip.dataset.kw);
  });

  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Analyzing & Generating...';
  showStatus(statusEl, "⏳ Image analyze ho rahi hai...", "info");
  resultEl.style.display = "none";
  autofillBtn.style.display = "none";
  regenBtn.style.display = "none";
  document.getElementById("img-seo-title-panel").style.display = "none";
  document.getElementById("img-seo-desc-panel").style.display = "none";
  document.getElementById("img-metadata-panel").style.display = "none";

  try {
    const currentFile = fileInput.files[0] || imgOriginalFile;
    imgOriginalFile = currentFile;

    // Increment variation counter EVERY time generate is pressed
    imgVariationCount++;
    const variationNum = imgVariationCount;

    // STEP A: Image analysis — sirf pehli baar karo ya nayi image pe
    // Agar imgLastText already hai (same image, dobara generate) toh skip karo
    let analysisContent = imgLastText;
    const isFirstRun = !analysisContent || fileInput.files[0]; // new file = fresh analysis

    if (isFirstRun) {
      const imageData = await fileToBase64(currentFile);
      const mimeType  = currentFile.type || "image/jpeg";
      showStatus(statusEl, `🤖 Step 1/2: Image analyze ho rahi hai...`, "info");
      analysisContent = await callOpenAI({
        model: "gpt-4o-mini",
        max_tokens: 800,
        messages: [
          { role: "system", content: IMAGE_SYSTEM_PROMPT },
          {
            role: "user",
            content: [
              { type: "image_url", image_url: { url: `data:${mimeType};base64,${imageData}` } },
              { type: "text", text: "Analyze this product image and generate a complete Meesho listing description." + (priceInput.value ? ` Meesho selling price: ₹${priceInput.value}.` : "") }
            ]
          }
        ]
      });
      imgLastText = analysisContent;
      resultEl.textContent = analysisContent;
      resultEl.style.display = "block";
    } else {
      // Dobara generate — image analysis skip, seedha SEO
      showStatus(statusEl, `♻️ Same image — analysis skip, variation #${variationNum} ban raha hai...`, "info");
    }

    // STEP B: Generate SEO Title + Description with unique variation
    showStatus(statusEl, `✨ Variation #${variationNum} ban raha hai — fresh title aur description...`, "info");

    const effectivePrimaryKw = primaryKw || "";
    const kwsToUse = imgSelectedKeywords.length >= 3
      ? imgSelectedKeywords
      : [effectivePrimaryKw, "online shopping India", "best price", "quality product", "buy now", "free delivery"].filter(Boolean);

    // Shuffle keywords slightly each variation to change description flow
    const shuffledKws = [...kwsToUse].sort(() => (Math.random() - 0.5) * (variationNum % 3 === 0 ? 1 : 0.3));

    const previousTitle = imgGeneratedTitle ? `\nPREVIOUS TITLE (DO NOT repeat this or start with same word): ${imgGeneratedTitle}` : "";

    const userPromptSeo = `VARIATION NUMBER: ${variationNum}
Opening word: use word number ${variationNum} from the rotation list in your system instructions.
${previousTitle}

Product details from image analysis: ${analysisContent}
${effectivePrimaryKw ? "Primary keyword (must appear near start of title): " + effectivePrimaryKw : ""}
SEO keywords to weave into title and description: ${shuffledKws.join(", ")}

REMINDER: No brand names anywhere. No commas hyphens or special characters.
Title must be 140 to 150 characters in Title Case.
Description must be exactly 5 sentences following the format in your instructions.
Every sentence must be grammatically correct and make complete logical sense.

Return ONLY valid JSON: {"title": "...", "description": "..."}`;

    let scribbleData = await scribbleGetSelectedForAI();
    // scribble + photo → rewrite the scribble so it matches the product in the photo (buyer, colour, sleeve, pack…)
    if (scribbleData && document.getElementById("img-scribble-adapt")?.checked !== false && (scribbleData.keywords || []).length && analysisContent) {
      showStatus(statusEl, "✏️ Scribble ko image ke hisaab se adjust kar raha hai (keywords wahi, galat grahak hatenge)...", "info");
      try {
        const nm = document.getElementById("img-scribble-select")?.value || "";
        const o = await lstBuildListing(primaryKw || nm, scribbleData.keywords, { analysis: analysisContent });
        scribbleData = { ...scribbleData, title: o.title, desc: o.desc, _note: o.note };
      } catch (e) { /* keep the saved scribble as it is */ }
    }
    const rawSeo = scribbleData ? JSON.stringify({ title: scribbleData.title, description: scribbleData.desc }) : await callOpenAI({
      model: "gpt-4o-mini",
      max_tokens: 1400,
      temperature: Math.min(0.95, 0.65 + (variationNum * 0.03)), // gradually more creative each variation
      messages: [
        { role: "system", content: SEO_TITLE_DESC_PROMPT },
        { role: "user", content: userPromptSeo }
      ]
    });

    const seoResult = parseJSON(rawSeo);
    if (!seoResult.title || !seoResult.description) throw new Error("AI ne sahi format nahi diya, dobara try karein");

    // Clean and store (scribble text is kept exactly as saved — commas/full stops included)
    imgGeneratedTitle = scribbleData ? String(scribbleData.title || "").trim() : cleanText(seoResult.title);
    imgGeneratedDesc  = scribbleData ? String(scribbleData.desc || "").trim() : cleanText(seoResult.description);

    // Show title
    const titleEl = document.getElementById("img-seo-title");
    titleEl.value = imgGeneratedTitle;
    document.getElementById("img-seo-title-panel").style.display = "block";
    // Show variation badge
    const varBadge = document.getElementById("img-variation-badge");
    if (varBadge) { varBadge.textContent = `VARIATION #${variationNum}`; varBadge.style.display = "inline-block"; }

    // Show description
    const descEl = document.getElementById("img-seo-desc");
    descEl.value = imgGeneratedDesc;
    document.getElementById("img-seo-desc-panel").style.display = "block";

    // Update counters
    updateImgSeoCounters();
    titleEl.addEventListener("input", () => { imgGeneratedTitle = cleanText(titleEl.value); titleEl.value = imgGeneratedTitle; updateImgSeoCounters(); });
    descEl.addEventListener("input",  () => { imgGeneratedDesc  = cleanText(descEl.value);  descEl.value  = imgGeneratedDesc;  updateImgSeoCounters(); });

    // Show metadata panel
    document.getElementById("img-metadata-panel").style.display = "block";

    autofillBtn.style.display = "block";
    regenBtn.style.display = "block";
    showStatus(statusEl, scribbleData?._note ? `✅ Scribble image ke hisaab se ready — ${scribbleData._note.replace(/ · auto-save ho gaya/, "")}. Ab Autofill karein.` : `✅ Variation #${variationNum} ready! Autofill karein ya Dobara Generate dabao naya title ke liye.`, "success");

    // Auto-save to chrome storage
    await chromeSet({
      lastImgTitle: imgGeneratedTitle,
      lastImgDesc: imgGeneratedDesc,
      lastImgKeywords: imgSelectedKeywords,
      lastImgAnalysis: analysisContent,
      lastImgVariation: variationNum,
      lastImgSavedAt: new Date().toISOString()
    });

  } catch (e) {
    showStatus(statusEl, `❌ ${e.message}`, "error");
  } finally {
    btn.disabled = false; btn.textContent = "✨ Image Analyze & Generate";
  }
}

function updateImgSeoCounters() {
  const title = document.getElementById("img-seo-title").value;
  const desc  = document.getElementById("img-seo-desc").value;
  const tLen  = title.length;
  const wCount = desc.trim() ? desc.trim().split(/\s+/).length : 0;
  const tColor = (tLen >= 140 && tLen <= 150) ? "#2e7d32" : (tLen < 140 ? "#e65100" : "#c62828");
  document.getElementById("img-title-charcount").innerHTML = `<span style="color:${tColor};font-weight:700;">${tLen} chars</span> (ideal: 140-150)`;
  document.getElementById("img-desc-wordcount").innerHTML  = `<span style="font-weight:700;">${wCount} words</span> (ideal: ~500)`;
}

// ── Write Image Metadata — 3 images + max keywords ───────────────────────────
// Wire image preview thumbnails (called on DOMContentLoaded)
function wireImageMetadataInputs() {
  [1,2,3].forEach(n => {
    const inp = document.getElementById(`imgMeta${n}`);
    if (!inp) return;
    inp.addEventListener("change", () => {
      const file = inp.files[0];
      if (!file) return;
      const thumb = document.getElementById(`imgMeta${n}Thumb`);
      const prev  = document.getElementById(`imgMeta${n}Preview`);
      const lbl   = document.getElementById(`imgMeta${n}Label`);
      const url   = URL.createObjectURL(file);
      thumb.src = url;
      prev.style.display  = "block";
      lbl.style.display   = "none";
    });
  });
}

async function handleWriteImageMetadata() {
  const statusEl = document.getElementById("img-meta-status");
  const btn      = document.getElementById("imgWriteMetaBtn");

  // Collect selected files
  const files = [1,2,3].map(n => {
    const inp = document.getElementById(`imgMeta${n}`);
    return inp?.files?.[0] || null;
  }).filter(Boolean);

  if (files.length === 0) {
    showStatus(statusEl, "⚠ Kam se kam 1 image select karein", "error"); return;
  }
  if (!imgGeneratedTitle) {
    showStatus(statusEl, "⚠ Pehle Image tab se listing generate karein", "error"); return;
  }

  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Processing...';

  try {
    // Collect ALL available keywords — KW Hunter + imgSelectedKeywords + title words
    const stored = await chromeGet(["kwhSavedKWs", "sellerDetails"]);
    const kwhData = stored.kwhSavedKWs;
    const sellerDetails = stored.sellerDetails || {};
    const mfrName = sellerDetails.manufacturer_name || "Kiwtech Enterprises";

    // Build master keyword pool
    let masterKWs = [];
    if (kwhData?.allKws?.length) masterKWs = [...kwhData.allKws];
    else if (kwhData?.kws?.length) masterKWs = [...kwhData.kws];
    if (imgSelectedKeywords?.length) {
      imgSelectedKeywords.forEach(k => { if (!masterKWs.includes(k)) masterKWs.push(k); });
    }
    // Add title words as keywords too
    const titleWords = imgGeneratedTitle.split(" ").filter(w => w.length > 3);
    titleWords.forEach(w => { if (!masterKWs.includes(w.toLowerCase())) masterKWs.push(w.toLowerCase()); });

    // Dedupe and clean
    masterKWs = [...new Set(masterKWs.map(k => k.trim().toLowerCase()))].filter(k => k.length > 2);

    // Update KW count display
    const kwCountEl = document.getElementById("imgMetaKwCount");
    if (kwCountEl) kwCountEl.textContent = `${masterKWs.length} keywords available → spread across ${files.length} images`;

    // Generate manufacturer comment once
    showStatus(statusEl, `⏳ Metadata prepare ho raha hai (${files.length} images)...`, "info");
    let mfrComment = `This product is manufactured by ${mfrName} with highest quality standards. Each item is carefully crafted and quality tested before packaging.`;
    try {
      const rawMfrDesc = await callOpenAI({
        model: "gpt-4o-mini", max_tokens: 300, temperature: 0.4,
        messages: [
          { role: "system", content: MANUFACTURER_COMMENT_PROMPT },
          { role: "user", content: `Manufacturer name: ${mfrName}` }
        ]
      });
      if (rawMfrDesc?.trim()) mfrComment = cleanText(rawMfrDesc.trim());
    } catch(e) {}

    // Process each image with rotated keyword sets
    const chunkSize = Math.ceil(masterKWs.length / files.length);
    const dlWrap = document.getElementById("img-meta-downloads");
    if (dlWrap) dlWrap.style.display = "block";

    let anySuccess = false;
    for (let i = 0; i < files.length; i++) {
      const file = files[i];
      showStatus(statusEl, `⏳ Image ${i+1}/${files.length} process ho rahi hai...`, "info");

      // Rotate keyword chunks — each image gets different slice + shared base
      const start  = i * chunkSize;
      const sliceA = masterKWs.slice(start, start + chunkSize);
      const sliceB = masterKWs.slice(0, Math.min(5, masterKWs.length)); // top 5 always
      const imgKWs = [...new Set([...sliceB, ...sliceA])].slice(0, 20); // max 20 per image

      // Title = product title (same for all)
      const metaTitle   = imgGeneratedTitle;
      // Subject = space-separated keywords (up to 15)
      const metaSubject = imgKWs.slice(0, 15).join(" ");
      // Tags = comma-separated all keywords (up to 20)
      const metaTags    = imgKWs.join(", ");
      // Comment = manufacturer description
      const metaComment = mfrComment;
      const metaRating  = 5;

      try {
        const base64Data = await fileToBase64(file);
        const metaRes = await new Promise((resolve, reject) => {
          chrome.runtime.sendMessage({
            type: "WRITE_IMAGE_METADATA",
            imageBase64: base64Data,
            mimeType: file.type || "image/jpeg",
            metadata: { title: metaTitle, subject: metaSubject, tags: metaTags, comment: metaComment, rating: metaRating }
          }, res => {
            if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
            else resolve(res);
          });
        });

        if (metaRes?.success && metaRes?.outputBase64) {
          const byteChars = atob(metaRes.outputBase64);
          const byteArr = new Uint8Array(byteChars.length);
          for (let j = 0; j < byteChars.length; j++) byteArr[j] = byteChars.charCodeAt(j);
          const blob = new Blob([byteArr], { type: "image/jpeg" });
          const url  = URL.createObjectURL(blob);
          const dlLink = document.getElementById(`img-meta-dl-${i+1}`);
          if (dlLink) { dlLink.href = url; dlLink.style.display = ""; }
          anySuccess = true;
        }
      } catch(e) {
        console.error(`Image ${i+1} metadata error:`, e);
      }
    }

    if (anySuccess) {
      showStatus(statusEl, `✅ ${files.length} image(s) metadata save ho gayi! Niche se download karo.`, "success");
      await chromeSet({ lastMetaTitle: imgGeneratedTitle, lastMetaSavedAt: new Date().toISOString() });
    } else {
      showStatus(statusEl, "❌ Metadata write failed — background script check karo", "error");
    }

  } catch(e) {
    showStatus(statusEl, `❌ ${e.message}`, "error");
  } finally {
    btn.disabled = false; btn.textContent = "💾 Teeno Images Metadata Save Karo";
  }
}

// ── Autofill from image analysis ─────────────────────────────────────────────
async function handleImgAutofill() {
  if (!imgLastText) return;
  const btn = document.getElementById("imgAutofillBtn");
  const statusEl = document.getElementById("image-status");
  btn.disabled = true; btn.innerHTML = '<span class="spinner"></span> Generating fields...';
  showStatus(statusEl, "🔍 Deep scan ho raha hai (dropdowns check kar raha hai)...", "info");

  try {
    const priceOverride = document.getElementById("imgMeeshoPrice").value.trim();
    let scanned = imgScannedFields;
    if (!scanned || scanned.length === 0) {
      const scanRes = await sendToBackground({ type: "DEEP_SCAN" });
      if (scanRes?.success && scanRes.fields?.length > 0) { scanned = scanRes.fields; imgScannedFields = scanned; }
    }

    // Use SEO title as product name if available
    const descForAI = imgGeneratedTitle
      ? `${imgLastText}\n\nProduct Title (use this as product name): ${imgGeneratedTitle}`
      : imgLastText;

    const descWithPrice = priceOverride ? descForAI + ` Meesho selling price: ₹${priceOverride}.` : descForAI;
    showStatus(statusEl, "🤖 AI fields generate kar raha hai...", "info");

    const descForAI2 = imgGeneratedDesc ? descWithPrice + `\n\nProduct Description (use exactly this in the description field): ${imgGeneratedDesc}` : descWithPrice;
    let fields = await generateFieldsWithAI(descForAI2, scanned || []);
    fields = await postProcessFields(fields, scanned || [], priceOverride, { primary: [imgGeneratedTitle, document.getElementById("imgPrimaryKeyword")?.value || ""].join(" "), extra: imgLastText });
    fields = await applySellerDetails(fields, scanned || []);
    fields = forceTitleDesc(fields, scanned || [], imgGeneratedTitle, imgGeneratedDesc);

    const autofillRes = await sendToBackground({ type: "AUTOFILL_FIELDS", fields });
    if (autofillRes?.success) showStatus(statusEl, "✅ Autofill shuru ho gaya!", "success");
    else showStatus(statusEl, `⚠ ${autofillRes?.error || "Autofill failed"}`, "error");
  } catch (e) {
    showStatus(statusEl, `❌ ${e.message}`, "error");
  } finally {
    btn.disabled = false; btn.textContent = "🚀 Autofill on Meesho Tab";
  }
}

// ── Defaults ───────────────────────────────────────────────────────────────────
async function loadDefaultFields() {
  const stored = await chromeGet(["defaultFields"]);
  return stored.defaultFields || {};
}
async function loadDefaultsUI() {
  const fields = await loadDefaultFields();
  const list = document.getElementById("defaults-list");
  list.innerHTML = "";
  for (const [key, val] of Object.entries(fields)) appendDefaultRow(list, key, val);
}
function appendDefaultRow(list, key = "", val = "") {
  const row = document.createElement("div");
  row.className = "field-row";
  row.style.alignItems = "center";
  row.innerHTML = `
    <input class="field-value" placeholder="Field name" value="${escHtml(key)}" style="width:100px;flex-shrink:0;" />
    <input class="field-value" placeholder="Default value" value="${escHtml(val)}" style="flex:1;" />
    <button style="background:#f44;color:#fff;border:2px solid #000;font-size:11px;font-weight:800;padding:3px 7px;cursor:pointer;margin-left:4px;" onclick="this.parentElement.remove()">✕</button>
  `;
  list.appendChild(row);
}
function addDefaultField() { appendDefaultRow(document.getElementById("defaults-list")); }
async function saveDefaults() {
  const statusEl = document.getElementById("defaults-status");
  const fields = {};
  document.querySelectorAll("#defaults-list .field-row").forEach(row => {
    const inputs = row.querySelectorAll("input");
    const k = inputs[0]?.value?.trim(); const v = inputs[1]?.value?.trim();
    if (k) fields[k] = v || "";
  });
  await chromeSet({ defaultFields: fields });
  showStatus(statusEl, "✅ Defaults save ho gaye!", "success");
  setTimeout(() => showStatus(statusEl, "", ""), 2000);
}
async function clearDefaults() {
  if (!confirm("Sab defaults delete karne hain?")) return;
  await chromeSet({ defaultFields: {} });
  document.getElementById("defaults-list").innerHTML = "";
  const statusEl = document.getElementById("defaults-status");
  showStatus(statusEl, "✅ Defaults clear ho gaye.", "success");
  setTimeout(() => showStatus(statusEl, "", ""), 2000);
}

// ── Seller Details ─────────────────────────────────────────────────────────────
async function loadSellerDetailsUI() {
  const stored = await chromeGet(["sellerDetails"]);
  const d = stored.sellerDetails || {};
  const set = (id, v) => { const el = document.getElementById(id); if (el) el.value = v || ""; };
  set("mfr-name",    d.manufacturer_name);
  set("mfr-address", d.manufacturer_address);
  set("mfr-pincode", d.manufacturer_pincode);

  // Packer same toggle
  const sameEl = document.getElementById("packer-same-as-mfr");
  const packerSame = d.packer_same !== false;
  if (sameEl) sameEl.checked = packerSame;
  const extra = document.getElementById("packer-fields-extra");
  const note  = document.getElementById("packer-same-note");
  if (extra) extra.style.display = packerSame ? "none" : "block";
  if (note)  note.style.display  = packerSame ? "block" : "none";
  if (!packerSame) {
    set("pkr-name",    d.packer_name);
    set("pkr-address", d.packer_address);
    set("pkr-pincode", d.packer_pincode);
  }

  // Importer not-required toggle
  const impNR = document.getElementById("importer-not-required");
  const impNotRequired = d.importer_not_required !== false;
  if (impNR) impNR.checked = impNotRequired;
  const impExtra = document.getElementById("importer-fields-extra");
  if (impExtra) impExtra.style.display = impNotRequired ? "none" : "block";
  if (!impNotRequired) {
    set("imp-name",    d.importer_name);
    set("imp-address", d.importer_address);
    set("imp-pincode", d.importer_pincode);
  }

  const warn = document.getElementById("setup-warning");
  if (warn) warn.style.display = (!d.manufacturer_name || !d.manufacturer_address || !d.manufacturer_pincode) ? "block" : "none";
}
async function saveSellerDetails() {
  const statusEl = document.getElementById("seller-status");
  const name    = document.getElementById("mfr-name").value.trim();
  const address = document.getElementById("mfr-address").value.trim();
  const pincode = document.getElementById("mfr-pincode").value.trim();
  if (!name || !address || !pincode) { showStatus(statusEl, "⚠ Manufacturer ke teeno fields fill karein", "error"); return; }

  const same = document.getElementById("packer-same-as-mfr").checked;
  let pkrName    = same ? name    : (document.getElementById("pkr-name")?.value.trim()    || "");
  let pkrAddress = same ? address : (document.getElementById("pkr-address")?.value.trim() || "");
  let pkrPincode = same ? pincode : (document.getElementById("pkr-pincode")?.value.trim() || "");
  if (!same && (!pkrName || !pkrAddress || !pkrPincode)) {
    showStatus(statusEl, "⚠ Packer ke teeno fields fill karein (ya 'Same as Manufacturer' check karein)", "error"); return;
  }

  const impNR = document.getElementById("importer-not-required").checked;
  const impName    = impNR ? "Not Required" : (document.getElementById("imp-name")?.value.trim()    || "Not Required");
  const impAddress = impNR ? "Not Required" : (document.getElementById("imp-address")?.value.trim() || "Not Required");
  const impPincode = impNR ? "Not Required" : (document.getElementById("imp-pincode")?.value.trim() || "Not Required");

  await chromeSet({ sellerDetails: {
    manufacturer_name:    name,
    manufacturer_address: address,
    manufacturer_pincode: pincode,
    packer_same:    same,
    packer_name:    pkrName,
    packer_address: pkrAddress,
    packer_pincode: pkrPincode,
    importer_not_required: impNR,
    importer_name:    impName,
    importer_address: impAddress,
    importer_pincode: impPincode
  }});

  const warn = document.getElementById("setup-warning");
  if (warn) warn.style.display = "none";
  showStatus(statusEl, "✅ Manufacturer + Packer + Importer save ho gaye! Ab autofill mein sab fields fill hongi.", "success");
  setTimeout(() => showStatus(statusEl, "", ""), 3500);
}

// ── Pricing Rules ──────────────────────────────────────────────────────────────
async function loadPricingRulesUI() {
  const stored = await chromeGet(["pricingRules"]);
  const r = stored.pricingRules || { autoMrp: true, autoWrongReturn: true };
  const mrpEl = document.getElementById("auto-mrp"); const wrnEl = document.getElementById("auto-wrong-return");
  if (mrpEl) mrpEl.checked = r.autoMrp !== false;
  if (wrnEl) wrnEl.checked = r.autoWrongReturn !== false;
}
async function savePricingRules() {
  const statusEl = document.getElementById("pricing-status");
  await chromeSet({ pricingRules: { autoMrp: document.getElementById("auto-mrp").checked, autoWrongReturn: document.getElementById("auto-wrong-return").checked } });
  showStatus(statusEl, "✅ Pricing rules save ho gayi!", "success");
  setTimeout(() => showStatus(statusEl, "", ""), 2500);
}

// ── Settings ───────────────────────────────────────────────────────────────────
async function loadOpenAIKeyUI() {
  const el = document.getElementById("ai-status-msg");
  if (!el) return;
  el.textContent = "Checking AI connection...";
  chrome.runtime.sendMessage({
    type: "OPENAI_CALL",
    payload: { model: "gpt-3.5-turbo", max_tokens: 1, messages: [{ role: "user", content: "ping" }] }
  }, res => {
    if (chrome.runtime.lastError || !res) { el.textContent = "⚠️ AI status unknown"; return; }
    if (res.success || (res.error && !res.error.includes("configure nahi"))) {
      el.innerHTML = "✅ AI Ready hai — sab kuch setup hai!"; el.style.color = "#2e7d32";
    } else {
      el.innerHTML = "❌ AI key missing — admin se contact karein"; el.style.color = "#c62828";
    }
  });
}
async function saveOpenAIKey() {}

// ── FOMO Timer + Coupon ───────────────────────────────────────────────────────
function startFomoTimer() {
  const timerEl = document.getElementById('fomoTimer');
  const seatsEl = document.getElementById('fomoSeats');
  if (!timerEl) return;

  // Load or set timer end from storage (persistent 24h countdown)
  chrome.storage.local.get(['fomoEndTime', 'fomoSeats'], r => {
    let endTime = r.fomoEndTime;
    let seats   = r.fomoSeats || 7;
    const now   = Date.now();

    if (!endTime || endTime < now) {
      // Fresh 23h 47m 12s countdown
      endTime = now + (23 * 3600 + 47 * 60 + 12) * 1000;
      seats   = Math.floor(Math.random() * 4) + 5; // 5-8 seats
      chrome.storage.local.set({ fomoEndTime: endTime, fomoSeats: seats });
    }

    if (seatsEl) seatsEl.textContent = seats;

    const tick = () => {
      const left = Math.max(0, endTime - Date.now());
      const h = Math.floor(left / 3600000);
      const m = Math.floor((left % 3600000) / 60000);
      const s = Math.floor((left % 60000) / 1000);
      if (timerEl) timerEl.textContent = `${String(h).padStart(2,'0')}:${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
      if (left > 0) setTimeout(tick, 1000);
    };
    tick();
  });
}

function copyCoupon() {
  navigator.clipboard.writeText('KIWTECH300').catch(() => {});
  const btn = document.getElementById('copyBtn');
  if (btn) { btn.textContent = '✅ Copied!'; btn.style.background = '#059669'; }
  const applied = document.getElementById('couponApplied');
  if (applied) applied.style.display = 'block';
  setTimeout(() => {
    if (btn) { btn.textContent = '📋 Copy'; btn.style.background = '#10b981'; }
  }, 2000);
}

// ═══════════════════════════════════════════════════════════════════════
// ── RANK TRACKER UI — Background engine se connect karo ───────────────
// ═══════════════════════════════════════════════════════════════════════

// Listen for rank updates from background
chrome.runtime.onMessage.addListener(msg => {
  if (msg.type !== 'RANK_UPDATE') return;
  const { status, page, message, idsFound, rank, posInPage, perPage, sample } = msg;

  if (status === 'progress') {
    const sampleTxt = sample ? `\nSample IDs: ${sample}` : '';
    rankUpdateStatus(
      `📄 Page ${page}/100 | 🔢 ${idsFound} IDs collected | ${message}${sampleTxt}`,
      page, 100
    );
    // Update count badge
    const statusBox = document.getElementById('rankStatusBox');
    if (statusBox) {
      let countEl = document.getElementById('rankLiveCount');
      if (!countEl) {
        countEl = document.createElement('div');
        countEl.id = 'rankLiveCount';
        countEl.style.cssText = 'margin-top:10px;background:var(--bg2);border:1.5px solid var(--accent);border-radius:6px;padding:8px 12px;font-size:11px;font-weight:800;color:var(--accent);text-align:center;';
        statusBox.appendChild(countEl);
      }
      countEl.textContent = `🔢 ${idsFound} Product IDs collected — Page ${page} scan ho raha hai`;
    }
  }
  else if (status === 'found') {
    rankShowFound(rank, msg.page, posInPage, perPage, msg.keyword, msg.catalogId);
    stopRankUI();
  }
  else if (status === 'notfound') {
    rankUpdateStatus(`❌ ${message}`, 0, 0);
    document.getElementById('rankSpinner').style.display = 'none';
    stopRankUI();
  }
  else if (status === 'error') {
    rankUpdateStatus(`❌ Error: ${message}`, 0, 0);
    document.getElementById('rankSpinner').style.display = 'none';
    stopRankUI();
  }
});

async function startRankCheck() {
  const keyword  = document.getElementById('rankKeyword')?.value?.trim();
  const targetId = document.getElementById('rankCatalogId')?.value?.trim();
  if (!keyword)  { alert('Keyword daalo pehle!'); return; }
  if (!targetId) { alert('Product ID daalo pehle!'); return; }

  document.getElementById('btnCheckRank').style.display  = 'none';
  document.getElementById('btnStopRank').style.display   = '';
  document.getElementById('rankResultBox').style.display = 'none';
  document.getElementById('rankStatusBox').style.display = 'block';
  document.getElementById('rankSpinner').style.display   = 'block';
  rankUpdateStatus('Background engine shuru ho raha hai...', 0, 100);

  const res = await new Promise(r => chrome.runtime.sendMessage({ type: 'RANK_START', keyword, targetId }, r));
  if (res?.error) {
    rankUpdateStatus('❌ ' + res.error, 0, 0);
    document.getElementById('rankSpinner').style.display = 'none';
    stopRankUI();
  }
}

function stopRankUI() {
  const startBtn = document.getElementById('btnCheckRank');
  const stopBtn  = document.getElementById('btnStopRank');
  const spinner  = document.getElementById('rankSpinner');
  if (startBtn) startBtn.style.display = '';
  if (stopBtn)  stopBtn.style.display  = 'none';
  if (spinner)  spinner.style.display  = 'none';
}


function rankRenderHistory(currentKey) {
  chrome.storage.local.get(['rankHistory'], r => {
    const h   = r.rankHistory || {};
    const box  = document.getElementById('rankHistoryBox');
    const list = document.getElementById('rankHistoryList');
    if (!list || !box) return;
    const key  = currentKey || Object.keys(h)[0] || '';
    const data = h[key];
    if (!data?.entries?.length) { box.style.display = 'none'; return; }
    box.style.display = 'block';

    const entries = data.entries;
    const recent  = entries.slice(0, 7).reverse();
    const maxRank = Math.max(...recent.map(e => e.rank || 0), 1);
    const minRank = Math.min(...recent.map(e => e.rank || 0), 0);
    const rng     = maxRank - minRank || 1;

    const bars = recent.map((e, i) => {
      const bh = Math.max(4, Math.round((1 - (e.rank - minRank) / rng) * 32));
      const isLast = i === recent.length - 1;
      return `<div style="flex:1;height:${bh}px;background:${isLast ? 'var(--accent)' : 'var(--border2)'};border-radius:3px 3px 0 0;align-self:flex-end;min-height:4px;" title="#${e.rank}"></div>`;
    }).join('');

    const rows = entries.map((e, i) => {
      const prev  = entries[i + 1];
      const diff  = prev ? prev.rank - e.rank : 0;
      const dc    = diff > 0 ? 'var(--green)' : diff < 0 ? 'var(--red)' : 'var(--text2)';
      const arrow = diff > 0 ? `▲${diff}` : diff < 0 ? `▼${Math.abs(diff)}` : '—';
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border2);">
        <div style="font-size:20px;font-weight:900;color:var(--accent);width:60px;">#${e.rank}</div>
        <div style="flex:1;">
          <div style="font-size:10px;font-weight:700;color:var(--text);">Page ${e.page || '?'}, Pos ${e.posInPage || '?'}</div>
          <div style="font-size:9px;color:var(--text2);">${e.date} ${e.time}</div>
        </div>
        <div style="font-size:13px;font-weight:800;color:${dc};">${arrow}</div>
      </div>`;
    }).join('');

    list.innerHTML = `
      <div style="display:flex;gap:3px;align-items:flex-end;height:36px;margin-bottom:12px;">${bars}</div>
      <div style="font-size:9px;font-weight:800;color:var(--text2);text-transform:uppercase;margin-bottom:6px;">
        🔑 ${data.keyword} | ID: ${data.catalogId}
      </div>${rows}`;
  });
}

function rankWaitForLoad(tabId) {
  return new Promise(res => {
    // First wait for tab status = complete via polling
    let attempts = 0;
    const poll = setInterval(async () => {
      attempts++;
      try {
        const tab = await chrome.tabs.get(tabId);
        if (tab.status === 'complete') {
          clearInterval(poll);
          res();
          return;
        }
      } catch(e) {
        clearInterval(poll);
        res();
        return;
      }
      // Hard timeout 18 seconds
      if (attempts > 90) {
        clearInterval(poll);
        res();
      }
    }, 200);
  });
}

function stopRankCheck() {
  rankRunning = false;
  const startBtn = document.getElementById('btnCheckRank');
  const stopBtn  = document.getElementById('btnStopRank');
  const spinner  = document.getElementById('rankSpinner');
  if (startBtn) startBtn.style.display = '';
  if (stopBtn)  stopBtn.style.display  = 'none';
  if (spinner)  spinner.style.display  = 'none';
}

function rankUpdateStatus(msg, page, maxPage) {
  const txt  = document.getElementById('rankStatusText');
  const prog = document.getElementById('rankProgress');
  if (txt)  txt.textContent = msg;
  if (prog && maxPage > 0) prog.style.width = Math.round((page / maxPage) * 100) + '%';
}

function rankShowFound(rank, page, posInPage, perPage, keyword, catalogId) {
  document.getElementById('rankResultBox').style.display = 'block';
  document.getElementById('rankStatusBox').style.display = 'none';

  const numEl = document.getElementById('rankNumber');
  numEl.textContent = `#${rank}`;
  // Color by rank
  if (rank <= 50)       numEl.style.color = 'var(--green)';
  else if (rank <= 200) numEl.style.color = 'var(--accent)';
  else if (rank <= 500) numEl.style.color = 'var(--gold)';
  else                  numEl.style.color = 'var(--red)';

  document.getElementById('rankDetail').textContent = `"${keyword}" search mein`;
  document.getElementById('rankPage').textContent   = page;
  document.getElementById('rankPos').textContent    = posInPage;
  document.getElementById('rankPPP').textContent    = perPage;

  // Save to history
  const entry = {
    date: new Date().toISOString().slice(0, 10),
    time: new Date().toLocaleTimeString('en-IN', { hour: '2-digit', minute: '2-digit' }),
    rank, page, posInPage, perPage, keyword, catalogId
  };
  chrome.storage.local.get(['rankHistory'], r => {
    const key = catalogId + '_' + keyword.replace(/\s+/g, '_').slice(0, 20);
    const h = r.rankHistory || {};
    if (!h[key]) h[key] = { keyword, catalogId, entries: [] };
    h[key].entries.unshift(entry);
    if (h[key].entries.length > 30) h[key].entries = h[key].entries.slice(0, 30);
    chrome.storage.local.set({ rankHistory: h }, () => rankRenderHistory(key));
  });
}

function rankRenderHistory(currentKey) {
  chrome.storage.local.get(['rankHistory'], r => {
    const h   = r.rankHistory || {};
    const box  = document.getElementById('rankHistoryBox');
    const list = document.getElementById('rankHistoryList');
    if (!list || !box) return;
    const key  = currentKey || Object.keys(h)[0] || '';
    const data = h[key];
    if (!data?.entries?.length) { box.style.display = 'none'; return; }
    box.style.display = 'block';

    const entries = data.entries;
    // Mini bar chart — last 7
    const recent  = entries.slice(0, 7).reverse();
    const maxRank = Math.max(...recent.map(e => e.rank || 0), 1);
    const minRank = Math.min(...recent.map(e => e.rank || 0), 0);
    const rng     = maxRank - minRank || 1;

    const bars = recent.map((e, i) => {
      const h = Math.max(4, Math.round((1 - (e.rank - minRank) / rng) * 32));
      const isLast = i === recent.length - 1;
      return `<div style="flex:1;height:${h}px;background:${isLast ? 'var(--accent)' : 'var(--border2)'};border-radius:3px 3px 0 0;align-self:flex-end;min-height:4px;transition:height .3s;" title="#${e.rank}"></div>`;
    }).join('');

    const rows = entries.map((e, i) => {
      const prev = entries[i + 1];
      const diff = prev ? prev.rank - e.rank : 0;
      const dc   = diff > 0 ? 'var(--green)' : diff < 0 ? 'var(--red)' : 'var(--text2)';
      const arrow = diff > 0 ? `▲${diff}` : diff < 0 ? `▼${Math.abs(diff)}` : '—';
      return `<div style="display:flex;align-items:center;gap:8px;padding:6px 0;border-bottom:1px solid var(--border2);">
        <div style="font-size:20px;font-weight:900;color:var(--accent);width:60px;font-family:Verdana;">#${e.rank}</div>
        <div style="flex:1;">
          <div style="font-size:10px;font-weight:700;color:var(--text);">Page ${e.page}, Pos ${e.posInPage}</div>
          <div style="font-size:9px;color:var(--text2);">${e.date} ${e.time}</div>
        </div>
        <div style="font-size:13px;font-weight:800;color:${dc};">${arrow}</div>
      </div>`;
    }).join('');

    list.innerHTML = `
      <div style="display:flex;gap:3px;align-items:flex-end;height:36px;margin-bottom:12px;padding:0 2px;">
        ${bars}
      </div>
      <div style="font-size:9px;font-weight:800;color:var(--text2);text-transform:uppercase;margin-bottom:6px;">
        🔑 ${data.keyword} | ID: ${data.catalogId}
      </div>
      ${rows}`;
  });
}

// Stub: capture profiles (kept for backward compat with profile save)
async function loadCaptureProfiles() { /* replaced by Scribbles tab */ }

// ═══════════════════════════════════════════════════════════════════════
// ── SCRIBBLES (Meesho Listing Keyword Optimizer) ──────────────────────
// ═══════════════════════════════════════════════════════════════════════

let scribbleKeywords = []; // Array of lowercase trimmed keywords

// Load keywords from textarea into state + render chips
function scribbleLoadKeywords() {
  const raw = document.getElementById("scribble-keywords").value;
  const lines = raw.split("\n").map(s => s.trim().toLowerCase()).filter(Boolean);
  scribbleKeywords = [...new Set(lines)]; // deduplicate
  renderScribbleChips();
  scribbleUpdateHighlights("title");
  scribbleUpdateHighlights("desc");
  scribbleRenderDensityTable();
}

function scribbleClearKeywords() {
  scribbleKeywords = [];
  document.getElementById("scribble-keywords").value = "";
  document.getElementById("scribble-kw-chips").innerHTML = "";
  scribbleUpdateHighlights("title");
  scribbleUpdateHighlights("desc");
}

// Render keyword chips with matched/unmatched state
function renderScribbleChips() {
  const titleText = document.getElementById("scribble-title-editor").innerText.toLowerCase();
  const descText  = document.getElementById("scribble-desc-editor").innerText.toLowerCase();
  const container = document.getElementById("scribble-kw-chips");
  container.innerHTML = "";
  scribbleKeywords.forEach(kw => {
    const inTitle = titleText.includes(kw);
    const inDesc  = descText.includes(kw);
    const matched = inTitle || inDesc;
    const chip = document.createElement("span");
    chip.className = "scribble-chip " + (matched ? "matched" : "unmatched");
    chip.title = matched ? "✅ Used in title/desc" : "❌ Not used yet";
    chip.textContent = kw;
    container.appendChild(chip);
  });
}

// Highlight keywords inside a contenteditable div WITHOUT breaking cursor
function scribbleUpdateHighlights(which) {
  const editorId = which === "title" ? "scribble-title-editor" : "scribble-desc-editor";
  const editor = document.getElementById(editorId);
  const maxChars = which === "title" ? 200 : 1000;
  const kwCountId   = which === "title" ? "scribble-title-kw-count" : "scribble-desc-kw-count";
  const kwTotalId   = which === "title" ? "scribble-title-kw-total" : "scribble-desc-kw-total";
  const charCountId = which === "title" ? "scribble-title-chars" : "scribble-desc-chars";
  const progressId  = which === "title" ? "scribble-title-progress" : "scribble-desc-progress";

  // Get plain text first (strip HTML)
  const plain = editor.innerText;

  // Char count enforcement
  document.getElementById(charCountId).textContent = plain.length;
  if (plain.length > maxChars) {
    document.getElementById(charCountId).style.color = "#c62828";
  } else {
    document.getElementById(charCountId).style.color = "#555";
  }

  // Count matched keywords
  const lowerPlain = plain.toLowerCase();
  let matchedCount = 0;
  scribbleKeywords.forEach(kw => { if (lowerPlain.includes(kw)) matchedCount++; });

  document.getElementById(kwCountId).textContent = matchedCount;
  document.getElementById(kwTotalId).textContent = scribbleKeywords.length;

  // Progress bar
  const pct = scribbleKeywords.length > 0 ? Math.round((matchedCount / scribbleKeywords.length) * 100) : 0;
  document.getElementById(progressId).style.width = pct + "%";

  // Rebuild highlighted HTML (save + restore caret position)
  if (scribbleKeywords.length === 0) {
    renderScribbleChips();
    return;
  }

  // Save caret offset
  const savedOffset = scribbleGetCaretOffset(editor);

  // Build highlighted HTML from plain text
  let html = scribbleEscapeHtml(plain);
  // Sort keywords longest first to avoid partial replacements
  const sorted = [...scribbleKeywords].sort((a, b) => b.length - a.length);
  sorted.forEach(kw => {
    const escaped = scribbleEscapeHtml(kw);
    const regex = new RegExp(escaped.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    html = html.replace(regex, match => `<mark class="scribble-highlight">${match}</mark>`);
  });

  // Only update innerHTML if changed (avoids unnecessary reflows)
  if (editor.innerHTML !== html) {
    editor.innerHTML = html;
    // Restore caret
    scribbleSetCaretOffset(editor, savedOffset);
  }

  renderScribbleChips();
}

// Caret offset helpers (works with nested <mark> tags)
function scribbleGetCaretOffset(el) {
  let offset = 0;
  const sel = window.getSelection();
  if (!sel || sel.rangeCount === 0) return 0;
  const range = sel.getRangeAt(0).cloneRange();
  range.selectNodeContents(el);
  range.setEnd(sel.getRangeAt(0).endContainer, sel.getRangeAt(0).endOffset);
  offset = range.toString().length;
  return offset;
}

function scribbleSetCaretOffset(el, offset) {
  const sel = window.getSelection();
  if (!sel) return;
  const range = document.createRange();
  let chars = 0;
  let found = false;

  function traverse(node) {
    if (found) return;
    if (node.nodeType === Node.TEXT_NODE) {
      const next = chars + node.length;
      if (offset <= next) {
        range.setStart(node, offset - chars);
        range.setEnd(node, offset - chars);
        found = true;
      }
      chars = next;
    } else {
      for (const child of node.childNodes) traverse(child);
    }
  }

  traverse(el);
  if (!found) { range.selectNodeContents(el); range.collapse(false); }
  sel.removeAllRanges();
  sel.addRange(range);
}

function scribbleEscapeHtml(str) {
  return str.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;");
}

// Get plain text from editor (for saving/AI use)
function scribbleGetPlain(which) {
  const el = document.getElementById(which === "title" ? "scribble-title-editor" : "scribble-desc-editor");
  return el.innerText.trim();
}

// Save scribble
async function scribbleSave() {
  const name = document.getElementById("scribble-save-name").value.trim();
  const statusEl = document.getElementById("scribble-save-status");
  if (!name) { showStatus(statusEl, "⚠ Save name daalein", "error"); return; }
  const title = scribbleGetPlain("title");
  const desc  = scribbleGetPlain("desc");
  if (!title) { showStatus(statusEl, "⚠ Title khali hai", "error"); return; }
  const stored = await chromeGet(["scribbleSaved"]);
  const all = stored.scribbleSaved || {};
  all[name] = { title, desc, keywords: [...scribbleKeywords], savedAt: Date.now() };
  await chromeSet({ scribbleSaved: all });
  showStatus(statusEl, `✅ "${name}" save ho gaya!`, "success");
  scribbleLoadSavedList();
  scribblePopulateAiSelect();
}

// Reset current scribble editors
function scribbleReset() {
  document.getElementById("scribble-title-editor").innerHTML = "";
  document.getElementById("scribble-desc-editor").innerHTML = "";
  document.getElementById("scribble-title-chars").textContent = "0";
  document.getElementById("scribble-desc-chars").textContent = "0";
  document.getElementById("scribble-title-kw-count").textContent = "0";
  document.getElementById("scribble-desc-kw-count").textContent = "0";
  document.getElementById("scribble-title-progress").style.width = "0%";
  document.getElementById("scribble-desc-progress").style.width = "0%";
  renderScribbleChips();
}

// Load saved list into panel
async function scribbleLoadSavedList() {
  const stored = await chromeGet(["scribbleSaved"]);
  const all = stored.scribbleSaved || {};
  const wrap = document.getElementById("scribble-saved-list-wrap");
  const list = document.getElementById("scribble-saved-list");
  const keys = Object.keys(all);
  if (keys.length === 0) { wrap.style.display = "none"; return; }
  wrap.style.display = "block";
  list.innerHTML = "";
  keys.forEach(name => {
    const s = all[name];
    const row = document.createElement("div");
    row.style.cssText = "background:#fff;border:2px solid #000;padding:8px;margin-bottom:6px;";
    row.innerHTML = `
      <div style="font-size:10px;font-weight:900;color:#000;margin-bottom:3px;">📁 ${scribbleEscapeHtml(name)}</div>
      <div style="font-size:9px;color:#555;margin-bottom:5px;">Title: ${scribbleEscapeHtml((s.title||"").substring(0,60))}${s.title&&s.title.length>60?"...":""}</div>
      <div style="display:flex;gap:4px;">
        <button class="btn btn-black" style="flex:1;padding:5px;font-size:9px;margin-bottom:0;" data-scribble-load="${name}">📂 Load</button>
        <button class="btn btn-red" style="flex:1;padding:5px;font-size:9px;margin-bottom:0;background:#fff;color:#c62828;border-color:#c62828;" data-scribble-del="${name}">🗑 Delete</button>
      </div>`;
    list.appendChild(row);
  });

  // Event delegation for load/delete
  list.querySelectorAll("[data-scribble-load]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const n = btn.dataset.scribbleLoad;
      const st2 = await chromeGet(["scribbleSaved"]);
      const entry = (st2.scribbleSaved || {})[n];
      if (!entry) return;
      // Restore keywords
      if (entry.keywords && entry.keywords.length) {
        scribbleKeywords = entry.keywords;
        document.getElementById("scribble-keywords").value = entry.keywords.join("\n");
      }
      // Set title + desc as plain text, then highlight
      document.getElementById("scribble-title-editor").innerText = entry.title || "";
      document.getElementById("scribble-desc-editor").innerText = entry.desc || "";
      scribbleUpdateHighlights("title");
      scribbleUpdateHighlights("desc");
      scribbleRenderDensityTable();
      document.getElementById("scribble-save-name").value = n;
    });
  });
  list.querySelectorAll("[data-scribble-del]").forEach(btn => {
    btn.addEventListener("click", async () => {
      if (!confirm(`"${btn.dataset.scribbleDel}" delete karna chahte hain?`)) return;
      const st2 = await chromeGet(["scribbleSaved"]);
      const all2 = st2.scribbleSaved || {};
      delete all2[btn.dataset.scribbleDel];
      await chromeSet({ scribbleSaved: all2 });
      scribbleLoadSavedList();
      scribblePopulateAiSelect();
    });
  });
}

// Populate AI select dropdown
async function scribblePopulateAiSelect() {
  const stored = await chromeGet(["scribbleSaved"]);
  const all = stored.scribbleSaved || {};
  const names = Object.keys(all).sort((a, b) => (all[b].savedAt || 0) - (all[a].savedAt || 0));   // newest first
  ["scribble-ai-select", "img-scribble-select"].forEach(id => {
    const sel = document.getElementById(id);
    if (!sel) return;
    const keep = sel.value;
    sel.innerHTML = '<option value="">-- Saved Scribble chunein --</option>';
    names.forEach(name => { const opt = document.createElement("option"); opt.value = name; opt.textContent = name; sel.appendChild(opt); });
    if (keep && all[keep]) sel.value = keep;
  });
}

// Get selected scribble for AI use (called from image/text tab generate)
async function scribbleGetSelectedForAI() {
  // Image tab: "Title & Description kahan se?" → Saved Scribble
  const src = document.querySelector('input[name="imgTdSrc"]:checked')?.value;
  if (src === "scribble") {
    const n = document.getElementById("img-scribble-select")?.value;
    if (n) { const st = await chromeGet(["scribbleSaved"]); const e = (st.scribbleSaved || {})[n]; if (e) return e; }
  }
  const checkbox = document.getElementById("scribble-use-in-ai");
  if (!checkbox.checked) return null;
  const selName = document.getElementById("scribble-ai-select").value;
  if (!selName) return null;
  const stored = await chromeGet(["scribbleSaved"]);
  return (stored.scribbleSaved || {})[selName] || null;
}

// ── Scribble Keyword Density Table ──────────────────────────────────────────
// Per-keyword: how many times in title, how many in desc, target, status
let scribbleDensityTargets = {}; // { keyword: { title: N, desc: N } }

function scribbleRenderDensityTable() {
  const table = document.getElementById("scribble-density-table");
  if (!table) return;
  if (!scribbleKeywords.length) { table.innerHTML = '<div style="font-size:10px;color:#888;padding:4px 0;">Keywords load karo pehle</div>'; return; }

  const titleText = document.getElementById("scribble-title-editor").innerText.toLowerCase();
  const descText  = document.getElementById("scribble-desc-editor").innerText.toLowerCase();

  // Default targets from inputs
  const defTitle = parseInt(document.getElementById("scribble-target-title")?.value || "1", 10);
  const defDesc  = parseInt(document.getElementById("scribble-target-desc")?.value || "2", 10);

  let html = `<table style="width:100%;border-collapse:collapse;font-size:10px;">
    <thead>
      <tr style="background:#000;color:#fde047;font-size:9px;">
        <th style="padding:4px 6px;text-align:left;font-weight:900;">KEYWORD</th>
        <th style="padding:4px 3px;text-align:center;">TITLE<br>Count/Target</th>
        <th style="padding:4px 3px;text-align:center;">DESC<br>Count/Target</th>
        <th style="padding:4px 6px;text-align:center;">STATUS</th>
      </tr>
    </thead>
    <tbody>`;

  scribbleKeywords.forEach((kw, idx) => {
    if (!scribbleDensityTargets[kw]) scribbleDensityTargets[kw] = { title: defTitle, desc: defDesc };
    const tgt = scribbleDensityTargets[kw];

    // Count occurrences
    const re = new RegExp(kw.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "gi");
    const titleCount = (titleText.match(re) || []).length;
    const descCount  = (descText.match(re) || []).length;

    const titleMet = titleCount >= tgt.title;
    const descMet  = descCount >= tgt.desc;
    const bothMet  = titleMet && descMet;
    const noneUsed = titleCount === 0 && descCount === 0;

    const statusIcon = bothMet ? "🟢" : noneUsed ? "🔴" : "🟡";
    const rowBg = idx % 2 === 0 ? "#fff" : "#fafafa";

    html += `<tr style="background:${rowBg};border-bottom:1px solid #e5e7eb;">
      <td style="padding:4px 6px;font-weight:700;max-width:90px;word-break:break-word;">${scribbleEscapeHtml(kw)}</td>
      <td style="padding:4px 3px;text-align:center;">
        <span style="font-size:12px;font-weight:900;color:${titleMet?"#16a34a":"#dc2626"};">${titleCount}</span>
        <span style="font-size:9px;color:#888;">/</span>
        <input type="number" min="0" max="9" value="${tgt.title}" data-kw="${scribbleEscapeHtml(kw)}" data-field="title"
          style="width:28px;padding:2px;border:1px solid #ccc;font-size:10px;font-weight:700;text-align:center;background:${titleMet?"#f0fdf4":"#fff7f7"};" class="density-target-inp" />
      </td>
      <td style="padding:4px 3px;text-align:center;">
        <span style="font-size:12px;font-weight:900;color:${descMet?"#2563eb":"#dc2626"};">${descCount}</span>
        <span style="font-size:9px;color:#888;">/</span>
        <input type="number" min="0" max="20" value="${tgt.desc}" data-kw="${scribbleEscapeHtml(kw)}" data-field="desc"
          style="width:28px;padding:2px;border:1px solid #ccc;font-size:10px;font-weight:700;text-align:center;background:${descMet?"#eff6ff":"#fff7f7"};" class="density-target-inp" />
      </td>
      <td style="padding:4px 6px;text-align:center;font-size:14px;">${statusIcon}</td>
    </tr>`;
  });

  html += "</tbody></table>";
  table.innerHTML = html;

  // Wire target input changes
  table.querySelectorAll(".density-target-inp").forEach(inp => {
    inp.addEventListener("change", () => {
      const kw = inp.dataset.kw;
      const field = inp.dataset.field;
      const val = Math.max(0, parseInt(inp.value, 10) || 0);
      if (!scribbleDensityTargets[kw]) scribbleDensityTargets[kw] = { title: defTitle, desc: defDesc };
      scribbleDensityTargets[kw][field] = val;
      scribbleRenderDensityTable(); // re-render with new target
    });
  });
}

// ── Export / Import ────────────────────────────────────────────────────────────
async function exportData() {
  const statusEl = document.getElementById("defaults-status");
  try {
    const stored = await chromeGet(["defaultFields", "captureProfiles", "savedProfiles", "sellerDetails", "scribbleSaved"]);
    const blob = new Blob([JSON.stringify(stored, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob); const a = document.createElement("a");
    a.href = url; a.download = `kiwtech_backup_${Date.now()}.json`; a.click(); URL.revokeObjectURL(url);
  } catch (e) { console.error("Export error", e); }
}

// ── Admin Panel ────────────────────────────────────────────────────────────────
async function handleAdminLogin() {
  const pass = document.getElementById("adminPassInput").value.trim();
  const statusEl = document.getElementById("admin-login-status");
  if (!pass) { showStatus(statusEl, "⚠ Password daalein", "error"); return; }
  adminPass = pass;
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "ADMIN_LIST_KEYS", adminPass: pass }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (res.success) {
    showStatus(statusEl, "✅ Login successful!", "success");
    document.getElementById("admin-logged-in").style.display = "block";
    renderAdminKeys(res.keys);
  } else {
    showStatus(statusEl, `❌ ${res.error || "Wrong password"}`, "error");
  }
}

async function handleAdminGenKey() {
  const statusEl = document.getElementById("admin-gen-status");
  const plan = document.getElementById("adminPlan").value;
  const expiry = parseInt(document.getElementById("adminExpiry").value) || 30;
  const gmail = document.getElementById("adminGmailInput").value.trim();
  const note = document.getElementById("adminNote").value.trim();
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "ADMIN_GENERATE_KEY", adminPass, plan, expiryDays: expiry, gmail, note }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (res.success) {
    showStatus(statusEl, "✅ Key generated!", "success");
    document.getElementById("admin-new-key").style.display = "block";
    document.getElementById("admin-new-key-val").textContent = res.key;
    document.getElementById("admin-new-key-exp").textContent = `Gmail: ${gmail || '-'} | Expiry: ${new Date(res.expiry).toLocaleDateString('en-IN')} | Plan: ${plan}`;
    loadAdminKeys();
  } else {
    showStatus(statusEl, `❌ ${res.error}`, "error");
  }
}

async function loadAdminKeys() {
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "ADMIN_LIST_KEYS", adminPass }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (res.success) renderAdminKeys(res.keys);
}

function renderAdminKeys(keys) {
  const container = document.getElementById("admin-keys-list");
  const entries = Object.entries(keys);
  if (!entries.length) { container.innerHTML = '<p style="font-size:11px;color:#888;padding:8px;">Koi keys nahi hain abhi.</p>'; return; }
  container.innerHTML = entries.map(([key, info]) => {
    const expired = info.expiry && new Date() > new Date(info.expiry);
    const status = !info.active ? '<span class="key-inactive">INACTIVE</span>' : expired ? '<span class="key-expired">EXPIRED</span>' : '<span class="key-active">ACTIVE ✓</span>';
    const expDate = info.expiry ? new Date(info.expiry).toLocaleDateString('en-IN') : 'Never';
    return `
      <div class="admin-key-row">
        <div class="admin-key-code">${key}</div>
        <div class="admin-key-meta">${status} | Plan: ${info.plan || '-'} | Exp: ${expDate}</div>
        ${info.gmail ? `<div class="admin-key-meta" style="color:#1565c0;">📧 ${escHtml(info.gmail)}</div>` : ''}
        ${info.note ? `<div class="admin-key-meta" style="color:#333;">Note: ${escHtml(info.note)}</div>` : ''}
        ${info.active && !expired ? `<button onclick="deactivateKey('${key}')" style="background:#f44;color:#fff;border:1px solid #c00;font-size:9px;padding:2px 6px;cursor:pointer;margin-top:4px;">Deactivate</button>` : ''}
      </div>
    `;
  }).join('');
}

async function deactivateKey(key) {
  if (!confirm(`Deactivate key: ${key}?`)) return;
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "ADMIN_DEACTIVATE_KEY", adminPass, key }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (res.success) loadAdminKeys();
  else alert("Error: " + res.error);
}

async function handleAdminExport() {
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({ type: "ADMIN_EXPORT_KEYS", adminPass }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (!res.success) { alert("Export failed: " + (res.error || "unknown")); return; }
  const blob = new Blob([JSON.stringify({ keys: res.keys }, null, 2)], { type: "application/json" });
  const url  = URL.createObjectURL(blob);
  const a    = document.createElement("a");
  a.href = url; a.download = "kiwtech-keys-export.json"; a.click();
  URL.revokeObjectURL(url);
}

async function handleAdminImport(e) {
  const file = e.target.files[0];
  if (!file) return;
  try {
    const text = await file.text();
    const data = JSON.parse(text);
    const keys = data.keys || data;
    if (!keys || typeof keys !== "object") { alert("Invalid keys.json format"); return; }
    const res = await new Promise(resolve => {
      chrome.runtime.sendMessage({ type: "ADMIN_IMPORT_KEYS", adminPass, keys }, r => {
        if (chrome.runtime.lastError) resolve({ success: false });
        else resolve(r);
      });
    });
    if (res.success) { alert(`✅ ${res.imported} keys import ho gayi!`); loadAdminKeys(); }
    else alert("Import failed: " + (res.error || "unknown"));
  } catch (err) {
    alert("File parse error: " + err.message);
  }
  e.target.value = "";
}

// ── Buy Now / Demo ────────────────────────────────────────────────────────────
const OWNER_WHATSAPP = "918929401527"; // Kiwtech WhatsApp number

const PLAN_LABELS = {
  "1_month": "1 Month Plan — ₹699",
  "3_month": "3 Months Plan — ₹1,799",
  "1_year":  "1 Year Plan — ₹5,999 (Best Value)"
};

function handleBuyNow() {
  const plan = document.getElementById("buyPlanSelect").value;
  const planLabel = PLAN_LABELS[plan] || plan;
  const msg = encodeURIComponent(
    `Namaste! 🙏\n\nMujhe Kiwtech Meesho All-in-One Tool ka *${planLabel}* khareedna hai.\n\n✅ AI Listing Generator\n✅ Shipping Cost Optimizer\n\nPlease payment details send karein.\n\n📧 Extension: v5.0`
  );
  chrome.tabs.create({ url: `https://wa.me/${OWNER_WHATSAPP}?text=${msg}` });
}

function handleDemoRequest() {
  const msg = encodeURIComponent(
    `Namaste! 🙏\n\nMujhe Kiwtech Meesho Tool ka *4-Hour FREE Demo* chahiye.\n\nMera Gmail ID: (apna gmail yahan likhein)\n\nKripya demo key send karein — main try karke purchase karunga.\n\n📧 Extension: v5.0`
  );
  chrome.tabs.create({ url: `https://wa.me/${OWNER_WHATSAPP}?text=${msg}` });
}

function handleDemoRequestFromAuth() {
  const gmail = document.getElementById("authGmail").value.trim() || "(gmail nahi diya)";
  const msg = encodeURIComponent(
    `Namaste! 🙏\n\nMujhe Kiwtech Meesho Tool ka *4-Hour FREE Demo* chahiye.\n\n📧 Mera Gmail ID: ${gmail}\n\nKripya demo key send karein.\n\n📧 Extension: v5.0`
  );
  chrome.tabs.create({ url: `https://wa.me/${OWNER_WHATSAPP}?text=${msg}` });
}

// ── Admin: Generate Demo Key (4 hours) ───────────────────────────────────────
async function handleAdminGenDemoKey() {
  const statusEl = document.getElementById("admin-gen-status");
  const gmail = document.getElementById("adminGmailInput").value.trim();
  const note  = document.getElementById("adminNote").value.trim();
  if (!gmail) { showStatus(statusEl, "⚠ Client Gmail ID daalein", "error"); return; }
  const res = await new Promise(resolve => {
    chrome.runtime.sendMessage({
      type: "ADMIN_GENERATE_DEMO",
      adminPass,
      gmail,
      note: note || `4hr Demo - ${gmail}`
    }, r => {
      if (chrome.runtime.lastError) resolve({ success: false });
      else resolve(r);
    });
  });
  if (res.success) {
    showStatus(statusEl, "✅ 4-Hour Demo Key Generated!", "success");
    document.getElementById("admin-new-key").style.display = "block";
    document.getElementById("admin-new-key-val").textContent = res.key;
    document.getElementById("admin-new-key-exp").textContent = `Gmail: ${gmail} | Expiry: ${new Date(res.expiry).toLocaleString('en-IN')} | DEMO (4hrs)`;
    loadAdminKeys();
  } else {
    showStatus(statusEl, `❌ ${res.error}`, "error");
  }
}

// ── Utilities ──────────────────────────────────────────────────────────────────
function showStatus(el, msg, type) { el.textContent = msg; el.className = `status${type ? " " + type : ""}`; }
function escHtml(str) { return String(str || "").replace(/&/g,"&amp;").replace(/"/g,"&quot;").replace(/</g,"&lt;").replace(/>/g,"&gt;"); }
function chromeGet(keys) { return new Promise(resolve => chrome.storage.local.get(keys, resolve)); }
function chromeSet(obj)  { return new Promise(resolve => chrome.storage.local.set(obj, resolve)); }
function sendToBackground(message) {
  return new Promise((resolve, reject) => {
    chrome.runtime.sendMessage(message, response => {
      if (chrome.runtime.lastError) reject(new Error(chrome.runtime.lastError.message));
      else resolve(response);
    });
  });
}
function fileToBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(reader.result.split(",")[1]);
    reader.onerror = () => reject(new Error("File read failed"));
    reader.readAsDataURL(file);
  });
}

// ═══════════════════════════════════════════════════════════
// SHIPPING TAB LOGIC
// ═══════════════════════════════════════════════════════════

let shipBlob = null;
let shipResults = [];
let shipShouldStop = false;
let shipIsProcessing = false;

function shipFileChange(e) {
  const file = e.target.files[0];
  if (!file) return;
  shipBlob = file;
  showShipPreview(URL.createObjectURL(file));
  const det = document.getElementById("ship-detect-status");
  if (det) { det.textContent = "✅ Image loaded from file"; det.className = "status success"; }
}

function showShipPreview(url) {
  const wrap = document.getElementById("ship-preview-wrap");
  const img = document.getElementById("ship-preview-img");
  if (wrap && img) { img.src = url; wrap.style.display = "block"; }
}

async function shipAutodetect() {
  const btn = document.getElementById("ship-autodetect-btn");
  const det = document.getElementById("ship-detect-status");
  btn.disabled = true; btn.textContent = "⏳ Detecting...";

  const res = await new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0] || !tabs[0].url.includes("meesho.com")) { resolve(null); return; }
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          // Try #changeFrontImage file first
          const inp = document.querySelector("#changeFrontImage");
          if (inp && inp.files && inp.files[0]) {
            return new Promise(r => {
              const reader = new FileReader();
              reader.onload = () => r({ dataUrl: reader.result });
              reader.readAsDataURL(inp.files[0]);
            });
          }
          // Try displayed product image
          const imgs = Array.from(document.querySelectorAll("img")).filter(i => i.naturalWidth > 150 && i.src.startsWith("http"));
          if (imgs.length > 0) {
            return { imgUrl: imgs[0].src };
          }
          return null;
        }
      }, results => {
        if (chrome.runtime.lastError || !results || !results[0]) { resolve(null); return; }
        resolve(results[0].result);
      });
    });
  });

  if (res) {
    if (res.dataUrl) {
      // Convert dataUrl to blob
      const r = await fetch(res.dataUrl);
      shipBlob = await r.blob();
      showShipPreview(res.dataUrl);
      det.textContent = "✅ Image detected from page!"; det.className = "status success";
    } else if (res.imgUrl) {
      try {
        const r = await fetch(res.imgUrl);
        shipBlob = await r.blob();
        showShipPreview(res.imgUrl);
        det.textContent = "✅ Product image detected!"; det.className = "status success";
      } catch(e) {
        det.textContent = "❌ Image fetch failed — manually upload karein"; det.className = "status error";
      }
    }
  } else {
    det.textContent = "⚠ Not found — Meesho listing page kholen ya manually upload karein"; det.className = "status error";
  }

  btn.disabled = false; btn.textContent = "🔍 Auto-Detect from Meesho Page";

  // Also detect current shipping cost
  detectAndShowShipping();
}

async function detectAndShowShipping() {
  const costDiv = document.getElementById("ship-current-cost");
  const costVal = document.getElementById("ship-current-val");
  if (!costDiv || !costVal) return;

  const res = await new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0] || !tabs[0].url.includes("meesho.com")) { resolve(null); return; }
      chrome.scripting.executeScript({
        target: { tabId: tabs[0].id },
        func: () => {
          const selectors = ["p.MuiTypography-root.MuiTypography-body1.css-v40lxd", '[class*="css-v40lxd"]', ".MuiTypography-body1"];
          for (const sel of selectors) {
            const els = document.querySelectorAll(sel);
            for (const el of els) {
              const txt = el.textContent || "";
              if ((txt.includes("shipping") || txt.includes("Shipping")) && txt.includes("₹")) {
                const m = txt.match(/₹\s*(\d+)/);
                if (m) return parseInt(m[1]);
              }
            }
          }
          return null;
        }
      }, results => {
        if (chrome.runtime.lastError || !results || !results[0]) resolve(null);
        else resolve(results[0].result);
      });
    });
  });

  if (res) {
    costDiv.style.display = "block";
    costVal.textContent = "₹" + res;
  }
}

async function shipStart() {
  if (!shipBlob) { alert("Pehle image select karein ya auto-detect karein"); return; }
  if (shipIsProcessing) return;

  const target = parseInt(document.getElementById("ship-target").value) || 30;
  const maxAttempts = parseInt(document.getElementById("ship-attempts").value) || 30;

  // Show progress, hide results and start btn
  document.getElementById("ship-start-btn").style.display = "none";
  document.getElementById("ship-stop-btn").style.display = "block";
  document.getElementById("ship-progress-wrap").style.display = "block";
  document.getElementById("ship-results-wrap").style.display = "none";

  shipResults = [];
  shipShouldStop = false;
  shipIsProcessing = true;

  // Send message to active Meesho tab to run optimizer
  const tabRes = await new Promise(resolve => {
    chrome.tabs.query({ active: true, currentWindow: true }, tabs => {
      if (!tabs[0] || !tabs[0].url.includes("meesho.com")) { resolve({ success: false, error: "Meesho page open karein" }); return; }

      // Convert blob to base64 to pass to content script
      const reader = new FileReader();
      reader.onload = () => {
        chrome.tabs.sendMessage(tabs[0].id, {
          action: "RUN_SHIPPING_OPTIMIZER",
          imageData: reader.result,
          target,
          maxAttempts
        }, res => {
          if (chrome.runtime.lastError) resolve({ success: false, error: chrome.runtime.lastError.message });
          else resolve(res || { success: false, error: "No response" });
        });
      };
      reader.onerror = () => resolve({ success: false, error: "File read failed" });
      reader.readAsDataURL(shipBlob);
    });
  });

  if (!tabRes.success) {
    // Content script might not handle this — run via scripting API
    await runShipOptimizerViaScripting(target, maxAttempts);
    return;
  }
}

// Run optimizer by injecting into page
async function runShipOptimizerViaScripting(target, maxAttempts) {
  // Since MeeshoAPI runs in content script, we trigger the modal there
  // and poll for results
  const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
  if (!tabs[0]) {
    shipReset();
    alert("Meesho supplier page kholen phir try karein");
    return;
  }

  // Send message to content script shipping optimizer
  const reader = new FileReader();
  const dataUrl = await new Promise(resolve => {
    reader.onload = () => resolve(reader.result);
    reader.onerror = () => resolve(null);
    reader.readAsDataURL(shipBlob);
  });

  if (!dataUrl) { shipReset(); return; }

  // Tell content script to run optimizer with this image
  chrome.tabs.sendMessage(tabs[0].id, {
    action: "POPUP_SHIP_START",
    imageDataUrl: dataUrl,
    target,
    maxAttempts
  });

  // Poll for progress updates via storage
  const pollInterval = setInterval(async () => {
    const stored = await chromeGet(["shipProgress", "shipResults"]);
    if (shipShouldStop) {
      clearInterval(pollInterval);
      shipStop(stored.shipResults || []);
      return;
    }
    if (stored.shipProgress) {
      const p = stored.shipProgress;
      const pct = Math.round((p.attempt / p.total) * 100);
      const barEl = document.getElementById("ship-progress-bar-inner");
      const txtEl = document.getElementById("ship-progress-text");
      const cntEl = document.getElementById("ship-progress-count");
      const bestEl = document.getElementById("ship-progress-best");
      if (barEl) barEl.style.width = pct + "%";
      if (txtEl) txtEl.textContent = `Variation ${p.attempt}/${p.total} testing...`;
      if (cntEl) cntEl.textContent = `${p.noPid || 0} skipped`;
      if (bestEl && p.best) bestEl.textContent = `Best: ₹${p.best}`;
    }
    if (stored.shipResults && stored.shipResults.done) {
      clearInterval(pollInterval);
      shipStop(stored.shipResults.results || []);
    }
  }, 500);
}

function shipStop(results) {
  shipIsProcessing = false;
  shipResults = results || [];

  document.getElementById("ship-start-btn").style.display = "block";
  document.getElementById("ship-stop-btn").style.display = "none";
  document.getElementById("ship-progress-wrap").style.display = "none";

  if (shipResults.length > 0) {
    document.getElementById("ship-results-wrap").style.display = "block";
    document.getElementById("ship-results-count").textContent = `(${shipResults.length})`;
    renderShipResults();
  } else {
    alert("Koi result nahi mila. Meesho catalog page (product add/edit) pe hona chahiye.");
  }
}

function renderShipResults() {
  const list = document.getElementById("ship-results-list");
  if (!list) return;
  list.innerHTML = shipResults.slice(0, 10).map((r, i) => `
    <div class="ship-result-row ${i===0?'best':''}">
      ${r.dataUrl ? `<img class="ship-result-img" src="${r.dataUrl}">` : ''}
      <div style="flex:1;min-width:0;">
        <div class="ship-result-cost ${i===0?'best-cost':''}">₹${r.shippingCost}</div>
        <div class="ship-result-name">${r.name}${r.isVerified?' ✓':''}</div>
      </div>
      <div class="ship-result-btns">
        <button class="ship-btn-apply" data-i="${i}">Apply</button>
        <button class="ship-btn-save" data-i="${i}">Save</button>
      </div>
    </div>
  `).join('');

  list.querySelectorAll(".ship-btn-apply").forEach(btn => {
    btn.onclick = () => shipApply(shipResults[parseInt(btn.dataset.i)]);
  });
  list.querySelectorAll(".ship-btn-save").forEach(btn => {
    btn.onclick = () => shipDownload(shipResults[parseInt(btn.dataset.i)]);
  });
  document.getElementById("ship-apply-best-btn").onclick = () => {
    if (shipResults.length > 0) shipApply(shipResults[0]);
  };
  document.getElementById("ship-retry-btn").onclick = shipReset;
}

async function shipApply(result) {
  if (!result) return;
  const tabs = await new Promise(r => chrome.tabs.query({ active: true, currentWindow: true }, r));
  if (!tabs[0] || !tabs[0].url.includes("meesho.com")) {
    alert("Meesho listing page open karein"); return;
  }
  chrome.tabs.sendMessage(tabs[0].id, { action: "APPLY_SHIP_IMAGE", dataUrl: result.dataUrl }, res => {
    if (res && res.success) alert("✅ Image apply ho gaya! Shipping price check karein.");
    else alert("Apply karne mein error — manual upload try karein");
  });
}

function shipDownload(result) {
  const a = document.createElement("a");
  a.href = result.dataUrl;
  a.download = `kiwtech-ship-${result.name}-${Date.now()}.jpg`;
  a.click();
}

function shipReset() {
  shipShouldStop = false;
  shipIsProcessing = false;
  document.getElementById("ship-start-btn").style.display = "block";
  document.getElementById("ship-stop-btn").style.display = "none";
  document.getElementById("ship-progress-wrap").style.display = "none";
  document.getElementById("ship-results-wrap").style.display = "none";
}

// Listen for shipping progress from content script
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "SHIP_PROGRESS") {
    const pct = Math.round((msg.attempt / msg.total) * 100);
    const bar = document.getElementById("ship-progress-bar-inner");
    const txt = document.getElementById("ship-progress-text");
    const cnt = document.getElementById("ship-progress-count");
    const best = document.getElementById("ship-progress-best");
    if (bar) bar.style.width = pct + "%";
    if (txt) txt.textContent = `Variation ${msg.attempt}/${msg.total}...`;
    if (cnt) cnt.textContent = `${msg.noPid||0} skipped`;
    if (best && msg.best) best.textContent = `Best: ₹${msg.best}`;
  }
  if (msg.type === "SHIP_DONE") {
    shipStop(msg.results || []);
  }
});


// ─── AUTO UPDATE CHECKER ─────────────────────────────────────
const CURRENT_VERSION = "5.1";
const VERSION_URL = "https://kiwtech.in/version-research.json";

async function checkForResearchUpdate() {
  try {
    const res = await fetch(VERSION_URL + "?t=" + Date.now());
    if (!res.ok) return;
    const data = await res.json();
    const latest = data.version;

    const curr = CURRENT_VERSION.split(".").map(Number);
    const lat  = latest.split(".").map(Number);
    const isNewer = lat[0] > curr[0] || (lat[0] === curr[0] && lat[1] > curr[1]);

    if (!isNewer) return;

    // Show update banner
    let banner = document.getElementById("kw-update-banner");
    if (!banner) {
      banner = document.createElement("div");
      banner.id = "kw-update-banner";
      banner.style.cssText = "position:fixed;top:0;left:0;right:0;z-index:99999;background:linear-gradient(135deg,#6C47FF,#ff2d78);color:#fff;padding:10px 14px;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:space-between;gap:8px;box-shadow:0 2px 12px rgba(0,0,0,0.3);";
      banner.innerHTML = `
        <span>🚀 New update available — v${latest}!</span>
        <div style="display:flex;gap:8px;align-items:center;">
          <a href="${data.download_url}" target="_blank"
            style="background:#fff200;color:#000;padding:5px 12px;border-radius:8px;font-size:12px;font-weight:900;text-decoration:none;">
            ⬇️ Update Now
          </a>
          <button onclick="this.parentElement.parentElement.remove()"
            style="background:none;border:none;color:#fff;cursor:pointer;font-size:18px;padding:0 4px;">×</button>
        </div>
      `;
      document.body.prepend(banner);
    }

    // Store update info
    await chrome.storage.local.set({
      pendingResearchUpdate: { version: latest, url: data.download_url }
    });

  } catch(e) {
    console.log("[Kiwtech] Update check failed:", e.message);
  }
}

// Check after 3 seconds
setTimeout(checkForResearchUpdate, 3000);
